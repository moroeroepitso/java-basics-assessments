package javamarathon.part1.fundamentals;

import java.util.Scanner;

/**
 *
 * @author botho
 */
public class CheckIfSidesFormaRightAngle {

    public static void main(String[] args) {
        Scanner scanner = new Scanner(System.in);

        System.out.println("Input three integers (sides of a triangle):");
        int a = scanner.nextInt();
        int b = scanner.nextInt();
        int c = scanner.nextInt();
        scanner.close();

        // Find the largest side (potential hypotenuse)
        int hypotenuse = Math.max(a, Math.max(b, c));
        int side1, side2;

        // Assign the other two sides
        if (hypotenuse == a) {
            side1 = b;
            side2 = c;

        } else if (hypotenuse == b) {
            side1 = a;
            side2 = c;

        } else {
            side1 = a;
            side2 = b;
        }

        // Check Pythagorean theorem: hypotenuse^2 == side1^2 + side2^2
        if (hypotenuse * hypotenuse == side1 * side1 + side2 * side2) {
            System.out.println("Yes");
        } else {
            System.out.println("No");
        }
    }
}
