package javamarathon.part1.fundamentals;

/**
 *
 * @author botho
 */
public class UniqueThreeDigitsNumbers {

    public static void main(String[] args) {

        // ------------------------------------------------------------
        // STEP 1: Initialize a counter for valid numbers
        // ------------------------------------------------------------
        // We increment this counter every time we form a valid
        // three-digit number (all three digits distinct).
        int count = 0;

        // ------------------------------------------------------------
        // STEP 2: Generate all combinations using three nested loops
        // ------------------------------------------------------------
        // Loop structure:
        //   - Outer loop (i):    hundreds digit
        //   - Middle loop (j):   tens digit
        //   - Inner loop (k):    units digit
        //
        // Each loop iterates over the allowed digit set {1, 2, 3, 4}.
        // The nested loops naturally produce numbers in lexicographic
        // order, which matches the expected output.
        for (int i = 1; i <= 4; i++) {          // hundreds place

            for (int j = 1; j <= 4; j++) {      // tens place

                for (int k = 1; k <= 4; k++) {  // units place

                    // ------------------------------------------------
                    // STEP 3: Check that all three digits are distinct
                    // ------------------------------------------------
                    // The rule "each digit used at most once" means:
                    //     i ≠ j, j ≠ k, and i ≠ k
                    //
                    // If any two digits are equal, we skip this
                    // combination using 'continue' — jumping straight
                    // to the next iteration of the innermost loop.
                    //
                    // The '&&' operator short-circuits: if i == j is
                    // true, we don't need to evaluate the rest.
                    if (i == j || j == k || i == k) {
                        continue;   // invalid combination; skip it
                    }

                    // ------------------------------------------------
                    // STEP 4: Form the number and print it
                    // ------------------------------------------------
                    // The digits i, j, k can be combined into a
                    // three-digit number using arithmetic:
                    //     number = i × 100 + j × 10 + k
                    //
                    // Alternatively, we can concatenate them as
                    // strings. Both produce the same printed output,
                    // but the arithmetic form is the "real" number.
                    int number = i * 100 + j * 10 + k;

                    // Print the number on its own line.
                    System.out.println(number);

                    // ------------------------------------------------
                    // STEP 5: Increment the counter
                    // ------------------------------------------------
                    count++;
                }
            }
        }

        // ------------------------------------------------------------
        // STEP 6: Print the total count
        // ------------------------------------------------------------
        // The required output format is:
        //   "Total number of the three-digit-number is 24"
        System.out.println("Total number of the three-digit-number is " + count);

        // ------------------------------------------------------------
        // STEP 7: (Optional) Show the combinatorial calculation
        // ------------------------------------------------------------
        // The count of 24 comes from the permutation formula:
        //     P(4, 3) = 4! / (4 − 3)! = 24 / 1 = 24
        //
        // This section is for reference; it is not part of the
        // required output.
        System.out.println();
        System.out.println("Combinatorial explanation:");
        System.out.println("  P(4, 3) = 4! / (4 - 3)! = 24 / 1 = 24");

        // ============================================================
        // ALTERNATIVE APPROACH — Collect into a list first
        // ============================================================
        // The nested-loop approach prints numbers as they are found.
        // If you need to store them for later use (e.g., to sort,
        // filter, or further process), collect them in a List.
        // ============================================================
        java.util.List<Integer> results = new java.util.ArrayList<>();
        for (int i = 1; i <= 4; i++) {
            for (int j = 1; j <= 4; j++) {
                for (int k = 1; k <= 4; k++) {
                    if (i != j && j != k && i != k) {
                        results.add(i * 100 + j * 10 + k);
                    }
                }
            }
        }
        System.out.println();
        System.out.println("Collected into a list: " + results);
        System.out.println("List size: " + results.size());
    }
}
