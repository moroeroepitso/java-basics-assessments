package javamarathon.part1.fundamentals;

import java.util.Scanner;

/**
 *
 * @author botho
 */
public class SumDigitstoSingleDigit {

    public static void main(String[] args) {
        Scanner scanner = new Scanner(System.in);
        System.out.print("Input a positive integer: ");
        int num = scanner.nextInt();
        scanner.close();

        // Repeatedly sum digits until a single digit remains
        while (num >= 10) {
            int sum = 0;
            // Extract each digit and add
            while (num > 0) {
                sum += num % 10;
                num /= 10;
            }
            num = sum; // assign the sum for next iteration
        }

        System.out.println(num); // prints the single digit result
    }
}
