package javamarathon.part1.fundamentals;

/**
 *
 * @author botho
 */
public class DistanceBetweenTwoPoints {

    public static void main(String[] args) {

        // ------------------------------------------------------------
        // STEP 1: Declare the coordinates of the two points (in degrees)
        // ------------------------------------------------------------
        // Point A = Nashville, Tennessee
        double lat1 = 36.12;    // latitude of point A
        double lon1 = -86.67;   // longitude of point A (negative = west)

        // Point B = Los Angeles, California
        double lat2 = 33.94;    // latitude of point B
        double lon2 = -118.40;  // longitude of point B (negative = west)

        // ------------------------------------------------------------
        // STEP 2: Define the Earth's mean radius
        // ------------------------------------------------------------
        // The mean radius is approximately 6371 km. Different values
        // (equatorial 6378.137 km, polar 6356.752 km, mean 6371 km) are
        // used in different contexts. 6371 km is the standard choice
        // for the Haversine formula in most tutorials and reference
        // implementations (including the classic rosettacode.org example).
        double earthRadiusKm = 6371.0;

        // ------------------------------------------------------------
        // STEP 3: Convert coordinates from degrees to radians
        // ------------------------------------------------------------
        // Java's Math.sin, Math.cos, and Math.atan2 expect angles in
        // RADIANS. Math.toRadians() converts degrees to radians:
        //     radians = degrees × π / 180
        //
        // We convert all four coordinates up front so the formula below
        // stays clean.
        double lat1Rad = Math.toRadians(lat1);
        double lon1Rad = Math.toRadians(lon1);
        double lat2Rad = Math.toRadians(lat2);
        double lon2Rad = Math.toRadians(lon2);

        // ------------------------------------------------------------
        // STEP 4: Compute the differences in latitude and longitude
        // ------------------------------------------------------------
        // Δφ = φ₂ − φ₁  and  Δλ = λ₂ − λ₁
        double deltaLat = lat2Rad - lat1Rad;
        double deltaLon = lon2Rad - lon1Rad;

        // ------------------------------------------------------------
        // STEP 5: Apply the Haversine formula
        // ------------------------------------------------------------
        //   a = sin²(Δφ / 2) + cos(φ₁) × cos(φ₂) × sin²(Δλ / 2)
        //
        // Note: 'sin²(x)' means (sin(x))², not sin(x²).
        //       We write 'Math.sin(...) * Math.sin(...)' or use
        //       'Math.pow(Math.sin(...), 2)'. The multiplication
        //       form is faster and just as readable.
        double sinHalfLat = Math.sin(deltaLat / 2);
        double sinHalfLon = Math.sin(deltaLon / 2);

        double a = sinHalfLat * sinHalfLat
                + Math.cos(lat1Rad) * Math.cos(lat2Rad)
                * sinHalfLon * sinHalfLon;

        // ------------------------------------------------------------
        // STEP 6: Compute the central angle 'c' in radians
        // ------------------------------------------------------------
        //   c = 2 × atan2(√a, √(1 − a))
        //
        // Math.atan2(y, x) returns the angle θ such that tan(θ) = y/x,
        // correctly handling all quadrants. It is more numerically
        // stable than 2 × asin(√a) for small distances and near-
        // antipodal points.
        double c = 2 * Math.atan2(Math.sqrt(a), Math.sqrt(1 - a));

        // ------------------------------------------------------------
        // STEP 7: Compute the final distance
        // ------------------------------------------------------------
        //   d = R × c
        double distanceKm = earthRadiusKm * c;

        // ------------------------------------------------------------
        // STEP 8: Print the result
        // ------------------------------------------------------------
        // The required output format is:
        //   "The distance between those points is: 2886.448429764854 km"
        System.out.println("The distance between those points is: "
                + distanceKm + " km");

        // ------------------------------------------------------------
        // STEP 9: (Optional) Print a verification trace
        // ------------------------------------------------------------
        // Showing the intermediate values helps confirm the calculation
        // and provides a useful learning reference.
        System.out.println();
        System.out.println("Verification trace:");
        System.out.println("  Point A (lat, lon) degrees : ("
                + lat1 + ", " + lon1 + ")");
        System.out.println("  Point B (lat, lon) degrees : ("
                + lat2 + ", " + lon2 + ")");
        System.out.println("  Point A (lat, lon) radians : ("
                + lat1Rad + ", " + lon1Rad + ")");
        System.out.println("  Point B (lat, lon) radians : ("
                + lat2Rad + ", " + lon2Rad + ")");
        System.out.println("  Δφ (radians)               = " + deltaLat);
        System.out.println("  Δλ (radians)               = " + deltaLon);
        System.out.println("  sin²(Δφ/2)                 = "
                + (sinHalfLat * sinHalfLat));
        System.out.println("  sin²(Δλ/2)                 = "
                + (sinHalfLon * sinHalfLon));
        System.out.println("  a                          = " + a);
        System.out.println("  c (central angle, radians) = " + c);
        System.out.println("  Earth radius (km)          = " + earthRadiusKm);
        System.out.println("  Distance (km)              = " + distanceKm);

        // ------------------------------------------------------------
        // STEP 10: (Optional) Print the distance in other units
        // ------------------------------------------------------------
        // A common convenience is to also show the distance in miles,
        // nautical miles, and meters. The conversion factors are:
        //   1 km  ≈ 0.621371 miles
        //   1 km  ≈ 0.539957 nautical miles
        //   1 km  =  1000 meters
        // ------------------------------------------------------------
        double distanceMiles = distanceKm * 0.621371;
        double distanceNauticalMiles = distanceKm * 0.539957;
        double distanceMeters = distanceKm * 1000;

        System.out.println();
        System.out.println("Distance in other units:");
        System.out.println("  Miles           : " + distanceMiles);
        System.out.println("  Nautical miles  : " + distanceNauticalMiles);
        System.out.println("  Meters          : " + distanceMeters);

        // ------------------------------------------------------------
        // BONUS: Try more examples to confirm the logic
        // ------------------------------------------------------------
        // Uncomment the lines below to test other famous city pairs.
        // ------------------------------------------------------------
        // System.out.println("\nMore examples:");
        //
        // // New York to London (≈ 5570 km)
        // System.out.println("  NYC → London   : "
        //     + haversine(40.7128, -74.0060, 51.5074, -0.1278) + " km");
        //
        // // Sydney to Tokyo (≈ 7826 km)
        // System.out.println("  Sydney → Tokyo : "
        //     + haversine(-33.8688, 151.2093, 35.6762, 139.6503) + " km");
        //
        // // Same point → should return 0
        // System.out.println("  Same point     : "
        //     + haversine(36.12, -86.67, 36.12, -86.67) + " km");
    }

    /**
     * Computes the great-circle distance in kilometers between two points on
     * the Earth's surface using the Haversine formula.
     *
     * This helper method is used in the "BONUS" section above to compute
     * distances for multiple city pairs without duplicating the formula.
     *
     * @param lat1 latitude of point A in decimal degrees
     * @param lon1 longitude of point A in decimal degrees
     * @param lat2 latitude of point B in decimal degrees
     * @param lon2 longitude of point B in decimal degrees
     * @return great-circle distance between A and B in kilometers
     */
    private static double haversine(double lat1, double lon1,
            double lat2, double lon2) {
        // Mean Earth radius in kilometers.
        final double R = 6371.0;

        // Convert degrees to radians.
        double phi1 = Math.toRadians(lat1);
        double phi2 = Math.toRadians(lat2);
        double deltaPhi = Math.toRadians(lat2 - lat1);
        double deltaLambda = Math.toRadians(lon2 - lon1);

        // Haversine formula.
        double a = Math.sin(deltaPhi / 2) * Math.sin(deltaPhi / 2)
                + Math.cos(phi1) * Math.cos(phi2)
                * Math.sin(deltaLambda / 2) * Math.sin(deltaLambda / 2);

        double c = 2 * Math.atan2(Math.sqrt(a), Math.sqrt(1 - a));

        return R * c;
    }
}
