package javamarathon.part1.fundamentals;

/**
 *
 * 2128087 PITSO MOROEROE
 */
public class ExpressionEvaluation {



    public static void main(String[] args) {

        // ------------------------------------------------------------
        // STEP 1: Declare and initialize all six variables as 'double'
        // ------------------------------------------------------------
        // Declaring every variable as 'double' ensures that all arithmetic
        // operations (especially division) are performed in floating-point
        // arithmetic, avoiding integer truncation.
        double a = 5;
        double b = 3;
        double c = 4;
        double d = 2;
        double e = 6;
        double f = 1.5;

        // ------------------------------------------------------------
        // STEP 2: Evaluate the expression
        // ------------------------------------------------------------
        // The expression is:   (a + b) / c + (d * e) - f
        //
        // Java follows standard operator precedence (PEMDAS):
        //   1. Parentheses          ->  (a + b)  and  (d * e)
        //   2. Multiplication (*)   ->  d * e
        //   3. Division (/)         ->  (a + b) / c
        //   4. Addition (+)         ->  + between the two terms
        //   5. Subtraction (-)      ->  - f
        //
        // Note: * and / have equal precedence and are evaluated
        //       left-to-right. The same is true for + and -.
        //
        // Step-by-step trace:
        //   (a + b)        =  (5.0 + 3.0)   =  8.0
        //   (d * e)        =  (2.0 * 6.0)   =  12.0
        //   (a + b) / c    =  8.0 / 4.0     =  2.0
        //   2.0 + 12.0     =  14.0
        //   14.0 - 1.5     =  12.5
        double result = (a + b) / c + (d * e) - f;

        // ------------------------------------------------------------
        // STEP 3: Print the result in a readable format
        // ------------------------------------------------------------
        // Using println() with string concatenation for clarity.
        // The '+' signs outside the parentheses are string concatenation
        // operators, while the '+' inside the parentheses are arithmetic.
        System.out.println("(a + b) / c + (d * e) - f");
        System.out.println("= (" + a + " + " + b + ") / " + c
                         + " + (" + d + " * " + e + ") - " + f);
        System.out.println("= " + result);

        // ------------------------------------------------------------
        // STEP 4: (Optional) Show intermediate values for debugging
        // ------------------------------------------------------------
        // Breaking the expression into smaller pieces helps verify each
        // step of the calculation and makes the logic easier to follow.
        double sumAB      = a + b;              // 8.0
        double productDE  = d * e;              // 12.0
        double quotient   = (a + b) / c;        // 2.0
        double intermediate = quotient + productDE; // 14.0
        double finalValue = intermediate - f;   // 12.5

        System.out.println();
        System.out.println("Step-by-step breakdown:");
        System.out.println("  (a + b)      = " + sumAB);
        System.out.println("  (d * e)      = " + productDE);
        System.out.println("  (a + b) / c  = " + quotient);
        System.out.println("  quotient + (d * e) = " + intermediate);
        System.out.println("  intermediate - f   = " + finalValue);

        // ------------------------------------------------------------
        // Alternative output using printf() for cleaner formatting
        // (uncomment to use) — %.1f prints one decimal place.
        // ------------------------------------------------------------
        // System.out.printf("Result = %.1f%n", result);
    }
} 

