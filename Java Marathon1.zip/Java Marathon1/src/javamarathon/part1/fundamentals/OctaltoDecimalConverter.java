package javamarathon.part1.fundamentals;

/**
 *
 * @author botho
 */
public class OctaltoDecimalConverter {

    public static void main(String[] args) {

        // ------------------------------------------------------------
        // STEP 1: Declare the octal number as a String
        // ------------------------------------------------------------
        // Storing the octal value as a String preserves its octal meaning
        // and allows leading zeros (e.g., "0010") if needed.
        String octal = "10";

        // ------------------------------------------------------------
        // STEP 2: Convert to decimal using the built-in method
        // ------------------------------------------------------------
        // Integer.parseInt(String, radix) interprets the string as a
        // number in the given base. Passing radix = 8 tells Java to
        // treat the string as octal.
        //
        //   Integer.parseInt("10", 8)  =  8
        //
        // This is the recommended approach for real-world code: concise,
        // correct, and handles leading zeros properly.
        int decimalNumber = Integer.parseInt(octal, 8);

        // ------------------------------------------------------------
        // STEP 3: Print the result
        // ------------------------------------------------------------
        // The required output format is:
        //   "Equivalent decimal number: 8"
        System.out.println("Equivalent decimal number: " + decimalNumber);

        // ------------------------------------------------------------
        // STEP 4: (Optional) Print a verification trace
        // ------------------------------------------------------------
        // Showing the intermediate steps helps confirm the conversion
        // was done correctly and provides a useful learning reference.
        System.out.println();
        System.out.println("Verification trace:");
        System.out.println("  Octal string    = " + octal);
        System.out.println("  Decimal number  = " + decimalNumber);
        System.out.println("  Octal check     = " + Integer.toOctalString(decimalNumber));

        // ============================================================
        // ALTERNATIVE APPROACH — Manual octal-to-decimal conversion
        // ============================================================
        // This method shows the underlying algorithm: walk through the
        // octal string from LEFT to RIGHT, multiplying the running total
        // by 8 at each step and adding the current digit. This is a form
        // of Horner's method and avoids computing powers of 8 separately.
        //
        // WORKING TRACE with octal = "10":
        //
        //   Start:  decimal = 0
        //   Digit '1':  decimal = 0 × 8 + 1  =  1
        //   Digit '0':  decimal = 1 × 8 + 0  =  8   ✓
        //
        // WORKING TRACE with octal = "17" (15 in decimal):
        //
        //   Start:  decimal = 0
        //   Digit '1':  decimal = 0 × 8 + 1  =  1
        //   Digit '7':  decimal = 1 × 8 + 7  =  15   ✓
        //
        // WORKING TRACE with octal = "377" (255 in decimal):
        //
        //   Start:  decimal = 0
        //   Digit '3':  decimal = 0   × 8 + 3  =  3
        //   Digit '7':  decimal = 3   × 8 + 7  =  31
        //   Digit '7':  decimal = 31  × 8 + 7  =  255   ✓
        // ============================================================
        int manualDecimal = octalToDecimalManual(octal);
        System.out.println();
        System.out.println("Manual conversion result: " + manualDecimal);

        // ------------------------------------------------------------
        // BONUS: Try more examples to confirm the logic
        // ------------------------------------------------------------
        // Uncomment the lines below to test other octal values.
        // ------------------------------------------------------------
        // System.out.println("\nMore examples:");
        // System.out.println("  0    → " + octalToDecimalManual("0"));      // 0
        // System.out.println("  1    → " + octalToDecimalManual("1"));      // 1
        // System.out.println("  7    → " + octalToDecimalManual("7"));      // 7
        // System.out.println("  10   → " + octalToDecimalManual("10"));     // 8
        // System.out.println("  17   → " + octalToDecimalManual("17"));     // 15
        // System.out.println("  100  → " + octalToDecimalManual("100"));    // 64
        // System.out.println("  377  → " + octalToDecimalManual("377"));    // 255
    }

    /**
     * Converts an octal string to its decimal integer representation.
     *
     * Algorithm (Horner's method): Walk through the octal string from left to
     * right, maintaining a running decimal value. At each step: decimal =
     * decimal * 8 + currentDigit This is equivalent to multiplying the running
     * total by 8 (to shift it one position left) and adding the new digit.
     *
     * This approach avoids computing powers of 8 explicitly, which makes it
     * both faster and easier to read.
     *
     * @param octal the octal string to convert (e.g., "10")
     * @return the equivalent decimal integer
     * @throws IllegalArgumentException if the input contains characters other
     * than '0' through '7', or if the string is empty
     */
    private static int octalToDecimalManual(String octal) {

        // Validate input: must be non-empty.
        if (octal == null || octal.isEmpty()) {
            throw new IllegalArgumentException(
                    "Octal string must not be null or empty.");
        }

        // 'decimal' holds the running total, starting at 0.
        int decimal = 0;

        // Walk through each character of the octal string from left
        // (most significant digit) to right (least significant digit).
        for (int i = 0; i < octal.length(); i++) {

            // Fetch the current character and validate it.
            char digit = octal.charAt(i);
            if (digit < '0' || digit > '7') {
                throw new IllegalArgumentException(
                        "Invalid octal character '" + digit
                        + "' at index " + i + ". Only '0' through '7' are allowed.");
            }

            // Multiply the running total by 8 (shift one position left),
            // then add the numeric value of the current digit.
            //   '7' - '0' = 7
            //   '3' - '0' = 3
            decimal = decimal * 8 + (digit - '0');
        }

        // Return the computed decimal value.
        return decimal;
    }
}
