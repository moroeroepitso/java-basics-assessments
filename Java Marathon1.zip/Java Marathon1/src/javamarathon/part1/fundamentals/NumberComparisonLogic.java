package javamarathon.part1.fundamentals;

import java.util.Scanner;

/**
 *
 * @author botho
 */
public class NumberComparisonLogic {

    public static void main(String[] args) {

        // ------------------------------------------------------------
        // STEP 1: Create a Scanner to read input from the keyboard
        // ------------------------------------------------------------
        Scanner scanner = new Scanner(System.in);

        // ------------------------------------------------------------
        // STEP 2: Prompt for and read each of the three numbers
        // ------------------------------------------------------------
        // The prompts match the expected output exactly, including
        // the inconsistent spacing around the colons:
        //   "Input the first number : 2"   ← space before colon
        //   "Input the second number: 9"   ← no space before colon
        //   "Input the third number : 14"  ← space before colon
        //
        // We use print() so the user's input appears on the same line
        // as the prompt.
        System.out.print("Input the first number : ");
        int first = scanner.nextInt();

        System.out.print("Input the second number: ");
        int second = scanner.nextInt();

        System.out.print("Input the third number : ");
        int third = scanner.nextInt();

        // ------------------------------------------------------------
        // STEP 3: Evaluate the ascending-order condition
        // ------------------------------------------------------------
        // The condition is: second > first AND third > second.
        //
        // The two sub-conditions:
        //     (second > first)   →  is the second bigger than the first?
        //     (third  > second)  →  is the third bigger than the second?
        //
        // Both must be true, so we combine them with '&&' (AND).
        //
        // For (2, 9, 14):
        //     (9 > 2)  →  true
        //     (14 > 9) →  true
        //     true && true  →  true
        boolean result = (second > first) && (third > second);

        // ------------------------------------------------------------
        // STEP 4: Print the result
        // ------------------------------------------------------------
        // The required output format is:
        //   "The result is: true"
        //
        // Java's boolean printing gives lowercase "true" or "false",
        // matching the expected output exactly.
        System.out.println("The result is: " + result);

        // ------------------------------------------------------------
        // STEP 5: Close the Scanner
        // ------------------------------------------------------------
        scanner.close();

        // ------------------------------------------------------------
        // STEP 6: (Optional) Print verification details
        // ------------------------------------------------------------
        // A short trace showing each sub-condition helps confirm the
        // logic is correct.
        System.out.println();
        System.out.println("Verification trace:");
        System.out.println("  first  = " + first);
        System.out.println("  second = " + second);
        System.out.println("  third  = " + third);
        System.out.println("  second > first  →  " + second + " > " + first
                + "  →  " + (second > first));
        System.out.println("  third  > second →  " + third + " > " + second
                + "  →  " + (third > second));
        System.out.println("  Combined (&&)   →  " + result);

        // ============================================================
        // ALTERNATIVE 1 — Static (non-interactive) version
        // ============================================================
        // For fixed inputs (2, 9, 14), no reading is needed. The
        // entire computation collapses to a single boolean expression.
        // ============================================================
        int f = 2, s = 9, t = 14;
        boolean staticResult = (s > f) && (t > s);

        System.out.println();
        System.out.println("Static version:");
        System.out.println("  (9 > 2) && (14 > 9)  →  " + staticResult);

        // ============================================================
        // ALTERNATIVE 2 — Using a helper method
        // ============================================================
        // Encapsulating the test in a method gives it a clear name
        // and makes it reusable across the program.
        // ============================================================
        System.out.println();
        System.out.println("Via helper method:");
        System.out.println("  isStrictlyAscending(2, 9, 14)   = "
                + isStrictlyAscending(2, 9, 14));
        System.out.println("  isStrictlyAscending(1, 2, 3)    = "
                + isStrictlyAscending(1, 2, 3));
        System.out.println("  isStrictlyAscending(3, 2, 1)    = "
                + isStrictlyAscending(3, 2, 1));
        System.out.println("  isStrictlyAscending(1, 1, 2)    = "
                + isStrictlyAscending(1, 1, 2));
        System.out.println("  isStrictlyAscending(1, 2, 2)    = "
                + isStrictlyAscending(1, 2, 2));
        System.out.println("  isStrictlyAscending(-5, 0, 5)   = "
                + isStrictlyAscending(-5, 0, 5));

        // ============================================================
        // ALTERNATIVE 3 — Chained comparison via a single expression
        // ============================================================
        // The condition "second > first && third > second" can be
        // written more compactly, though Java does not support the
        // mathematical chained form "first < second < third" the way
        // some other languages do. We must write both comparisons
        // explicitly:
        // ============================================================
        boolean chained = first < second && second < third;
        System.out.println();
        System.out.println("Chained form (first < second && second < third): "
                + chained);

        // Note: many beginners try to write "first < second < third".
        // Java parses this left-to-right as "(first < second) < third",
        // which is a compile error because the left side is a boolean
        // and the right side is an int — they can't be compared with <.
        // The correct form always combines two comparisons with &&.
        // ============================================================
        // ALTERNATIVE 4 — Generalized: check ascending order for any N
        // ============================================================
        // The condition extends naturally to any number of values:
        // for an array arr, "strictly ascending" means
        //     arr[i] < arr[i+1]  for every i.
        // A loop over the array checks all consecutive pairs.
        // ============================================================
        int[] values = {2, 9, 14};
        boolean isAscending = true;
        for (int i = 0; i < values.length - 1; i++) {
            if (values[i] >= values[i + 1]) {
                isAscending = false;
                break;
            }
        }
        System.out.println();
        System.out.println("Generalized (array-based) check: " + isAscending);

        // ============================================================
        // ALTERNATIVE 5 — Descending or other orderings
        // ============================================================
        // Similar tests can check other orderings:
        //   strictly descending:  first > second && second > third
        //   non-decreasing:       first <= second && second <= third
        //   non-increasing:       first >= second && second >= third
        // ============================================================
        System.out.println();
        System.out.println("Other orderings for (2, 9, 14):");
        System.out.println("  strictly descending  → "
                + (first > second && second > third));
        System.out.println("  non-decreasing       → "
                + (first <= second && second <= third));
        System.out.println("  non-increasing       → "
                + (first >= second && second >= third));
    }

    /**
     * Returns true if the three integers are in strictly ascending order: a < b
     * < c.
     *
     * The method is small and clear; giving it a name ("is strictly ascending")
     * makes the calling code read almost like English.
     *
     * @param a first value
     * @param b second value
     * @param c third value
     * @return true if a < b < c, false otherwise
     */
    private static boolean isStrictlyAscending(int a, int b, int c) {
        return (b > a) && (c > b);
    }
}
