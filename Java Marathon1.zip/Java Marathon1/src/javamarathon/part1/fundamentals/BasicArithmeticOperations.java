package javamarathon.part1.fundamentals;

public class BasicArithmeticOperations {

    public static void main(String[] args) {

        // ------------------------------------------------------------
        // STEP 1: Declare and initialize the two input numbers
        // ------------------------------------------------------------
        // 'a' is the first operand (dividend / minuend / multiplicand).
        // 'b' is the second operand (divisor / subtrahend / multiplier).
        // Both are stored as 'int' since the given values are whole numbers.
        int a = 125;
        int b = 24;

        // ------------------------------------------------------------
        // STEP 2: Perform the arithmetic operations
        // ------------------------------------------------------------
        // Each result is stored in its own variable for clarity and to
        // allow reuse (e.g., printing, further computation, testing).

        // Addition: combines the two values into a single sum.
        // 125 + 24 = 149
        int sum = a + b;

        // Subtraction: removes the second value from the first.
        // 125 - 24 = 101
        int difference = a - b;

        // Multiplication: repeated addition of 'a' by 'b' times.
        // 125 * 24 = 3000
        int product = a * b;

        // Division: integer division. Because both operands are 'int',
        // the fractional part is truncated (NOT rounded).
        // 125 / 24 = 5 remainder 5, so the integer result is 5.
        // NOTE: If either operand were a 'double', the result would be
        //       5.2083333... and the decimal portion would be kept.
        int quotient = a / b;

        // Modulus: returns the remainder left over after integer division.
        // 125 mod 24 = 5  because  24 * 5 = 120 and 125 - 120 = 5.
        // The modulus operator is often used to check divisibility
        // (remainder == 0 means 'b' divides 'a' evenly).
        int remainder = a % b;

        // ------------------------------------------------------------
        // STEP 3: Display each result in the required format
        // ------------------------------------------------------------
        // We use println() with string concatenation for a clean,
        // readable output. The '+' inside the print statements is the
        // string concatenation operator, NOT arithmetic addition.
        System.out.println(a + " + " + b + " = " + sum);        // Addition line
        System.out.println(a + " - " + b + " = " + difference);  // Subtraction line
        System.out.println(a + " x " + b + " = " + product);     // Multiplication line
        System.out.println(a + " / " + b + " = " + quotient);    // Division line
        System.out.println(a + " mod " + b + " = " + remainder); // Modulus line

        // ------------------------------------------------------------
        // Alternative display using printf() for aligned formatting
        // (uncomment to use) — %d is the placeholder for an int value.
        // ------------------------------------------------------------
        // System.out.printf("%d + %d = %d%n", a, b, sum);
        // System.out.printf("%d - %d = %d%n", a, b, difference);
        // System.out.printf("%d x %d = %d%n", a, b, product);
        // System.out.printf("%d / %d = %d%n", a, b, quotient);
        // System.out.printf("%d mod %d = %d%n", a, b, remainder);
    }
}
 
