package javamarathon.part1.fundamentals;

/**
 *
 * @author botho
 */
public class DecimaltoBinaryConverter {

    public static void main(String[] args) {

        // ------------------------------------------------------------
        // STEP 1: Declare the decimal number
        // ------------------------------------------------------------
        // The number is stored as an 'int' since the input is a whole
        // decimal number with no fractional part.
        int number = 5;

        // ------------------------------------------------------------
        // STEP 2: Convert to binary using the built-in method
        // ------------------------------------------------------------
        // Integer.toBinaryString(int) returns the binary representation
        // of the given integer as a String, without leading zeros.
        //
        //   Integer.toBinaryString(5)  =  "101"
        //
        // This is the recommended approach for real-world code: concise,
        // correct, and handles all edge cases (including 0 and negative
        // numbers) properly.
        String binaryString = Integer.toBinaryString(number);

        // ------------------------------------------------------------
        // STEP 3: Print the result
        // ------------------------------------------------------------
        // The required output format is:
        //   "Binary number is: 101"
        System.out.println("Binary number is: " + binaryString);

        // ------------------------------------------------------------
        // STEP 4: (Optional) Print a verification trace
        // ------------------------------------------------------------
        // Showing the intermediate steps helps confirm the conversion
        // was done correctly and provides a useful learning reference.
        System.out.println();
        System.out.println("Verification trace:");
        System.out.println("  Decimal number  = " + number);
        System.out.println("  Binary string   = " + binaryString);
        System.out.println("  Decimal check   = " + Integer.parseInt(binaryString, 2));

        // ============================================================
        // ALTERNATIVE APPROACH — Manual decimal-to-binary conversion
        // ============================================================
        // This method shows the underlying algorithm: repeatedly divide
        // the decimal number by 2, and record each remainder. The
        // remainders, read from bottom to top, form the binary digits.
        //
        // WORKING TRACE with number = 5:
        //
        //   Step 1:  5 ÷ 2 = 2 remainder 1   →  record '1'
        //   Step 2:  2 ÷ 2 = 1 remainder 0   →  record '0'
        //   Step 3:  1 ÷ 2 = 0 remainder 1   →  record '1'
        //   Stop when the quotient reaches 0.
        //
        //   Remainders in order recorded:   1, 0, 1
        //   Reversed (read bottom-to-top):  1, 0, 1  →  "101"
        // ============================================================
        String manualBinary = decimalToBinaryManual(number);
        System.out.println();
        System.out.println("Manual conversion result: " + manualBinary);

        // ------------------------------------------------------------
        // BONUS: Try more examples to confirm the logic
        // ------------------------------------------------------------
        // Uncomment the lines below to test other decimal values.
        // ------------------------------------------------------------
        // System.out.println("\nMore examples:");
        // System.out.println("  0   → " + decimalToBinaryManual(0));      // 0
        // System.out.println("  1   → " + decimalToBinaryManual(1));      // 1
        // System.out.println("  10  → " + decimalToBinaryManual(10));     // 1010
        // System.out.println("  100 → " + decimalToBinaryManual(100));    // 1100100
        // System.out.println("  255 → " + decimalToBinaryManual(255));    // 11111111
    }

    /**
     * Converts a non-negative decimal integer to its binary string
     * representation using repeated division by 2.
     *
     * Algorithm: 1. If the number is 0, return "0" immediately. 2. While the
     * number is greater than 0: - Record the remainder of number / 2. - Divide
     * the number by 2 (integer division). 3. The remainders are collected from
     * least significant bit to most significant bit, so reverse them at the
     * end.
     *
     * @param n the decimal number to convert (must be >= 0)
     * @return the binary representation of n as a String
     */
    private static String decimalToBinaryManual(int n) {

        // Special case: 0 in decimal is "0" in binary.
        // Without this check, the loop below would not execute at all
        // (since n is not > 0), and we would return an empty string.
        if (n == 0) {
            return "0";
        }

        // StringBuilder accumulates the binary digits (bits) in the
        // order they are produced — from least significant to most
        // significant. We will reverse this at the end.
        StringBuilder bits = new StringBuilder();

        // Work on a copy of the input so the original is not modified.
        int quotient = n;

        // Repeatedly divide by 2, recording each remainder.
        while (quotient > 0) {
            // '%' returns the remainder of division by 2:
            //   even numbers → 0
            //   odd  numbers → 1
            int remainder = quotient % 2;

            // Append the current bit to the result.
            bits.append(remainder);

            // Integer division by 2 moves us to the next bit.
            // E.g., 5 / 2 = 2, then 2 / 2 = 1, then 1 / 2 = 0.
            quotient = quotient / 2;
        }

        // The bits were collected LSB-first, so reverse them to get
        // the standard MSB-first binary representation.
        return bits.reverse().toString();
    }
}
