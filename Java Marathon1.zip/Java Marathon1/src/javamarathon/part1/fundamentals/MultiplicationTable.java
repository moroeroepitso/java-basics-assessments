package javamarathon.part1.fundamentals;


import java.util.Scanner;

public class MultiplicationTable {

    public static void main(String[] args) {

        // ------------------------------------------------------------
        // STEP 1: Create a Scanner to read input from the keyboard
        // ------------------------------------------------------------
        // System.in represents standard input (the keyboard).
        // The Scanner wraps it and provides convenient methods like
        // nextInt() to read whole numbers.
        Scanner scanner = new Scanner(System.in);

        // ------------------------------------------------------------
        // STEP 2: Prompt the user and read the number
        // ------------------------------------------------------------
        System.out.print("Enter a number to print its multiplication table: ");

        // nextInt() reads the next integer the user types and stores it
        // in the variable 'number'. If the user types something that is
        // not an integer, an InputMismatchException will be thrown.
        int number = scanner.nextInt();

        // ------------------------------------------------------------
        // STEP 3: Print a header line for readability
        // ------------------------------------------------------------
        System.out.println("\nMultiplication Table of " + number + ":");
        System.out.println("-------------------------");

        // ------------------------------------------------------------
        // STEP 4: Loop from 1 to 10 and print each line of the table
        // ------------------------------------------------------------
        // A 'for' loop is ideal here because we know exactly how many
        // times we need to iterate (10 times).
        //
        //   int i = 1    -> initialization: start counter at 1
        //   i <= 10      -> condition: keep looping while i is at most 10
        //   i++          -> update: increment i by 1 after each iteration
        //
        // The loop body computes number * i and prints it in the
        // required "number x i = product" format.
        for (int i = 1; i <= 10; i++) {

            // Compute the product for the current row.
            // Because both 'number' and 'i' are int, the result is int.
            int product = number * i;

            // Print the current row of the multiplication table.
            // '+' is string concatenation here, not arithmetic addition.
            System.out.println(number + " x " + i + " = " + product);
        }

        // ------------------------------------------------------------
        // STEP 5: Close the Scanner to release the underlying resource
        // ------------------------------------------------------------
        // Good practice: close the Scanner once we are done reading input.
        scanner.close();

        // ------------------------------------------------------------
        // Alternative formatting using printf() (uncomment to use):
        // %d is a placeholder for an integer value.
        // ------------------------------------------------------------
        // for (int i = 1; i <= 10; i++) {
        //     System.out.printf("%d x %d = %d%n", number, i, number * i);
        // }
    }
}