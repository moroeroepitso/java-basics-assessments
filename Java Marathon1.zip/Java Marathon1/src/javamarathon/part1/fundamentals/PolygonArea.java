package javamarathon.part1.fundamentals;

/**
 *
 * @author botho
 */
public class PolygonArea {

    public static void main(String[] args) {

        // ------------------------------------------------------------
        // STEP 1: Declare and initialize the input values
        // ------------------------------------------------------------
        // 'sides' is the number of sides of the regular polygon.
        // Stored as 'int' because it must be a whole number.
        int sides = 7;

        // 'sideLength' is the length of one side.
        // Stored as 'double' because geometric computations with
        // trigonometric functions produce irrational results.
        double sideLength = 6;

        // ------------------------------------------------------------
        // STEP 2: Compute the area using the polygon formula
        // ------------------------------------------------------------
        // Formula:  Area = (n × s²) / (4 × tan(π / n))
        //
        // Step-by-step trace with n = 7, s = 6:
        //   s²              = 6 × 6                       = 36
        //   n × s²          = 7 × 36                      = 252
        //   π / n           = π / 7                       ≈ 0.4487989505128276
        //   tan(π / n)      = tan(0.4487989505128276)     ≈ 0.4815746188075287
        //   4 × tan(π / n)  = 4 × 0.4815746188075287      ≈ 1.926298475230115
        //   252 / 1.926298475230115                       ≈ 130.82084798405722
        //
        // Note: Because 'sides' is an 'int', the expression 'Math.PI / sides'
        // undergoes automatic type promotion — the int is converted to a
        // double before the division, so we get the correct fractional value.
        double area = (sides * sideLength * sideLength)
                / (4 * Math.tan(Math.PI / sides));

        // ------------------------------------------------------------
        // STEP 3: Print the result
        // ------------------------------------------------------------
        // The required output format is:
        //   "The area is: 130.82084798405722"
        //
        // Java's default double display shows full precision, matching
        // the expected output exactly.
        System.out.println("The area is: " + area);

        // ------------------------------------------------------------
        // STEP 4: (Optional) Print a verification trace
        // ------------------------------------------------------------
        // Showing the intermediate steps helps confirm the calculation
        // and provides a useful learning reference.
        System.out.println();
        System.out.println("Verification trace:");
        System.out.println("  Number of sides    = " + sides);
        System.out.println("  Side length        = " + sideLength);
        System.out.println("  side²              = " + (sideLength * sideLength));
        System.out.println("  n × s²             = " + (sides * sideLength * sideLength));
        System.out.println("  π / n              ≈ " + (Math.PI / sides));
        System.out.println("  tan(π / n)         ≈ " + Math.tan(Math.PI / sides));
        System.out.println("  4 × tan(π / n)     ≈ " + (4 * Math.tan(Math.PI / sides)));
        System.out.println("  Area               = " + area);

        // ------------------------------------------------------------
        // STEP 5: (Optional) Compute and display related measurements
        // ------------------------------------------------------------
        // For a regular polygon, several related quantities are useful:
        //   - Perimeter: total length around the polygon = n × s
        //   - Apothem:   distance from center to midpoint of a side
        //                = s / (2 × tan(π / n))
        //   - Circumradius: distance from center to a vertex
        //                = s / (2 × sin(π / n))
        // ------------------------------------------------------------
        double perimeter = sides * sideLength;
        double apothem = sideLength / (2 * Math.tan(Math.PI / sides));
        double circumradius = sideLength / (2 * Math.sin(Math.PI / sides));

        System.out.println();
        System.out.println("Related measurements:");
        System.out.println("  Perimeter          = " + perimeter);
        System.out.println("  Apothem            ≈ " + apothem);
        System.out.println("  Circumradius       ≈ " + circumradius);

        // ------------------------------------------------------------
        // STEP 6: (Optional) Verify using the (perimeter × apothem) / 2 form
        // ------------------------------------------------------------
        // An alternative way to compute the polygon area is:
        //     Area = (perimeter × apothem) / 2
        // This is equivalent to the main formula but uses intermediate
        // measurements. Comparing the two results is a good sanity check.
        // ------------------------------------------------------------
        double areaViaApothem = (perimeter * apothem) / 2;
        System.out.println();
        System.out.println("Area check (perimeter × apothem / 2): " + areaViaApothem);
        System.out.println("Values match: " + (Math.abs(area - areaViaApothem) < 1e-9));

        // ------------------------------------------------------------
        // BONUS: Try more examples to confirm the logic
        // ------------------------------------------------------------
        // Uncomment the lines below to test other polygons.
        // ------------------------------------------------------------
        // System.out.println("\nMore examples:");
        // System.out.println("  Triangle  (n=3, s=6): " + polygonArea(3, 6));   // 15.588...
        // System.out.println("  Square    (n=4, s=6): " + polygonArea(4, 6));   // 36.0
        // System.out.println("  Pentagon  (n=5, s=6): " + polygonArea(5, 6));   // 61.937...
        // System.out.println("  Hexagon   (n=6, s=6): " + polygonArea(6, 6));   // 93.530...
        // System.out.println("  Heptagon  (n=7, s=6): " + polygonArea(7, 6));   // 130.820...
        // System.out.println("  Octagon   (n=8, s=6): " + polygonArea(8, 6));   // 173.823...
        //
        // // As n grows very large, the polygon approaches a circle.
        // // For large n and small s, the area approaches π × R² where R
        // // is the circumradius.
    }

    /**
     * Computes the area of a regular polygon with the given number of sides and
     * side length.
     *
     * Formula: Area = (n × s²) / (4 × tan(π / n))
     *
     * This helper method is used in the "BONUS" section above to test multiple
     * polygons without duplicating the formula.
     *
     * @param n the number of sides (must be >= 3)
     * @param s the length of one side (must be > 0)
     * @return the area of the regular polygon
     */
    private static double polygonArea(int n, double s) {
        return (n * s * s) / (4 * Math.tan(Math.PI / n));
    }
}
