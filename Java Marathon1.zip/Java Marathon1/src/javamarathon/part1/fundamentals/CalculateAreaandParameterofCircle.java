package javamarathon.part1.fundamentals;

/**
 *
 * 2128087 pitso moroeroe
 */
public class CalculateAreaandParameterofCircle {
 
 public static void main(String[] args) {

        // ------------------------------------------------------------
        // STEP 1: Declare and initialize the radius
        // ------------------------------------------------------------
        // The radius is stored as a 'double' because it contains a
        // decimal value (7.5) and because all geometric formulas
        // involving π produce floating-point results.
        double radius = 7.5;

        // ------------------------------------------------------------
        // STEP 2: Compute the Perimeter (Circumference)
        // ------------------------------------------------------------
        // Formula:  C = 2 × π × r
        //
        // Step-by-step trace with radius = 7.5:
        //   2 × Math.PI  ≈ 6.283185307179586
        //   × 7.5        ≈ 47.12388980384689
        //
        // Math.PI is a static final field of the Math class that holds
        // the value of π to double precision.
        double perimeter = 2 * Math.PI * radius;

        // ------------------------------------------------------------
        // STEP 3: Compute the Area
        // ------------------------------------------------------------
        // Formula:  A = π × r²
        //
        // In Java, 'r²' is written as 'radius * radius' or, equivalently,
        // 'Math.pow(radius, 2)'. Multiplication is preferred here because
        // it is faster and avoids a method call for a trivial square.
        //
        // Step-by-step trace with radius = 7.5:
        //   r²           = 7.5 × 7.5          = 56.25
        //   π × 56.25    ≈ 3.141592653589793 × 56.25
        //                ≈ 176.71458676442586
        double area = Math.PI * radius * radius;

        // ------------------------------------------------------------
        // STEP 4: Print the results
        // ------------------------------------------------------------
        // Using println() with string concatenation prints the full
        // double value with all significant digits, matching the
        // expected output exactly.
        System.out.println("Perimeter is = " + perimeter);
        System.out.println("Area is = " + area);

        // ------------------------------------------------------------
        // STEP 5: (Optional) Print a formatted summary with labels
        // ------------------------------------------------------------
        // A formatted report makes the output easier to read and
        // demonstrates how to control decimal places with printf().
        // %.2f shows two decimal places (common for measurements in cm²).
        // ------------------------------------------------------------
        System.out.println();
        System.out.println("=== Circle Report ===");
        System.out.println("Radius       = " + radius);
        System.out.printf ("Perimeter    = %.2f%n", perimeter);
        System.out.printf ("Area         = %.2f%n", area);
        System.out.println("=====================");

        // ------------------------------------------------------------
        // Alternative: use Math.pow() instead of manual multiplication
        // (uncomment to use) — produces the same result but is slightly
        // slower and less idiomatic for squaring.
        // ------------------------------------------------------------
        // double area = Math.PI * Math.pow(radius, 2);
    }
}

