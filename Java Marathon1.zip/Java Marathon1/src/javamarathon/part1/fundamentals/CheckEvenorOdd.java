package javamarathon.part1.fundamentals;

import java.util.Scanner;

/**
 *
 * @author botho
 */
public class CheckEvenorOdd {

    public static void main(String[] args) {

        // ------------------------------------------------------------
        // STEP 1: Create a Scanner to read input from the keyboard
        // ------------------------------------------------------------
        // System.in is the standard input stream (the keyboard).
        // Scanner wraps it and provides convenient parsing methods.
        Scanner scanner = new Scanner(System.in);

        // ------------------------------------------------------------
        // STEP 2: Prompt the user and read the number
        // ------------------------------------------------------------
        // The expected output begins with:
        //   "Input a number: 20"
        //
        // We use print (not println) so the prompt and the user's input
        // appear on the same line, matching the expected output.
        System.out.print("Input a number: ");

        // nextInt() reads the next integer typed by the user.
        // If the user types something that is not an integer, an
        // InputMismatchException is thrown — we could catch it for
        // robustness, but for this exercise, we assume valid input.
        int number = scanner.nextInt();

        // ------------------------------------------------------------
        // STEP 3: Check whether the number is even or odd
        // ------------------------------------------------------------
        // The modulus operator '%' gives the remainder of division.
        //
        //   number % 2 == 0   →  even
        //   number % 2 != 0   →  odd
        //
        // We use an if/else to select the appropriate message.
        //
        // Note on the '==' comparison: '==' (double equals) tests
        // equality; '=' (single equals) would be assignment, which is
        // a compile error in this context.
        if (number % 2 == 0) {
            // ----------------------------------------------------
            // Even branch
            // ----------------------------------------------------
            // The expected output is "20 is even." — with a period
            // at the end. String concatenation joins the number, the
            // text " is even.", and produces the final message.
            System.out.println(number + " is even.");
        } else {
            // ----------------------------------------------------
            // Odd branch
            // ----------------------------------------------------
            // This branch is taken when number % 2 != 0, i.e., when
            // the number is odd. Included for completeness — the
            // given input (20) does not exercise it.
            System.out.println(number + " is odd.");
        }

        // ------------------------------------------------------------
        // STEP 4: Close the Scanner to release the underlying resource
        // ------------------------------------------------------------
        // Good practice: close the Scanner once we are done reading.
        scanner.close();

        // ------------------------------------------------------------
        // STEP 5: (Optional) Print additional information
        // ------------------------------------------------------------
        // Show the modulus result and a verification line so the
        // logic is transparent.
        System.out.println();
        System.out.println("Verification trace:");
        System.out.println("  number     = " + number);
        System.out.println("  number % 2 = " + (number % 2));
        System.out.println("  Even?      = " + (number % 2 == 0));
        System.out.println("  Odd?       = " + (number % 2 != 0));

        // ============================================================
        // ALTERNATIVE APPROACH 1 — Using the ternary operator
        // ============================================================
        // The if/else block can be collapsed into a single expression
        // using the ternary operator (? :):
        //
        //     condition ? valueIfTrue : valueIfFalse
        //
        // This is more compact for short branches, though less
        // readable when the branches become complex.
        // ============================================================
        String message = (number % 2 == 0)
                ? number + " is even."
                : number + " is odd.";
        System.out.println();
        System.out.println("Via ternary: " + message);

        // ============================================================
        // ALTERNATIVE APPROACH 2 — Using bitwise AND
        // ============================================================
        // The least significant bit (LSB) of a binary number is 0 for
        // even and 1 for odd. Bitwise AND with 1 isolates that bit:
        //
        //     (n & 1) == 0  →  even
        //     (n & 1) == 1  →  odd
        //
        // This is a fast, low-level alternative to modulus. On most
        // CPUs, it's marginally faster, but the difference is
        // negligible for typical applications. The modulus form is
        // more readable, so it's usually preferred.
        // ============================================================
        if ((number & 1) == 0) {
            System.out.println("Via bitwise AND: " + number + " is even.");
        } else {
            System.out.println("Via bitwise AND: " + number + " is odd.");
        }

        // ============================================================
        // ALTERNATIVE APPROACH 3 — Using Math.floorMod for negatives
        // ============================================================
        // Java's '%' operator can return negative results for negative
        // operands:
        //     -3 % 2 == -1   (not 1)
        // Math.floorMod(-3, 2) returns 1, which is mathematically
        // correct. If your program might receive negative inputs, use
        // floorMod to avoid subtle bugs:
        //
        //     Math.floorMod(n, 2) == 0  →  even
        //     Math.floorMod(n, 2) == 1  →  odd
        //
        // For non-negative inputs, both work identically.
        // ============================================================
        int safeMod = Math.floorMod(number, 2);
        System.out.println("Via floorMod: " + number
                + (safeMod == 0 ? " is even." : " is odd."));

        // ============================================================
        // ALTERNATIVE APPROACH 4 — Handling multiple numbers in a loop
        // ============================================================
        // If you want to check several numbers in sequence, put the
        // check inside a loop. The block below is commented out to
        // avoid interfering with the primary output.
        // ============================================================
        // System.out.println();
        // System.out.println("Checking 1 through 10:");
        // for (int i = 1; i <= 10; i++) {
        //     System.out.println("  " + i + (i % 2 == 0 ? " is even." : " is odd."));
        // }
        // ============================================================
        // ALTERNATIVE APPROACH 5 — Handling invalid input gracefully
        // ============================================================
        // Real-world programs should handle bad input. The block below
        // shows how to read an integer safely using hasNextInt():
        //
        //     System.out.print("Input a number: ");
        //     if (scanner.hasNextInt()) {
        //         int n = scanner.nextInt();
        //         System.out.println(n + (n % 2 == 0 ? " is even." : " is odd."));
        //     } else {
        //         System.out.println("Error: not a valid integer.");
        //     }
        // ============================================================
    }
}
