package javamarathon.part1.fundamentals;

/**
 *
 * @author botho
 */
public class CompareTwoNumbers {

    public static void main(String[] args) {

        // ------------------------------------------------------------
        // STEP 1: Declare and initialize the two numbers
        // ------------------------------------------------------------
        // Both are stored as 'int' because they are whole numbers.
        int a = 25;
        int b = 39;

        // ------------------------------------------------------------
        // STEP 2: Print a header to identify the inputs
        // ------------------------------------------------------------
        // This step is optional but makes the output self-explanatory.
        System.out.println("Comparing " + a + " and " + b + ":");
        System.out.println();

        // ============================================================
        // STEP 3: Apply each relational operator
        // ============================================================
        // We evaluate each comparison in turn. For each one, if the
        // result is true, we print the corresponding expression text.
        //
        // The pattern used throughout is:
        //     if (a <operator> b) {
        //         System.out.println(a + " <operator> " + b);
        //     }
        //
        // This matches the expected output style: only TRUE comparisons
        // are printed. If you wanted to print every comparison along
        // with its boolean result, you would use:
        //     System.out.println(a + " <operator> " + b + " → " + (a <operator> b));
        // ============================================================
        // ------------------------------------------------------------
        // OPERATOR 1: Equal to (==)
        // ------------------------------------------------------------
        // '==' checks whether the two values are identical.
        //   25 == 39  →  false, so nothing is printed.
        //
        // NOTE: '==' is NOT the same as '=' (single equals sign).
        //       '=' assigns a value; '==' compares two values.
        if (a == b) {
            System.out.println(a + " == " + b);
        }

        // ------------------------------------------------------------
        // OPERATOR 2: Not equal to (!=)
        // ------------------------------------------------------------
        // '!=' checks whether the two values are different.
        //   25 != 39  →  true, so "25 != 39" is printed.
        if (a != b) {
            System.out.println(a + " != " + b);
        }

        // ------------------------------------------------------------
        // OPERATOR 3: Greater than (>)
        // ------------------------------------------------------------
        // '>' checks whether the left value is strictly larger.
        //   25 > 39  →  false, so nothing is printed.
        if (a > b) {
            System.out.println(a + " > " + b);
        }

        // ------------------------------------------------------------
        // OPERATOR 4: Less than (<)
        // ------------------------------------------------------------
        // '<' checks whether the left value is strictly smaller.
        //   25 < 39  →  true, so "25 < 39" is printed.
        if (a < b) {
            System.out.println(a + " < " + b);
        }

        // ------------------------------------------------------------
        // OPERATOR 5: Greater than or equal to (>=)
        // ------------------------------------------------------------
        // '>=' checks whether the left value is larger or equal.
        //   25 >= 39  →  false, so nothing is printed.
        if (a >= b) {
            System.out.println(a + " >= " + b);
        }

        // ------------------------------------------------------------
        // OPERATOR 6: Less than or equal to (<=)
        // ------------------------------------------------------------
        // '<=' checks whether the left value is smaller or equal.
        //   25 <= 39  →  true, so "25 <= 39" is printed.
        if (a <= b) {
            System.out.println(a + " <= " + b);
        }

        // ------------------------------------------------------------
        // STEP 4: (Optional) Print ALL comparisons with their results
        // ------------------------------------------------------------
        // The required output only shows the TRUE comparisons, but for
        // learning purposes it helps to see every comparison alongside
        // its boolean result. Uncomment the block below to display them.
        // ------------------------------------------------------------
        // System.out.println();
        // System.out.println("Full comparison table:");
        // System.out.println("  " + a + " == " + b + "  →  " + (a == b));
        // System.out.println("  " + a + " != " + b + "  →  " + (a != b));
        // System.out.println("  " + a + " >  " + b + "  →  " + (a >  b));
        // System.out.println("  " + a + " <  " + b + "  →  " + (a <  b));
        // System.out.println("  " + a + " >= " + b + "  →  " + (a >= b));
        // System.out.println("  " + a + " <= " + b + "  →  " + (a <= b));
        // ------------------------------------------------------------
        // BONUS: Compare other types (char, double, String)
        // ------------------------------------------------------------
        // Relational operators work on characters (comparing their
        // Unicode values) and on numeric types like double. For
        // Strings, use .equals() and .compareTo() instead.
        // ------------------------------------------------------------
        // char c1 = 'A';           // Unicode 65
        // char c2 = 'a';           // Unicode 97
        // System.out.println(c1 < c2);   // true: 65 < 97
        //
        // double d1 = 3.14;
        // double d2 = 3.15;
        // System.out.println(d1 < d2);   // true
        //
        // String s1 = "apple";
        // String s2 = "banana";
        // System.out.println(s1.compareTo(s2) < 0);   // true (alphabetical)
    }
}

