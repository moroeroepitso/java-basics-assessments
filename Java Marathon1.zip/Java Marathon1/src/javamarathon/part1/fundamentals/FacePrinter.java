package javamarathon.part1.fundamentals;

/**
 *
 * @author botho
 */
public class FacePrinter {
  

    public static void main(String[] args) {

        // ------------------------------------------------------------
        // STEP 1: Print each line of the face
        // ------------------------------------------------------------
        // We use one println() per line. The pattern is fixed, so no
        // loops or variables are needed. This makes the code easy to
        // read and easy to modify if the face needs tweaking.

        // ---- Line 1: Top of the head (the "hair") ----
        // A '+' at each end and five double-quotes between them,
        // giving the impression of a curved fringe or hair.
        // The double-quote character is escaped with a backslash: \"
        System.out.println(" +\"\"\"\"\"+ ");

        // ---- Line 2: The eyes row ----
        // A '[' on the left, a '|' inside, two 'o' characters for eyes
        // separated by a space, a '|' on the right, and a ']' at the end.
        // This creates a pair of "goggles" or a face frame around the eyes.
        System.out.println("[| o o |]");

        // ---- Line 3: The nose row ----
        // A '|' on each side, with a '^' in the middle representing the nose.
        // Spaces around the '^' keep it centered.
        System.out.println(" |  ^  | ");

        // ---- Line 4: The mouth row ----
        // A '|' on each side, with a small mouth drawn using a single
        // quote (') and a dash (-) and another single quote, forming
        // the shape  '-'  which looks like a small smile or straight mouth.
        // Note: single quotes do NOT need escaping inside a double-quoted
        // Java string literal, but we could also write them as \' if we
        // wanted to be explicit.
        System.out.println(" | '-' | ");

        // ---- Line 5: The chin / bottom of the face ----
        // A '+' at each end and five dashes between them, closing the
        // box that forms the face.
        System.out.println(" +-----+ ");

        // ------------------------------------------------------------
        // ALTERNATIVE APPROACH — using a String[] array and a loop
        // (uncomment to use) — produces the same output but is more
        // concise when the number of lines grows.
        // ------------------------------------------------------------
        // String[] faceLines = {
        //     " +\"\"\"\"\"+ ",
        //     "[| o o |]",
        //     " |  ^  | ",
        //     " | '-' | ",
        //     " +-----+ "
        // };
        // for (String line : faceLines) {
        //     System.out.println(line);
        // }

        // ------------------------------------------------------------
        // ALTERNATIVE APPROACH — using printf() with %s placeholders
        // (uncomment to use) — useful if the lines need to be composed
        // from variables at runtime.
        // ------------------------------------------------------------
        // System.out.printf("%s%n", " +\"\"\"\"\"+ ");
        // System.out.printf("%s%n", "[| o o |]");
        // System.out.printf("%s%n", " |  ^  | ");
        // System.out.printf("%s%n", " | '-' | ");
        // System.out.printf("%s%n", " +-----+ ");
    }
}

