package javamarathon.part1.fundamentals;

/**
 *
 * @author botho
 */
public class ASCllValueFinder {

    public static void main(String[] args) {

        // ------------------------------------------------------------
        // STEP 1: Declare and initialize the character
        // ------------------------------------------------------------
        // Character literals in Java use SINGLE quotes: 'Z'.
        // (Double quotes "Z" would be a String, not a char.)
        //
        // The 'char' type stores a 16-bit Unicode code point. For
        // ASCII characters (0–127), the code point equals the ASCII
        // value, so this works cleanly.
        char character = 'Z';

        // ------------------------------------------------------------
        // STEP 2: Get the ASCII value
        // ------------------------------------------------------------
        // Two equivalent ways to convert char to int:
        //
        //   (a) Direct assignment (implicit widening conversion):
        //           int asciiValue = character;
        //
        //   (b) Explicit cast:
        //           int asciiValue = (int) character;
        //
        // Java's type system automatically promotes 'char' to 'int'
        // in numeric contexts, so both forms are valid. The direct
        // assignment is preferred for its brevity; the explicit cast
        // is sometimes used to make the conversion obvious.
        int asciiValue = character;

        // ------------------------------------------------------------
        // STEP 3: Print the result
        // ------------------------------------------------------------
        // The required output format is:
        //   "The ASCII value of Z is :90"
        //
        // Note: there is NO space between ':' and '90' in the expected
        // output — the colon is directly followed by the number.
        //
        // String concatenation is used to embed the char and int
        // values into the output line:
        //   - When a char is concatenated with a String, it is
        //     converted to its single-character representation.
        //   - When an int is concatenated with a String, it is
        //     converted to its decimal representation.
        System.out.println("The ASCII value of " + character + " is :" + asciiValue);

        // ------------------------------------------------------------
        // STEP 4: (Optional) Print a verification trace
        // ------------------------------------------------------------
        // Show the intermediate values to confirm the conversion.
        System.out.println();
        System.out.println("Verification trace:");
        System.out.println("  Character         : '" + character + "'");
        System.out.println("  ASCII / Unicode   : " + asciiValue);
        System.out.println("  In binary (7-bit) : "
                + String.format("%7s", Integer.toBinaryString(asciiValue)).replace(' ', '0'));
        System.out.println("  In hex            : 0x"
                + Integer.toHexString(asciiValue).toUpperCase());

        // ------------------------------------------------------------
        // STEP 5: (Optional) Show the full ASCII range for context
        // ------------------------------------------------------------
        // Print the ASCII table for the uppercase letters A–Z so the
        // user can see where 'Z' sits within the alphabet.
        System.out.println();
        System.out.println("ASCII values of A–Z (where 'Z' = 90 lives):");
        for (char c = 'A'; c <= 'Z'; c++) {
            System.out.printf("  '%c' = %d%n", c, (int) c);
        }

        // ============================================================
        // ALTERNATIVE APPROACHES
        // ============================================================
        // Below are several other ways to obtain the ASCII value of a
        // character, in case you encounter them in other references.
        // ============================================================
        // ------------------------------------------------------------
        // ALTERNATIVE 1 — Character.getNumericValue(char)
        // ------------------------------------------------------------
        // This method returns the numeric VALUE of a character when
        // it's used as a digit — for example, '5' returns 5, not 53.
        // For non-digit characters like 'Z', it returns −1 or the
        // character's Unicode digit value if it has one. Therefore,
        // this is NOT the right method for getting an ASCII value.
        int wrong = Character.getNumericValue('Z');
        System.out.println();
        System.out.println("(Note) Character.getNumericValue('Z') = " + wrong
                + " — NOT the ASCII value!");

        // ------------------------------------------------------------
        // ALTERNATIVE 2 — Casting back to char to verify round-trip
        // ------------------------------------------------------------
        // Convert the int back to a char to confirm the conversion is
        // lossless.
        char restored = (char) asciiValue;
        System.out.println("Round-trip check: (char) " + asciiValue
                + " = '" + restored + "' (matches original: "
                + (restored == character) + ")");

        // ------------------------------------------------------------
        // ALTERNATIVE 3 — Casting to byte for a compact representation
        // ------------------------------------------------------------
        // Because ASCII values fit in 7 bits, they also fit in a byte
        // (8 bits signed). For values 0–127, no overflow occurs.
        byte asciiByte = (byte) character;
        System.out.println("As byte value: " + asciiByte + " (same as int: "
                + (asciiByte == asciiValue) + ")");

        // ------------------------------------------------------------
        // BONUS — Try more characters
        // ------------------------------------------------------------
        // Uncomment the block below to see the ASCII values of various
        // characters. This is a great way to explore the ASCII table.
        // ------------------------------------------------------------
        // System.out.println();
        // System.out.println("More character values:");
        // char[] samples = {'A', 'a', '0', '9', ' ', '!', '@', '~', '\n', '\t'};
        // for (char c : samples) {
        //     System.out.printf("  '%s' = %d%n",
        //             c == '\n' ? "\\n" : (c == '\t' ? "\\t" : String.valueOf(c)),
        //             (int) c);
        // }
    }
}
