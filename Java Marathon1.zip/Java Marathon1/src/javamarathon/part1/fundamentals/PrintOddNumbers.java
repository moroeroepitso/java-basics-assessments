package javamarathon.part1.fundamentals;

/**
 *
 * @author botho
 */
public class PrintOddNumbers {

    public static void main(String[] args) {

        // ============================================================
        // APPROACH 1 — Step by 2 (RECOMMENDED)
        // ============================================================
        // This loop starts at 1 and increments by 2 on each iteration.
        // The sequence of values is: 1, 3, 5, 7, ..., 97, 99.
        // Every value is odd by construction, so no check is needed.
        //
        // This is the cleanest and most efficient approach:
        //   - 50 iterations (one per odd number)
        //   - No modulus operation
        //   - No conditional inside the loop
        //
        // Loop mechanics:
        //   int i = 1     → start at the first odd number
        //   i <= 99       → continue while i is at most 99
        //   i += 2        → add 2 (equivalent to i = i + 2)
        System.out.println("--- Method 1: Step by 2 ---");
        for (int i = 1; i <= 99; i += 2) {
            System.out.println(i);
        }

        // ------------------------------------------------------------
        // SEPARATOR between the two methods (optional)
        // ------------------------------------------------------------
        System.out.println();
        System.out.println("--- Method 2: Modulus check ---");

        // ============================================================
        // APPROACH 2 — Modulus check
        // ============================================================
        // This loop visits every integer from 1 to 99, and prints only
        // the odd ones. A number is odd if i % 2 != 0 (i.e., the
        // remainder when divided by 2 is 1).
        //
        // This is slightly less efficient than Method 1 because it
        // iterates 99 times (vs. 50) and performs a modulus check on
        // each iteration. But it generalizes better when the numbers
        // you want aren't a simple arithmetic sequence (e.g., "print
        // numbers divisible by 3 or 5").
        //
        // Loop mechanics:
        //   int i = 1     → start at 1
        //   i <= 99       → continue while i is at most 99
        //   i++           → increment by 1 (i = i + 1)
        //
        // Inside the loop:
        //   if (i % 2 != 0)  →  true when i is odd
        for (int i = 1; i <= 99; i++) {
            if (i % 2 != 0) {
                System.out.println(i);
            }
        }

        // ============================================================
        // STEP 3: (Optional) Verification — count the odd numbers
        // ============================================================
        // A quick check that we printed exactly 50 odd numbers:
        //   (99 − 1) / 2 + 1 = 50
        //
        // We can also confirm that the first and last values are 1 and
        // 99, and that all values satisfy i % 2 != 0.
        System.out.println();
        System.out.println("--- Verification ---");

        int count = 0;
        int first = -1;
        int last = -1;
        boolean allOdd = true;

        // Method 1 loop, instrumented for verification.
        for (int i = 1; i <= 99; i += 2) {
            if (first == -1) {
                first = i;
            }
            last = i;
            count++;
            if (i % 2 == 0) {
                allOdd = false;
            }
        }

        System.out.println("  Total count : " + count);
        System.out.println("  First value : " + first);
        System.out.println("  Last value  : " + last);
        System.out.println("  All odd?    : " + allOdd);

        // ============================================================
        // ALTERNATIVE — Using a while loop
        // ============================================================
        // The for loop is idiomatic for a fixed range, but a while
        // loop works too. The initialization is moved outside, and
        // the update is moved into the loop body.
        // ============================================================
        // int i = 1;
        // while (i <= 99) {
        //     System.out.println(i);
        //     i += 2;
        // }
        // ============================================================
        // ALTERNATIVE — Using Java streams (Java 8+)
        // ============================================================
        // A functional approach using IntStream.rangeClosed to
        // generate 1..99, filter for odds, and print each one.
        // Concise but less obvious to beginners.
        // ============================================================
        // java.util.stream.IntStream.rangeClosed(1, 99)
        //         .filter(n -> n % 2 != 0)
        //         .forEach(System.out::println);
        // ============================================================
        // ALTERNATIVE — Collecting into a list
        // ============================================================
        // If the numbers need to be stored (not just printed), use a
        // List<Integer>. The modulus approach is shown here to keep
        // the sequence obvious.
        // ============================================================
        java.util.List<Integer> odds = new java.util.ArrayList<>();
        for (int i = 1; i <= 99; i += 2) {
            odds.add(i);
        }
        System.out.println();
        System.out.println("Collected into a list:");
        System.out.println("  " + odds);

        // ============================================================
        // ALTERNATIVE — Print on a single line, space-separated
        // ============================================================
        // Some exercises want all values on one line. To do that,
        // use print() (not println()), and add spaces between values.
        // A trailing newline is added at the very end.
        // ============================================================
        System.out.println();
        System.out.println("All odd numbers on one line:");
        for (int i = 1; i <= 99; i += 2) {
            System.out.print(i);
            if (i < 99) {
                System.out.print(" ");
            }
        }
        System.out.println();   // final newline
    }
}
