package javamarathon.part1.fundamentals;

/**
 *
 * @author 2128087
 */
public class LengthofLastWord {

    public static int lengthOfLastWord(String s) {
        // Trim trailing spaces to avoid counting them
        s = s.trim();
        // Find last space index
        int lastSpace = s.lastIndexOf(' ');
        // Length is from after last space to end
        return s.length() - lastSpace - 1;
    }

    public static void main(String[] args) {
        String input = "The length of last word";
        int result = lengthOfLastWord(input);
        System.out.println("Length of last word: " + result); // Output: 4
    }
}
