package javamarathon.part1.fundamentals;

/**
 *
 * @author botho
 */
public class ReverseaString {

    public static void main(String[] args) {

        // ------------------------------------------------------------
        // STEP 1: Declare and initialize the original string
        // ------------------------------------------------------------
        // The string is stored in a variable of type String. Note the
        // capital 'S' — String is a class, not a primitive type.
        String original = "The quick brown fox";

        // ------------------------------------------------------------
        // STEP 2: Reverse the string using the built-in method
        // ------------------------------------------------------------
        // StringBuilder is a mutable sequence of characters. Its
        // reverse() method reverses the sequence in place and returns
        // the same StringBuilder for chaining.
        //
        // The pattern is:
        //     new StringBuilder(original).reverse().toString()
        //
        //   - 'new StringBuilder(original)'  creates a StringBuilder
        //     with a copy of the original string's characters.
        //   - '.reverse()'                    reverses the sequence.
        //   - '.toString()'                   converts back to a String.
        //
        // This is the recommended approach: concise, efficient, and
        // handles all characters correctly in practice.
        String reversed = new StringBuilder(original).reverse().toString();

        // ------------------------------------------------------------
        // STEP 3: Print the result
        // ------------------------------------------------------------
        // The required output format is:
        //   "Reverse string: xof nworb kciuq ehT"
        System.out.println("Reverse string: " + reversed);

        // ------------------------------------------------------------
        // STEP 4: (Optional) Verify the reversal is correct
        // ------------------------------------------------------------
        // A nice sanity check: reversing the reversed string should
        // give back the original. If they don't match, something is
        // wrong with the reverse logic.
        System.out.println();
        System.out.println("Verification:");
        System.out.println("  Original              : " + original);
        System.out.println("  Reversed              : " + reversed);
        System.out.println("  Double-reversed       : "
                + new StringBuilder(reversed).reverse().toString());
        System.out.println("  Matches original?     : "
                + original.equals(
                        new StringBuilder(reversed).reverse().toString()));

        // ------------------------------------------------------------
        // STEP 5: (Optional) Show the reversal character by character
        // ------------------------------------------------------------
        // Walking through the string from the end to the beginning and
        // printing each character makes it obvious how the reversal
        // works.
        System.out.println();
        System.out.println("Character-by-character (right to left):");
        for (int i = original.length() - 1; i >= 0; i--) {
            System.out.print(original.charAt(i));
        }
        System.out.println();  // newline at the end

        // ============================================================
        // ALTERNATIVE METHOD 1 — Using a char array (in-place swap)
        // ============================================================
        // Convert the string to a char array, then swap characters
        // using two pointers moving toward each other:
        //
        //   - 'left'  starts at index 0 (the first character).
        //   - 'right' starts at index length − 1 (the last character).
        //   - While left < right:
        //       swap chars[left] and chars[right]
        //       left++; right--;
        //
        // When left meets or passes right, the array is reversed.
        //
        // WORKING TRACE on a small example, "abc":
        //   Before: [a, b, c]  left=0, right=2
        //   Swap 0 and 2:  [c, b, a]  left=1, right=1
        //   left < right is false → stop.
        //   Result: "cba"  ✓
        char[] chars = original.toCharArray();
        int left = 0;
        int right = chars.length - 1;
        while (left < right) {
            // Classic three-step swap using a temporary variable.
            char temp = chars[left];
            chars[left] = chars[right];
            chars[right] = temp;

            left++;
            right--;
        }
        String reversedBySwap = new String(chars);

        System.out.println();
        System.out.println("Reversed (via char-array swap) : " + reversedBySwap);

        // ============================================================
        // ALTERNATIVE METHOD 2 — Using a loop with concatenation
        // ============================================================
        // Iterate from the last character to the first, appending each
        // character to a result string. This is simple and readable
        // but inefficient for large strings because String is
        // immutable — every "+=" creates a new String object.
        //
        // For small strings this is fine. For larger ones, prefer
        // StringBuilder (which we use here for efficiency).
        StringBuilder reversedByLoop = new StringBuilder();
        for (int i = original.length() - 1; i >= 0; i--) {
            reversedByLoop.append(original.charAt(i));
        }

        System.out.println("Reversed (via reverse loop)    : " + reversedByLoop);

        // ============================================================
        // ALTERNATIVE METHOD 3 — Recursive approach
        // ============================================================
        // A recursive reverse works by taking the first character and
        // appending it to the end of the recursively reversed rest:
        //
        //     reverse("abc") = reverse("bc") + "a"
        //                    = (reverse("c") + "b") + "a"
        //                    = ("c") + "b" + "a"
        //                    = "cba"
        //
        // This is elegant but inefficient (O(n²) due to substring
        // copies) and risks StackOverflowError on very long strings.
        // Included here for completeness.
        System.out.println();
        System.out.println("Reversed (via recursion)       : " + reverseRecursive(original));

        // ------------------------------------------------------------
        // BONUS: Handle other scenarios
        // ------------------------------------------------------------
        // Test the same reversal on strings of different kinds to see
        // how it behaves. Uncomment the block below to explore.
        // ------------------------------------------------------------
        // System.out.println();
        // System.out.println("More examples:");
        // System.out.println("  \"\"                → \"" + reverse("") + "\"");
        // System.out.println("  \"a\"               → \"" + reverse("a") + "\"");
        // System.out.println("  \"racecar\"         → \"" + reverse("racecar") + "\"");
        // System.out.println("  \"Hello, World!\"   → \"" + reverse("Hello, World!") + "\"");
        // System.out.println("  \"12345\"           → \"" + reverse("12345") + "\"");
    }

    /**
     * Reverses a string using StringBuilder — the recommended approach.
     *
     * This helper is used in the bonus section to test multiple strings without
     * duplicating the logic.
     *
     * @param s the string to reverse
     * @return a new string with the characters of s in reverse order
     */
    private static String reverse(String s) {
        if (s == null) {
            return null;
        }
        return new StringBuilder(s).reverse().toString();
    }

    /**
     * Reverses a string recursively.
     *
     * Base case: an empty string (or a string of length 1) is its own reverse.
     * Recursive case: reverse the substring from index 1 to the end, then
     * append the first character at the end.
     *
     * This method is provided for educational purposes; the iterative
     * StringBuilder approach is preferred in production code.
     *
     * @param s the string to reverse
     * @return the reversed string
     */
    private static String reverseRecursive(String s) {
        if (s == null || s.length() <= 1) {
            return s;
        }
        return reverseRecursive(s.substring(1)) + s.charAt(0);
    }
}
