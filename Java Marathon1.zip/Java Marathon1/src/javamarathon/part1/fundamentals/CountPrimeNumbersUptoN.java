package javamarathon.part1.fundamentals;

import java.util.Scanner;

/**
 *
 * @author botho
 */
public class CountPrimeNumbersUptoN {

    public static void main(String[] args) {

        Scanner scanner = new Scanner(System.in);

        System.out.println("Input the number(n):");
        int n = scanner.nextInt();
        scanner.close();

        // Handle edge case: no primes less than 2
        if (n < 2) {
            System.out.println("Number of prime numbers which are less than or equal to n.:");
            System.out.println(0);
            return;
        }

        // Sieve of Eratosthenes
        boolean[] isPrime = new boolean[n + 1];
        // Initialize all numbers >= 2 as prime
        for (int i = 2; i <= n; i++) {
            isPrime[i] = true;
        }

        // Mark non-primes
        for (int p = 2; p * p <= n; p++) {
            if (isPrime[p]) {
                // Mark multiples of p starting from p*p
                for (int multiple = p * p; multiple <= n; multiple += p) {
                    isPrime[multiple] = false;
                }
            }
        }

        // Count primes
        int count = 0;
        for (int i = 2; i <= n; i++) {
            if (isPrime[i]) {
                count++;
            }
        }

        System.out.println("Number of prime numbers which are less than or equal to n.:");
        System.out.println(count);
    }
}
