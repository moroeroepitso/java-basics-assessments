package javamarathon.part1.fundamentals;
import java.util.Scanner;
/**
 *
 * 2128087 pitso moroeroe
 */
public class AverageofThreeNumbers {



    public static void main(String[] args) {

        // ------------------------------------------------------------
        // STEP 1: Create a Scanner to read input from the keyboard
        // ------------------------------------------------------------
        // System.in is the standard input stream (the keyboard).
        // The Scanner class provides convenient methods to parse input.
        Scanner scanner = new Scanner(System.in);

        // ------------------------------------------------------------
        // STEP 2: Prompt the user and read the three numbers
        // ------------------------------------------------------------
        // Using nextDouble() allows the user to enter either whole
        // numbers (e.g., 10) or decimal numbers (e.g., 10.5), and both
        // will be handled correctly.
        System.out.print("Enter first number: ");
        double num1 = scanner.nextDouble();

        System.out.print("Enter second number: ");
        double num2 = scanner.nextDouble();

        System.out.print("Enter third number: ");
        double num3 = scanner.nextDouble();

        // ------------------------------------------------------------
        // STEP 3: Compute the average
        // ------------------------------------------------------------
        // Formula:  Average = (num1 + num2 + num3) / 3
        //
        // Step-by-step trace with the given values:
        //   num1 + num2 + num3 = 10 + 20 + 30  = 60
        //   60 / 3                              = 20.0
        //
        // Parentheses around the sum ensure that addition happens
        // BEFORE division. Without them, the expression would be
        // interpreted as:  num1 + num2 + (num3 / 3) = 10 + 20 + 10 = 40,
        // which is clearly wrong.
        double average = (num1 + num2 + num3) / 3;

        // ------------------------------------------------------------
        // STEP 4: Print the result
        // ------------------------------------------------------------
        // Two output styles are shown below:
        //   a) Simple concatenation — prints "20.0" for the given input.
        //   b) Formatted with %g — suppresses trailing ".0" and matches
        //      the expected output "20" exactly.
        //
        // The problem's expected output is "Average of three numbers is: 20"
        // so we use the formatted version to get a clean integer display
        // when the average is a whole number, while still showing decimals
        // when the average is fractional.

        System.out.println("Average of three numbers is: " + formatNumber(average));

        // ------------------------------------------------------------
        // STEP 5: Close the Scanner to release the underlying resource
        // ------------------------------------------------------------
        // Good practice: close the Scanner once we are done reading input.
        scanner.close();

        // ------------------------------------------------------------
        // Alternative output methods (uncomment to use one of these)
        // ------------------------------------------------------------
        // (a) Plain concatenation (prints "20.0"):
        // System.out.println("Average of three numbers is: " + average);
        //
        // (b) printf with %g (prints "20.0000" or "20"):
        // System.out.printf("Average of three numbers is: %g%n", average);
        //
        // (c) printf with %.2f (always prints two decimals, e.g., "20.00"):
        // System.out.printf("Average of three numbers is: %.2f%n", average);
    }

    /**
     * Helper method that formats a double for display.
     * 
     * If the value has no fractional part (e.g., 20.0), it is displayed
     * as an integer ("20"). Otherwise, the full decimal value is shown
     * (e.g., 21.666666666666668).
     * 
     * This is useful for the "Average of three numbers" exercise because
     * the expected output shows "20" rather than "20.0".
     * 
     * @param value the double to format
     * @return a clean string representation of the value
     */
    private static String formatNumber(double value) {
        // Check whether the value is a whole number:
        //   Math.floor(value) returns the largest integer <= value.
        //   If floor(value) == value, then value has no fractional part.
        if (value == Math.floor(value) && !Double.isInfinite(value)) {
            // Cast to long and convert to String to drop the ".0".
            return String.valueOf((long) value);
        }
        // Otherwise, return the default double string representation.
        return String.valueOf(value);
    }
} 

