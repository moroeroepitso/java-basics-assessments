package javamarathon.part1.fundamentals;

/**
 *
 * @author botho
 */
public class PowerandSquareRoot {
      public static void main(String[] args) {


  

        // ------------------------------------------------------------
        // STEP 1: Declare and initialize the input variables
        // ------------------------------------------------------------
        // 'base' represents the number that will be multiplied by itself.
        // Stored as a double because Math.pow() operates on doubles.
        double base = 2;

        // 'exponent' represents how many times the base is multiplied by itself.
        // Stored as a double to match the signature of Math.pow().
        double exponent = 10;

        // 'number' is the value for which we want to calculate the square root.
        // Stored as a double because Math.sqrt() accepts and returns a double.
        double number = 81;

        // ------------------------------------------------------------
        // STEP 2: Calculate the power using Math.pow()
        // ------------------------------------------------------------
        // Math.pow(a, b) returns 'a' raised to the power of 'b' (i.e., a^b).
        // It always returns a 'double', even when both arguments are integers.
        // Here: Math.pow(2, 10) = 2 * 2 * 2 * 2 * 2 * 2 * 2 * 2 * 2 * 2 = 1024.0
        double powerResult = Math.pow(base, exponent);

        // ------------------------------------------------------------
        // STEP 3: Calculate the square root using Math.sqrt()
        // ------------------------------------------------------------
        // Math.sqrt(x) returns the positive square root of 'x'.
        // It also returns a 'double'. Passing a negative number would
        // result in NaN (Not a Number) since real square roots of
        // negative values are undefined.
        // Here: Math.sqrt(81) = 9.0, because 9 * 9 = 81.
        double squareRootResult = Math.sqrt(number);

        // ------------------------------------------------------------
        // STEP 4: Display the results to the console
        // ------------------------------------------------------------
        // We use printf() for clean, formatted output:
        //   - %.0f formats a floating-point number with zero decimal places
        //     for the base/exponent display (e.g., 2 instead of 2.0).
        //   - %.1f formats a floating-point number with one decimal place
        //     to clearly show the returned double value (e.g., 1024.0).
        //   - %n inserts a platform-independent newline character.
        System.out.printf("%.0f ^ %.0f = %.1f%n", base, exponent, powerResult);
        System.out.printf("Square root of %.0f = %.1f%n", number, squareRootResult);

        // ------------------------------------------------------------
        // Alternative simpler display (uncomment to use):
        // This version relies on Java's default double-to-String conversion,
        // which already appends ".0" to whole-number doubles.
        // ------------------------------------------------------------
        // System.out.println(base + " ^ " + exponent + " = " + powerResult);
        // System.out.println("Square root of " + number + " = " + squareRootResult);
    }
}