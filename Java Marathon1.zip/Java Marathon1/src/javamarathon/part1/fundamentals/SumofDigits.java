package javamarathon.part1.fundamentals;

/**
 *
 * @author botho
 */
public class SumofDigits {

    public static void main(String[] args) {

        // ------------------------------------------------------------
        // STEP 1: Declare and initialize the number
        // ------------------------------------------------------------
        // Stored as an 'int' since the input is a whole number.
        int number = 700;

        // ------------------------------------------------------------
        // STEP 2: Compute the sum of digits
        // ------------------------------------------------------------
        // We call a helper method that performs the digit extraction
        // using the % and / operators. Keeping the logic in a method
        // makes the main method cleaner and the algorithm reusable.
        int sum = sumOfDigits(number);

        // ------------------------------------------------------------
        // STEP 3: Print the result
        // ------------------------------------------------------------
        // The required output format is:
        //   "The sum of the digits is: 7"
        System.out.println("The sum of the digits is: " + sum);

        // ------------------------------------------------------------
        // STEP 4: (Optional) Print a verification trace
        // ------------------------------------------------------------
        // Showing the intermediate steps helps confirm the algorithm
        // works and provides a useful learning reference.
        System.out.println();
        System.out.println("Verification trace for number = " + number + ":");
        traceDigitExtraction(number);

        // ------------------------------------------------------------
        // BONUS: Try more examples to confirm the logic
        // ------------------------------------------------------------
        // Uncomment the lines below to test other numbers.
        // ------------------------------------------------------------
        // System.out.println("\nMore examples:");
        // System.out.println("  0      → " + sumOfDigits(0));         // 0
        // System.out.println("  9      → " + sumOfDigits(9));         // 9
        // System.out.println("  123    → " + sumOfDigits(123));       // 6
        // System.out.println("  999    → " + sumOfDigits(999));       // 27
        // System.out.println("  1000   → " + sumOfDigits(1000));      // 1
        // System.out.println("  12345  → " + sumOfDigits(12345));     // 15
        // System.out.println("  700    → " + sumOfDigits(700));       // 7
    }

    /**
     * Computes the sum of the decimal digits of a non-negative integer.
     *
     * Algorithm: Repeatedly extract the rightmost digit using '% 10', add it to
     * a running total, then remove that digit using '/ 10'. Stop when the
     * number becomes 0.
     *
     * @param n the number whose digits should be summed (must be >= 0)
     * @return the sum of the digits of n
     */
    private static int sumOfDigits(int n) {

        // Special case: the sum of digits of 0 is 0.
        // Without this check, the loop below would not execute at all
        // (since n is not > 0), and we would return 0 anyway — so this
        // check is mostly for clarity.
        if (n == 0) {
            return 0;
        }

        // 'sum' holds the running total of digit values.
        int sum = 0;

        // Work on a copy of the input so the original is not modified.
        int remaining = n;

        // Loop until all digits have been extracted.
        while (remaining > 0) {

            // '% 10' returns the rightmost digit (0–9).
            int digit = remaining % 10;

            // Add the digit to the running sum.
            sum = sum + digit;

            // '/ 10' removes the rightmost digit by integer division.
            // E.g., 700 / 10 = 70, then 70 / 10 = 7, then 7 / 10 = 0.
            remaining = remaining / 10;
        }

        // Return the accumulated sum.
        return sum;
    }

    /**
     * Prints a step-by-step trace of the digit-extraction process for
     * teaching/debugging purposes. This method does not affect the computation
     * — it only displays the intermediate values.
     *
     * @param n the number whose digit extraction to trace
     */
    private static void traceDigitExtraction(int n) {

        // Handle the special case of n = 0.
        if (n == 0) {
            System.out.println("  number = 0, no digits to extract, sum = 0");
            return;
        }

        int remaining = n;
        int sum = 0;
        int step = 1;

        while (remaining > 0) {
            int digit = remaining % 10;
            int newSum = sum + digit;

            System.out.printf("  Step %d: digit = %d %% 10 = %d, "
                    + "sum = %d + %d = %d, remaining = %d / 10 = %d%n",
                    step, remaining, digit, sum, digit, newSum,
                    remaining, remaining / 10);

            sum = newSum;
            remaining = remaining / 10;
            step++;
        }

        System.out.println("  Final sum = " + sum);
    }
}
