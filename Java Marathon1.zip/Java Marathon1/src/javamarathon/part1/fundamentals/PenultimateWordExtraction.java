package javamarathon.part1.fundamentals;

import java.util.Scanner;

/**
 *
 * @author botho
 */
public class PenultimateWordExtraction {

    public static void main(String[] args) {

        // ------------------------------------------------------------
        // STEP 1: Create a Scanner to read input from the keyboard
        // ------------------------------------------------------------
        Scanner scanner = new Scanner(System.in);

        // ------------------------------------------------------------
        // STEP 2: Prompt for and read the sentence
        // ------------------------------------------------------------
        // The prompt matches the expected output:
        //   "Input a String: The quick brown fox jumps over the lazy dog."
        //
        // We use print() (not println()) so the user's typed sentence
        // appears on the same line as the prompt.
        //
        // nextLine() reads the entire line — this is essential for
        // sentences with spaces. next() would stop at the first space.
        System.out.print("Input a String: ");
        String sentence = scanner.nextLine();

        // ------------------------------------------------------------
        // STEP 3: Extract the penultimate word
        // ------------------------------------------------------------
        // We call a helper method that handles all the splitting,
        // indexing, and edge-case logic. Keeping it separate makes
        // the main method clean and the logic reusable.
        String penultimate = getPenultimateWord(sentence);

        // ------------------------------------------------------------
        // STEP 4: Print the result
        // ------------------------------------------------------------
        // The expected output format is:
        //   "Penultimate word: lazy"
        //
        // If no penultimate word exists (fewer than 2 words), the
        // helper returns a descriptive message instead of null.
        System.out.println("Penultimate word: " + penultimate);

        // ------------------------------------------------------------
        // STEP 5: Close the Scanner
        // ------------------------------------------------------------
        scanner.close();

        // ------------------------------------------------------------
        // STEP 6: (Optional) Verification trace
        // ------------------------------------------------------------
        // Show the words array and indices to illustrate how the
        // penultimate word is located.
        System.out.println();
        System.out.println("Verification trace:");

        if (sentence == null || sentence.trim().isEmpty()) {
            System.out.println("  (empty or blank sentence)");
        } else {
            // Split on one or more whitespace characters.
            String[] words = sentence.split("\\s+");
            System.out.println("  Total words: " + words.length);
            System.out.println("  Word list:");
            for (int i = 0; i < words.length; i++) {
                String tag = "";
                if (i == words.length - 1) {
                    tag = "   ← last (ultimate)";
                } else if (i == words.length - 2) {
                    tag = "   ← penultimate";
                }
                System.out.printf("    words[%d] = \"%s\"%s%n", i, words[i], tag);
            }

            if (words.length >= 2) {
                System.out.println("  Penultimate index: words.length - 2 = "
                        + (words.length - 2));
                System.out.println("  Penultimate word : \"" + words[words.length - 2] + "\"");
            } else {
                System.out.println("  Fewer than 2 words — no penultimate word.");
            }
        }

        // ============================================================
        // ALTERNATIVE 1 — Static version (non-interactive)
        // ============================================================
        String staticSentence = "The quick brown fox jumps over the lazy dog.";
        System.out.println();
        System.out.println("Static version:");
        System.out.println("  Sentence          : " + staticSentence);
        System.out.println("  Penultimate word  : " + getPenultimateWord(staticSentence));

        // ============================================================
        // ALTERNATIVE 2 — Inline extraction without a helper
        // ============================================================
        // If you prefer not to use a helper method, the same logic
        // fits in a few lines:
        //
        //     String[] words = sentence.trim().split("\\s+");
        //     String penultimate = (words.length >= 2)
        //             ? words[words.length - 2]
        //             : "(no penultimate word)";
        //
        // The helper method just packages this so it's reusable.
        // ============================================================
        // ============================================================
        // ALTERNATIVE 3 — Using a list and List.get
        // ============================================================
        // If you prefer working with List<Integer> to Arrays, the same
        // logic works with an ArrayList:
        //
        //     List<String> words = Arrays.asList(sentence.trim().split("\\s+"));
        //     String penultimate = (words.size() >= 2)
        //             ? words.get(words.size() - 2)
        //             : "(no penultimate word)";
        //
        // This is stylistically different but functionally identical.
        // ============================================================
        java.util.List<String> wordList
                = java.util.Arrays.asList(sentence.trim().split("\\s+"));
        String penultimateViaList = (wordList.size() >= 2)
                ? wordList.get(wordList.size() - 2)
                : "(no penultimate word)";

        System.out.println();
        System.out.println("Via ArrayList:");
        System.out.println("  Penultimate word  : " + penultimateViaList);

        // ============================================================
        // ALTERNATIVE 4 — Using StringTokenizer (legacy API)
        // ============================================================
        // Before split(), the standard way to tokenize a string was
        // StringTokenizer. It's still available but considered legacy.
        // Shown here for completeness:
        //
        //     StringTokenizer st = new StringTokenizer(sentence);
        //     String prev = null, curr = null;
        //     while (st.hasMoreTokens()) {
        //         prev = curr;
        //         curr = st.nextToken();
        //     }
        //     // After the loop, 'prev' is the penultimate token.
        // ============================================================
        java.util.StringTokenizer tokenizer = new java.util.StringTokenizer(sentence);
        String prev = null;
        String curr = null;
        while (tokenizer.hasMoreTokens()) {
            prev = curr;
            curr = tokenizer.nextToken();
        }
        String penultimateViaTokenizer = (prev != null) ? prev : "(no penultimate word)";

        System.out.println("Via StringTokenizer:");
        System.out.println("  Penultimate word  : " + penultimateViaTokenizer);

        // ============================================================
        // ALTERNATIVE 5 — Trailing-punctuation-aware version
        // ============================================================
        // The simple approach splits on whitespace, so punctuation
        // stays attached to words: "dog." remains "dog." rather than
        // becoming "dog". If we want to strip punctuation from the
        // penultimate word, we can do it with a simple character
        // filter. This is shown for completeness; for the given
        // sentence, the penultimate word "lazy" has no punctuation
        // anyway.
        // ============================================================
        String penultimateClean = stripTrailingPunctuation(penultimate);
        System.out.println();
        System.out.println("With trailing punctuation stripped:");
        System.out.println("  Penultimate word  : " + penultimateClean);

        // ============================================================
        // ALTERNATIVE 6 — Testing multiple inputs
        // ============================================================
        // A test sweep over varied inputs confirms the logic handles
        // edge cases properly.
        System.out.println();
        System.out.println("Test sweep:");
        String[] tests = {
            "The quick brown fox jumps over the lazy dog.",
            "hello world",
            "one two three four five",
            "just one word",
            "   spaced   out   words   ",
            "a b",
            "hello",
            "",
            "   ",
            "The end."
        };
        for (String test : tests) {
            String result = getPenultimateWord(test);
            System.out.printf("  %-45s → %s%n",
                    "\"" + test + "\"", "\"" + result + "\"");
        }
    }

    /**
     * Extracts the penultimate (second-to-last) word from a sentence.
     *
     * The sentence is split on one or more whitespace characters. If the
     * sentence contains at least two words, the penultimate word is at index
     * (length − 2). Otherwise a descriptive message is returned.
     *
     * @param sentence the sentence to process (may be null or empty)
     * @return the penultimate word, or a descriptive message if fewer than 2
     * words are present
     */
    private static String getPenultimateWord(String sentence) {
        // Guard against null or blank input.
        if (sentence == null || sentence.trim().isEmpty()) {
            return "(no penultimate word)";
        }

        // Split on whitespace. The trim() handles leading/trailing
        // whitespace; the "\\s+" handles multiple internal spaces.
        String[] words = sentence.trim().split("\\s+");

        // If there are fewer than 2 words, there is no penultimate.
        if (words.length < 2) {
            return "(no penultimate word)";
        }

        // Return the second-to-last word.
        return words[words.length - 2];
    }

    /**
     * Removes trailing punctuation from a word: periods, commas, exclamation
     * marks, question marks, colons, semicolons.
     *
     * For example, "dog." becomes "dog". This is a small utility for cleaning
     * up word tokens that may carry trailing punctuation from a sentence.
     *
     * @param word the word to clean (may be null or empty)
     * @return the word with trailing punctuation removed
     */
    private static String stripTrailingPunctuation(String word) {
        if (word == null) {
            return null;
        }
        int end = word.length();
        while (end > 0 && ".,!?;:'\"".indexOf(word.charAt(end - 1)) >= 0) {
            end--;
        }
        return word.substring(0, end);
    }
}
