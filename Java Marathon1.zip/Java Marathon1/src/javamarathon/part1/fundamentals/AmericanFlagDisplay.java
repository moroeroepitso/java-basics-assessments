
package javamarathon.part1.fundamentals;

/**
 *
 * 2128087
 */
public class AmericanFlagDisplay {
  

    public static void main(String[] args) {

        // ------------------------------------------------------------
        // STEP 1: Define the dimensions and building blocks
        // ------------------------------------------------------------
        // Based on the expected output:
        //   - The star field (canton) occupies the LEFT portion of the
        //     first 9 rows. Its width is 13 characters
        //     ("* * * * * *" or " * * * * * ").
        //   - The stripe field occupies the RIGHT portion of those 9 rows
        //     and is 34 '=' characters wide.
        //   - The final 6 rows are 47 '=' characters wide (full width).
        //
        // We construct each row by concatenating a left star-field
        // segment with a right stripe-field segment.

        // The star field used on ODD-numbered rows (0-indexed: 0, 2, 4, 6, 8).
        // Pattern: "* * * * * *" — 6 stars each followed by a space,
        // then a leading space to align with the even rows.
        // Length check: "* * * * * * " = 6 stars + 6 spaces = 12 chars,
        // plus one leading space from concatenation arrangement.
        String starFieldOddRow  = "* * * * * * ";   // 12 characters

        // The star field used on EVEN-numbered rows (0-indexed: 1, 3, 5, 7).
        // Pattern: " * * * * * " — offset by one space for the staggered look.
        String starFieldEvenRow = " * * * * *  ";   // 12 characters

        // The stripe field that sits to the right of the star field in
        // the top 9 rows. This is 34 '=' characters.
        String stripeFieldRight = "=================================="; // 34 chars

        // The full-width stripe used for the bottom 6 rows.
        // This is 46 '=' characters (star field 12 + stripe field 34 = 46).
        String stripeFieldFull  = "=============================================="; // 46 chars

        // ------------------------------------------------------------
        // STEP 2: Print the top 9 rows (star field + stripe field)
        // ------------------------------------------------------------
        // A loop from 0 to 8 (inclusive) prints the first 9 rows.
        // On even iterations (0, 2, 4, 6, 8), we use the "odd row" star
        // pattern. On odd iterations (1, 3, 5, 7), we use the "even row"
        // pattern. This creates the staggered, checkerboard-like look
        // that mimics the alternating rows of stars on the real flag.
        //
        // The condition (row % 2 == 0) uses the modulus operator to
        // determine whether the row index is even or odd.
        for (int row = 0; row < 9; row++) {

            // Select the appropriate star-field segment based on the
            // parity of the row index.
            String starSegment = (row % 2 == 0) ? starFieldOddRow : starFieldEvenRow;

            // Concatenate the star segment with the right-side stripe
            // field and print the resulting row.
            System.out.println(starSegment + stripeFieldRight);
        }

        // ------------------------------------------------------------
        // STEP 3: Print the bottom 6 rows (full-width stripes)
        // ------------------------------------------------------------
        // A loop from 0 to 5 (inclusive) prints 6 identical rows of
        // full-width '=' characters. These represent the lower stripes
        // of the flag that extend across the entire width.
        for (int row = 0; row < 6; row++) {
            System.out.println(stripeFieldFull);
        }

        // ------------------------------------------------------------
        // ALTERNATIVE (hard-coded) version — uncomment to use:
        // This produces the exact same output without loops and is
        // useful for verifying the pattern visually.
        // ------------------------------------------------------------
        // System.out.println("* * * * * * ==================================");
        // System.out.println(" * * * * *  ==================================");
        // System.out.println("* * * * * * ==================================");
        // System.out.println(" * * * * *  ==================================");
        // System.out.println("* * * * * * ==================================");
        // System.out.println(" * * * * *  ==================================");
        // System.out.println("* * * * * * ==================================");
        // System.out.println(" * * * * *  ==================================");
        // System.out.println("* * * * * * ==================================");
        // System.out.println("==============================================");
        // System.out.println("==============================================");
        // System.out.println("==============================================");
        // System.out.println("==============================================");
        // System.out.println("==============================================");
        // System.out.println("==============================================");
    }
} 

