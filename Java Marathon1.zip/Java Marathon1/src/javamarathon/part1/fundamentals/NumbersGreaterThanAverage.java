package javamarathon.part1.fundamentals;

/**
 *
 * @author botho
 */
public class NumbersGreaterThanAverage {

    public static void main(String[] args) {

        // ------------------------------------------------------------
        // STEP 1: Declare the array
        // ------------------------------------------------------------
        // The array is initialized with the given values. In an
        // interactive program, the array might come from user input,
        // but for this exercise the input is fixed.
        int[] array = {1, 4, 17, 7, 25, 3, 100};

        // ------------------------------------------------------------
        // STEP 2: Print the original array
        // ------------------------------------------------------------
        // The expected output format is:
        //   "Original Array: [1, 4, 17, 7, 25, 3, 100]"
        //
        // Java's Arrays.toString(int[]) produces exactly this format.
        System.out.println("Original Array: " + java.util.Arrays.toString(array));

        // ------------------------------------------------------------
        // STEP 3: Compute the sum of all elements
        // ------------------------------------------------------------
        // We walk the array and accumulate the total.
        //
        // For the given array: 1 + 4 + 17 + 7 + 25 + 3 + 100 = 157
        int sum = 0;
        for (int value : array) {
            sum += value;
        }

        // ------------------------------------------------------------
        // STEP 4: Compute the average
        // ------------------------------------------------------------
        // The average is sum / count. To get a floating-point result,
        // we must ensure at least one operand is a double:
        //     (double) sum / array.length    →  floating-point division
        //     sum / array.length             →  integer division (truncated!)
        //
        // For 157 / 7:
        //     (double) 157 / 7  = 22.428571428571427
        //     157 / 7           = 22  (integer, truncated)
        //
        // The problem statement's sample output shows 22.0, which
        // corresponds to the integer-division interpretation. We
        // compute BOTH values so the difference is visible.
        double average = (double) sum / array.length;
        int integerAverage = sum / array.length;

        // Print the floating-point average (the "true" average).
        System.out.println("The average of the said array is: " + average);

        // Print the integer-division average to explain the sample.
        System.out.println("(Integer-division average: " + integerAverage + ".0)");

        // ------------------------------------------------------------
        // STEP 5: Print the header for the "greater than average" list
        // ------------------------------------------------------------
        // The expected output format is:
        //   "The numbers in the said array that are greater than the average are:"
        System.out.println("The numbers in the said array that are greater than the average are:");

        // ------------------------------------------------------------
        // STEP 6: Walk the array again and print elements greater than
        //         the average
        // ------------------------------------------------------------
        // For each element, check if it's STRICTLY greater than the
        // average. If so, print it on its own line.
        //
        // For the given array with average 22.428...:
        //     1   > 22.428? no
        //     4   > 22.428? no
        //     17  > 22.428? no
        //     7   > 22.428? no
        //     25  > 22.428? YES → print
        //     3   > 22.428? no
        //     100 > 22.428? YES → print
        //
        // Note: "strictly greater" uses '>'. If the problem asked for
        // "greater than or equal to", we would use '>='.
        for (int value : array) {
            if (value > average) {
                System.out.println(value);
            }
        }

        // ============================================================
        // STEP 7: (Optional) Verification and comparison
        // ============================================================
        System.out.println();
        System.out.println("Verification trace:");
        System.out.println("  Sum of elements      = " + sum);
        System.out.println("  Count of elements    = " + array.length);
        System.out.println("  Average (double)     = " + average);
        System.out.println("  Average (integer)    = " + integerAverage);
        System.out.println("  Double == integer?   = "
                + (average == integerAverage));

        // Show each element alongside its comparison to the average.
        System.out.println();
        System.out.println("  Element comparisons (vs. " + average + "):");
        for (int value : array) {
            String mark = (value > average) ? "  ← GREATER" : "";
            System.out.printf("    %3d > %.4f  →  %-5s%s%n",
                    value, average, (value > average), mark);
        }

        // ============================================================
        // ALTERNATIVE 1 — Collecting the results into a list first
        // ============================================================
        // If the "greater than average" numbers need to be reused
        // (sorted, counted, further processed), collect them first.
        java.util.List<Integer> greaterThanAvg = new java.util.ArrayList<>();
        for (int value : array) {
            if (value > average) {
                greaterThanAvg.add(value);
            }
        }
        System.out.println();
        System.out.println("Collected into a list: " + greaterThanAvg);
        System.out.println("Count: " + greaterThanAvg.size());

        // ============================================================
        // ALTERNATIVE 2 — Using Java streams (Java 8+)
        // ============================================================
        // A functional approach using IntStream: compute the average,
        // then filter and collect.
        //
        //     double avg = IntStream.of(array).average().orElse(0);
        //     IntStream.of(array)
        //              .filter(n -> n > avg)
        //              .forEach(System.out::println);
        //
        // Concise but arguably less transparent for beginners.
        // ============================================================
        System.out.println();
        System.out.println("Via streams:");
        double streamAvg = java.util.Arrays.stream(array).average().orElse(0);
        java.util.Arrays.stream(array)
                .filter(n -> n > streamAvg)
                .forEach(System.out::println);

        // ============================================================
        // ALTERNATIVE 3 — Using a helper method
        // ============================================================
        // Encapsulating the logic in a method makes it reusable and
        // easy to test with different arrays.
        // ============================================================
        System.out.println();
        System.out.println("Via helper method:");
        int[] result = numbersGreaterThanAverage(array);
        System.out.println("  Result array: " + java.util.Arrays.toString(result));

        // ============================================================
        // ALTERNATIVE 4 — Testing with other arrays
        // ============================================================
        // A sweep through several test cases confirms the logic.
        System.out.println();
        System.out.println("Test sweep:");
        int[][] tests = {
            {1, 4, 17, 7, 25, 3, 100}, // given
            {5, 10, 15, 20, 25}, // average = 15; greater = 20, 25
            {1, 2, 3, 4, 5}, // average = 3; greater = 4, 5
            {10, 10, 10, 10}, // average = 10; none greater
            {1}, // average = 1; none greater
            {100, 1}, // average = 50.5; greater = 100
            {-5, 0, 5, 10} // average = 2.5; greater = 5, 10
        };

        for (int[] test : tests) {
            double avg = java.util.Arrays.stream(test).average().orElse(0);
            int[] greater = numbersGreaterThanAverage(test);
            System.out.printf("  Array: %-30s  avg=%-8.4f  greater=%s%n",
                    java.util.Arrays.toString(test),
                    avg,
                    java.util.Arrays.toString(greater));
        }
    }

    /**
     * Returns a new array containing only the elements of the input array that
     * are strictly greater than the array's average.
     *
     * The average is computed as a double so that fractional results are
     * preserved. This means that "greater than average" is evaluated against
     * the true (potentially fractional) mean.
     *
     * @param array the input array (must not be null or empty)
     * @return an array of elements strictly greater than the average, or an
     * empty array if no element qualifies
     * @throws IllegalArgumentException if array is null or empty
     */
    private static int[] numbersGreaterThanAverage(int[] array) {
        if (array == null || array.length == 0) {
            throw new IllegalArgumentException("Array must not be null or empty.");
        }

        // Compute the sum.
        int sum = 0;
        for (int value : array) {
            sum += value;
        }

        // Compute the average as a double.
        double average = (double) sum / array.length;

        // Count how many elements exceed the average.
        int count = 0;
        for (int value : array) {
            if (value > average) {
                count++;
            }
        }

        // Allocate a new array of exactly the right size.
        int[] result = new int[count];

        // Fill the result array.
        int index = 0;
        for (int value : array) {
            if (value > average) {
                result[index++] = value;
            }
        }

        return result;
    }
}
