package javamarathon.part1.fundamentals;

/**
 *
 * @author botho
 */
public class HexagonArea {

    public static void main(String[] args) {

        // ------------------------------------------------------------
        // STEP 1: Declare and initialize the side length
        // ------------------------------------------------------------
        // Stored as 'double' because geometric computations with √3
        // produce irrational results that need floating-point precision.
        double side = 6;

        // ------------------------------------------------------------
        // STEP 2: Compute the area of the hexagon
        // ------------------------------------------------------------
        // Formula:  Area = (3 × √3 / 2) × side²
        //
        // Step-by-step trace with side = 6:
        //   side²           = 6 × 6                  = 36
        //   √3              ≈ 1.7320508075688772
        //   3 × √3          ≈ 5.196152422706632
        //   3 × √3 / 2      ≈ 2.598076211353316
        //   × side²         ≈ 2.598076211353316 × 36
        //                   ≈ 93.53074360871938
        //
        // Note: We write 'side * side' instead of Math.pow(side, 2)
        // because multiplication is faster and more idiomatic for
        // squaring.
        double area = (3 * Math.sqrt(3) / 2) * side * side;

        // ------------------------------------------------------------
        // STEP 3: Print the result
        // ------------------------------------------------------------
        // The required output format is:
        //   "The area of the hexagon is: 93.53074360871938"
        //
        // Java's default double display shows full precision, matching
        // the expected output exactly.
        System.out.println("The area of the hexagon is: " + area);

        // ------------------------------------------------------------
        // STEP 4: (Optional) Print a verification trace
        // ------------------------------------------------------------
        // Showing the intermediate steps helps confirm the calculation
        // and provides a useful learning reference.
        System.out.println();
        System.out.println("Verification trace:");
        System.out.println("  Side length         = " + side);
        System.out.println("  side²               = " + (side * side));
        System.out.println("  √3                  ≈ " + Math.sqrt(3));
        System.out.println("  (3 × √3 / 2)        ≈ " + (3 * Math.sqrt(3) / 2));
        System.out.println("  Area                = " + area);

        // ------------------------------------------------------------
        // STEP 5: (Optional) Compute and display the perimeter
        // ------------------------------------------------------------
        // The perimeter of a regular hexagon is simply 6 × side,
        // since all six sides are equal. This is a natural companion
        // calculation to the area.
        double perimeter = 6 * side;
        System.out.println();
        System.out.println("Perimeter of the hexagon = " + perimeter);

        // ------------------------------------------------------------
        // Alternative formula: using Math.pow instead of multiplication
        // (uncomment to use) — produces the same result but is
        // slightly slower and less idiomatic.
        // ------------------------------------------------------------
        // double area = (3 * Math.sqrt(3) / 2) * Math.pow(side, 2);
        // ------------------------------------------------------------
        // Alternative formula: dividing into 6 equilateral triangles
        // (uncomment to use) — mathematically identical but more
        // verbose. Useful for understanding the derivation.
        // ------------------------------------------------------------
        // double triangleArea = (Math.sqrt(3) / 4) * side * side;
        // double area = 6 * triangleArea;
        // ------------------------------------------------------------
        // STEP 6: (Optional) Print formatted output
        // ------------------------------------------------------------
        // For a cleaner, currency-like display with fixed decimals,
        // use printf with %.2f. Uncomment to see the difference.
        // ------------------------------------------------------------
        // System.out.printf("The area of the hexagon is: %.2f%n", area);
        // Output: "The area of the hexagon is: 93.53"
    }
}
