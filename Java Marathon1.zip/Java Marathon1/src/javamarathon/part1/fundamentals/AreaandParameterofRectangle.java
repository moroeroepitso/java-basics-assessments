package javamarathon.part1.fundamentals;
/**
 *
 * 2128087
 */
public class AreaandParameterofRectangle {
   

    public static void main(String[] args) {

        // ------------------------------------------------------------
        // STEP 1: Declare and initialize the rectangle dimensions
        // ------------------------------------------------------------
        // Both dimensions are stored as 'double' because they contain
        // decimal values and because geometric formulas produce
        // floating-point results.

        // 'length' is the longer side of the rectangle (horizontal extent).
        double length = 5.6;

        // 'width' is the shorter side of the rectangle (vertical extent).
        // Note: In a rectangle, length and width are interchangeable
        // when computing area and perimeter — the formulas are symmetric.
        double width = 8.5;

        // ------------------------------------------------------------
        // STEP 2: Compute the Area
        // ------------------------------------------------------------
        // Formula:  A = length × width
        //
        // Step-by-step trace with length = 5.6, width = 8.5:
        //   5.6 × 8.5  = 47.6  →  formatted as 47.60
        //
        // The '*' operator performs floating-point multiplication.
        double area = length * width;

        // ------------------------------------------------------------
        // STEP 3: Compute the Perimeter
        // ------------------------------------------------------------
        // Formula:  P = 2 × (length + width)
        //
        // The parentheses are ESSENTIAL. Without them, Java's operator
        // precedence would evaluate multiplication BEFORE addition:
        //    2 * length + width  =  (2 * 5.6) + 8.5  =  11.2 + 8.5  =  19.7  ✗
        // With parentheses:
        //    2 * (5.6 + 8.5)     =  2 * 14.1        =  28.2             ✓
        //
        // Step-by-step trace:
        //   length + width = 5.6 + 8.5 = 14.1
        //   2 × 14.1       = 28.2  →  formatted as 28.20
        double perimeter = 2 * (length + width);

        // ------------------------------------------------------------
        // STEP 4: Print the results in the required format
        // ------------------------------------------------------------
        // The expected output shows the calculation steps alongside the
        // numeric values, so we embed the operands into the printed line
        // using string concatenation. The final value is formatted with
        // %.2f to guarantee exactly two decimal places.
        //
        // printf() placeholders used:
        //   %.1f  →  one decimal place (for 5.6, 8.5)
        //   %.2f  →  two decimal places (for 47.60, 28.20)
        //   %n    →  platform-independent newline
        System.out.printf("Area is %.1f * %.1f = %.2f%n", length, width, area);
        System.out.printf("Perimeter is 2 * (%.1f + %.1f) = %.2f%n", length, width, perimeter);

        // ------------------------------------------------------------
        // Alternative output using println() with String.format()
        // (uncomment to use) — produces the same result without printf.
        // ------------------------------------------------------------
        // System.out.println("Area is " + length + " * " + width + " = "
        //                  + String.format("%.2f", area));
        // System.out.println("Perimeter is 2 * (" + length + " + " + width + ") = "
        //                  + String.format("%.2f", perimeter));

        // ------------------------------------------------------------
        // STEP 5: (Optional) Extra measurements for a rectangle
        // ------------------------------------------------------------
        // The diagonal of a rectangle can be computed using the
        // Pythagorean theorem, since the diagonal splits the rectangle
        // into two right triangles:
        //     d = √(length² + width²)
        //
        // Uncomment the lines below to see the diagonal printed too.
        // ------------------------------------------------------------
        // double diagonal = Math.sqrt(length * length + width * width);
        // System.out.printf("Diagonal is sqrt(%.1f² + %.1f²) = %.4f%n",
        //                   length, width, diagonal);

        // ------------------------------------------------------------
        // STEP 6: (Optional) Simple summary report
        // ------------------------------------------------------------
        System.out.println();
        System.out.println("=== Rectangle Summary ===");
        System.out.printf ("Length      = %.2f%n", length);
        System.out.printf ("Width       = %.2f%n", width);
        System.out.printf ("Area        = %.2f%n", area);
        System.out.printf ("Perimeter   = %.2f%n", perimeter);
        System.out.println("=========================");
    }
}

