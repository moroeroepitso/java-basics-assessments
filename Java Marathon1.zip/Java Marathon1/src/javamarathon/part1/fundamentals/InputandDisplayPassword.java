package javamarathon.part1.fundamentals;

/**
 *
 * @author botho
 */
public class InputandDisplayPassword {

    public static void main(String[] args) {

        // ------------------------------------------------------------
        // STEP 1: Print the prompt
        // ------------------------------------------------------------
        // The expected output starts with:
        //   "Input your Password:"
        System.out.println("Input your Password:");

        // ------------------------------------------------------------
        // STEP 2: Read the password using the most secure method available
        // ------------------------------------------------------------
        // We try the Console approach first (which hides typed chars),
        // then fall back to Scanner (which shows them) if Console is
        // unavailable.
        //
        // System.console() returns:
        //   - A Console object when running from a real terminal
        //   - null when running from an IDE, piped input, or a GUI
        //
        // This is a very common pattern in Java command-line tools.
        String password;

        java.io.Console console = System.console();

        if (console != null) {
            // --------------------------------------------------------
            // SECURE PATH — running in a real terminal
            // --------------------------------------------------------
            // readPassword() returns a char[] (not a String) for
            // security reasons: the caller can zero out the array
            // after use to reduce the time the password exists in
            // memory. We then convert to a String for display.
            //
            // The characters typed by the user are NOT echoed to the
            // terminal — they are invisible while typing.
            char[] passwordChars = console.readPassword();
            password = new String(passwordChars);

            // Immediately wipe the char array to minimize the window
            // during which the password is readable in memory.
            java.util.Arrays.fill(passwordChars, '\0');
        } else {
            // --------------------------------------------------------
            // FALLBACK PATH — running from an IDE or redirected input
            // --------------------------------------------------------
            // Scanner does NOT hide the typed characters. This is
            // fine for testing in NetBeans, but remember: in a real
            // terminal, always prefer Console.readPassword().
            //
            // nextLine() reads the entire line up to (but not including)
            // the newline character, which is important because passwords
            // may contain spaces.
            java.util.Scanner scanner = new java.util.Scanner(System.in);
            password = scanner.nextLine();
            scanner.close();
        }

        // ------------------------------------------------------------
        // STEP 3: Display the password back
        // ------------------------------------------------------------
        // The required output format is:
        //   "Your password was: abc@123"
        //
        // WARNING: In real applications, NEVER display a password back
        // to the user. This exercise is for learning input/output only.
        // Passwords should be hashed (e.g., with bcrypt or Argon2) and
        // never stored or printed in plaintext.
        System.out.println("Your password was: " + password);

        // ------------------------------------------------------------
        // STEP 4: (Optional) Show information about the password
        // ------------------------------------------------------------
        // Analyzing the password's structure without revealing it can
        // be useful for demonstrating security concepts. Here we only
        // show its LENGTH, not its content.
        System.out.println();
        System.out.println("Password analysis:");
        System.out.println("  Length         : " + password.length() + " characters");
        System.out.println("  Contains @     : " + password.contains("@"));
        System.out.println("  Contains digit : " + password.matches(".*\\d.*"));

        // ============================================================
        // ALTERNATIVE IMPLEMENTATION — Simple Scanner-only version
        // ============================================================
        // The simplest version of this program uses only Scanner. It
        // does not hide the password while typing, but it is portable
        // across every environment (IDE, terminal, piped input).
        //
        // Uncomment the block below and comment out the main method's
        // logic above to try it.
        // ============================================================
        // import java.util.Scanner;
        //
        // Scanner scanner = new Scanner(System.in);
        // System.out.println("Input your Password:");
        // String password = scanner.nextLine();
        // System.out.println("Your password was: " + password);
        // scanner.close();
        // ============================================================
        // ALTERNATIVE IMPLEMENTATION — BufferedReader version
        // ============================================================
        // BufferedReader is an older but efficient way to read input.
        // It is preferred over Scanner for performance-critical code,
        // but is more verbose.
        //
        // Uncomment the block below to try it.
        // ============================================================
        // import java.io.BufferedReader;
        // import java.io.InputStreamReader;
        //
        // BufferedReader reader = new BufferedReader(
        //         new InputStreamReader(System.in));
        // System.out.println("Input your Password:");
        // String password = reader.readLine();
        // System.out.println("Your password was: " + password);
    }
}
