package javamarathon.part1.fundamentals;

/**
 *
 * @author botho
 */
public class FirstNonRepeatingCharacter {

    public static int firstUniqChar(String s) {
        // Frequency array for lowercase letters (26 letters)
        int[] freq = new int[26];

        // First pass: count frequency of each character
        for (char c : s.toCharArray()) {
            freq[c - 'a']++;
        }

        // Second pass: find first character with frequency 1
        for (int i = 0; i < s.length(); i++) {
            if (freq[s.charAt(i) - 'a'] == 1) {
                return i;
            }
        }

        return -1; // no non-repeating character found
    }

    public static void main(String[] args) {
        String input = "google";
        int index = firstUniqChar(input);
        System.out.println("Index of first non-repeating character in '" + input + "' is: " + index);
        // Output: 4 (character 'l')
    }
}
