package javamarathon.part1.fundamentals;

/**
 *
 * @author botho
 */
public class CountCharactersinString {

    public static void main(String[] args) {

        // ------------------------------------------------------------
        // STEP 1: Declare and initialize the input string
        // ------------------------------------------------------------
        // The string contains a mix of letters, spaces, digits, and
        // punctuation — perfect for exercising all four categories.
        String input = "Aa kiu, I swd skieo 236587. GH kiu: sieo?? 25.33";

        // ------------------------------------------------------------
        // STEP 2: Print the string itself
        // ------------------------------------------------------------
        // The expected output uses the format:
        //   "The string is :  Aa kiu, I swd skieo 236587. GH kiu: sieo?? 25.33"
        // Notice the two spaces after the colon (that's how the sample
        // output is formatted).
        System.out.println("The string is :  " + input);

        // ------------------------------------------------------------
        // STEP 3: Initialize counters for the four categories
        // ------------------------------------------------------------
        // Each counter is an 'int' that starts at 0 and is incremented
        // whenever a matching character is encountered.
        int letterCount = 0;
        int spaceCount = 0;
        int numberCount = 0;
        int otherCount = 0;

        // ------------------------------------------------------------
        // STEP 4: Walk through the string and classify each character
        // ------------------------------------------------------------
        // We use a simple for loop with an index, so we can fetch each
        // character with charAt(i). The loop runs from 0 to length−1.
        //
        // The classification uses the ASCII ranges:
        //   'A' to 'Z'  →  uppercase letters  (ASCII 65–90)
        //   'a' to 'z'  →  lowercase letters  (ASCII 97–122)
        //   '0' to '9'  →  digits             (ASCII 48–57)
        //   ' '         →  space              (ASCII 32)
        //
        // Why compare characters directly instead of using ASCII numbers?
        // In Java, 'A' is a char literal, and char values can be compared
        // with '<' and '>' just like integers. The expression
        //     c >= 'A' && c <= 'Z'
        // is equivalent to
        //     c >= 65 && c <= 90
        // but the former is more readable and self-documenting.
        for (int i = 0; i < input.length(); i++) {

            // Fetch the character at the current position.
            char c = input.charAt(i);

            // Classify the character and increment the right counter.
            if ((c >= 'A' && c <= 'Z') || (c >= 'a' && c <= 'z')) {
                // Letters: either an uppercase or lowercase English letter.
                letterCount++;
            } else if (c >= '0' && c <= '9') {
                // Numbers: a decimal digit.
                numberCount++;
            } else if (c == ' ') {
                // Space: a single space character.
                // (A more general check would use Character.isWhitespace(c),
                // which also matches tab, newline, etc. Since our input
                // only contains spaces, either works.)
                spaceCount++;
            } else {
                // Everything else: punctuation and any other character.
                otherCount++;
            }
        }

        // ------------------------------------------------------------
        // STEP 5: Print the counts
        // ------------------------------------------------------------
        // The expected output order is: letter, space, number, other.
        System.out.println("letter: " + letterCount);
        System.out.println("space: " + spaceCount);
        System.out.println("number: " + numberCount);
        System.out.println("other: " + otherCount);

        // ------------------------------------------------------------
        // STEP 6: (Optional) Sanity check — counts must sum to length
        // ------------------------------------------------------------
        // Every character falls into exactly one of the four categories,
        // so the sum of all counters must equal the string's length.
        // This is a useful way to verify the classification logic.
        int total = letterCount + spaceCount + numberCount + otherCount;
        System.out.println();
        System.out.println("Verification:");
        System.out.println("  String length        = " + input.length());
        System.out.println("  Sum of all counters  = " + total);
        System.out.println("  Counts match length? = " + (total == input.length()));

        // ============================================================
        // ALTERNATIVE APPROACH — Using Character class methods
        // ============================================================
        // Java's Character class provides Unicode-aware classification:
        //   Character.isLetter(c)      →  letter in ANY language
        //   Character.isDigit(c)       →  digit in any script
        //   Character.isWhitespace(c)  →  space, tab, newline, etc.
        //
        // This approach is more robust than ASCII ranges: it works for
        // letters with accents (é, ñ), Arabic digits, Cyrillic letters,
        // and other non-ASCII characters.
        //
        // For the given input, both approaches produce identical
        // results because the string contains only ASCII characters.
        int altLetter = 0, altSpace = 0, altNumber = 0, altOther = 0;
        for (int i = 0; i < input.length(); i++) {
            char c = input.charAt(i);
            if (Character.isLetter(c)) {
                altLetter++;
            } else if (Character.isDigit(c)) {
                altNumber++;
            } else if (Character.isWhitespace(c)) {
                altSpace++;
            } else {
                altOther++;
            }
        }
        System.out.println();
        System.out.println("Character-class-based results:");
        System.out.println("  letter: " + altLetter);
        System.out.println("  space:  " + altSpace);
        System.out.println("  number: " + altNumber);
        System.out.println("  other:  " + altOther);

        // ============================================================
        // ALTERNATIVE APPROACH — Extract and print each category
        // ============================================================
        // For learning purposes, it can be helpful to see WHICH
        // characters fall into each category. The loop below builds
        // four strings — one per category — and prints them.
        StringBuilder letters = new StringBuilder();
        StringBuilder spaces = new StringBuilder();
        StringBuilder numbers = new StringBuilder();
        StringBuilder others = new StringBuilder();

        for (int i = 0; i < input.length(); i++) {
            char c = input.charAt(i);
            if (Character.isLetter(c)) {
                letters.append(c);
            } else if (Character.isDigit(c)) {
                numbers.append(c);
            } else if (Character.isWhitespace(c)) {
                spaces.append(c);
            } else {
                others.append(c);
            }
        }
        System.out.println();
        System.out.println("Characters by category:");
        System.out.println("  letters : [" + letters + "]");
        System.out.println("  spaces  : [" + spaces + "]");
        System.out.println("  numbers : [" + numbers + "]");
        System.out.println("  others  : [" + others + "]");
    }
}
