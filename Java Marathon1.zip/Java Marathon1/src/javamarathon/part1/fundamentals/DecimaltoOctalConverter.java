package javamarathon.part1.fundamentals;

/**
 *
 * @author botho
 */
public class DecimaltoOctalConverter {

    public static void main(String[] args) {

        // ------------------------------------------------------------
        // STEP 1: Declare the decimal number
        // ------------------------------------------------------------
        // The number is stored as an 'int' since the input is a whole
        // decimal number with no fractional part.
        int number = 15;

        // ------------------------------------------------------------
        // STEP 2: Convert to octal using the built-in method
        // ------------------------------------------------------------
        // Integer.toOctalString(int) returns the octal representation
        // of the given integer as a String, without leading zeros.
        //
        //   Integer.toOctalString(15)  =  "17"
        //
        // This is the recommended approach for real-world code: concise,
        // correct, and handles all edge cases (including 0 and negative
        // numbers) properly.
        String octalString = Integer.toOctalString(number);

        // ------------------------------------------------------------
        // STEP 3: Print the result
        // ------------------------------------------------------------
        // The required output format is:
        //   "Octal number is: 17"
        System.out.println("Octal number is: " + octalString);

        // ------------------------------------------------------------
        // STEP 4: (Optional) Print a verification trace
        // ------------------------------------------------------------
        // Showing the intermediate steps helps confirm the conversion
        // was done correctly and provides a useful learning reference.
        System.out.println();
        System.out.println("Verification trace:");
        System.out.println("  Decimal number  = " + number);
        System.out.println("  Octal string    = " + octalString);
        System.out.println("  Decimal check   = " + Integer.parseInt(octalString, 8));

        // ============================================================
        // ALTERNATIVE APPROACH — Manual decimal-to-octal conversion
        // ============================================================
        // This method shows the underlying algorithm: repeatedly divide
        // the decimal number by 8, and record each remainder. The
        // remainders, read from bottom to top, form the octal digits.
        //
        // WORKING TRACE with number = 15:
        //
        //   Step 1:  15 ÷ 8 = 1 remainder 7   →  record '7'
        //   Step 2:   1 ÷ 8 = 0 remainder 1   →  record '1'
        //   Stop when the quotient reaches 0.
        //
        //   Remainders in order recorded:   7, 1
        //   Reversed (read bottom-to-top):  1, 7  →  "17"
        // ============================================================
        String manualOctal = decimalToOctalManual(number);
        System.out.println();
        System.out.println("Manual conversion result: " + manualOctal);

        // ------------------------------------------------------------
        // BONUS: Try more examples to confirm the logic
        // ------------------------------------------------------------
        // Uncomment the lines below to test other decimal values.
        // ------------------------------------------------------------
        // System.out.println("\nMore examples:");
        // System.out.println("  0   → " + decimalToOctalManual(0));      // 0
        // System.out.println("  1   → " + decimalToOctalManual(1));      // 1
        // System.out.println("  7   → " + decimalToOctalManual(7));      // 7
        // System.out.println("  8   → " + decimalToOctalManual(8));      // 10
        // System.out.println("  15  → " + decimalToOctalManual(15));     // 17
        // System.out.println("  64  → " + decimalToOctalManual(64));     // 100
        // System.out.println("  255 → " + decimalToOctalManual(255));    // 377
    }

    /**
     * Converts a non-negative decimal integer to its octal string
     * representation using repeated division by 8.
     *
     * Algorithm: 1. If the number is 0, return "0" immediately. 2. While the
     * number is greater than 0: - Record the remainder of number / 8. - Divide
     * the number by 8 (integer division). 3. The remainders are collected from
     * least significant digit to most significant digit, so reverse them at the
     * end.
     *
     * @param n the decimal number to convert (must be >= 0)
     * @return the octal representation of n as a String
     */
    private static String decimalToOctalManual(int n) {

        // Special case: 0 in decimal is "0" in octal.
        // Without this check, the loop below would not execute at all
        // (since n is not > 0), and we would return an empty string.
        if (n == 0) {
            return "0";
        }

        // StringBuilder accumulates the octal digits in the order they
        // are produced — from least significant to most significant.
        // We will reverse this at the end.
        StringBuilder octal = new StringBuilder();

        // Work on a copy of the input so the original is not modified.
        int quotient = n;

        // Repeatedly divide by 8, recording each remainder.
        while (quotient > 0) {
            // '%' returns the remainder of division by 8, in the
            // range 0..7. These are exactly the valid octal digits,
            // so no symbol mapping is needed (unlike hexadecimal).
            int remainder = quotient % 8;

            // Append the current digit to the result.
            octal.append(remainder);

            // Integer division by 8 moves us to the next digit.
            // E.g., 15 / 8 = 1, then 1 / 8 = 0.
            quotient = quotient / 8;
        }

        // The digits were collected LSB-first, so reverse them to get
        // the standard MSB-first octal representation.
        return octal.reverse().toString();
    }
}
