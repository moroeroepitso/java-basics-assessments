package javamarathon.part1.fundamentals;

/**
 *
 * @author botho
 */
public class ComputeExpression {

    public static void main(String[] args) {

        // ------------------------------------------------------------
        // STEP 1: Declare and initialize the input number
        // ------------------------------------------------------------
        // We use 'int' because the input is a whole digit (0–9).
        //
        // Note: if the problem required reading input interactively,
        // we would use Scanner here. Since the input is fixed at 5,
        // we hard-code it for this exercise.
        int n = 5;

        // ------------------------------------------------------------
        // STEP 2: Print the input line
        // ------------------------------------------------------------
        // The expected output begins with:
        //   "Input number: 5"
        System.out.println("Input number: " + n);

        // ------------------------------------------------------------
        // STEP 3: Compute nn and nnn using the arithmetic method
        // ------------------------------------------------------------
        // For a single digit n:
        //   nn  = n × 11      (because 11 = 10 + 1, shifting n into
        //                      both the tens and units positions)
        //   nnn = n × 111     (because 111 = 100 + 10 + 1)
        //
        // Examples with n = 5:
        //   nn  = 5 × 11  = 55
        //   nnn = 5 × 111 = 555
        //
        // This works because multiplying a single digit by a repunit
        // (number like 11, 111, 1111...) replicates the digit across
        // each position.
        int nn = n * 11;
        int nnn = n * 111;

        // ------------------------------------------------------------
        // STEP 4: Compute the total sum
        // ------------------------------------------------------------
        // Sum = n + nn + nnn
        //     = 5 + 55 + 555
        //     = 615
        int sum = n + nn + nnn;

        // ------------------------------------------------------------
        // STEP 5: Print the result line
        // ------------------------------------------------------------
        // The required output format is:
        //   "5 + 55 + 555 = 615"
        //
        // We build the string using concatenation so the intermediate
        // values are visible in the printed line. This matches the
        // expected output exactly.
        System.out.println(n + " + " + nn + " + " + nnn + " = " + sum);

        // ------------------------------------------------------------
        // STEP 6: (Optional) Verification trace
        // ------------------------------------------------------------
        // Showing the intermediate values helps confirm the arithmetic.
        System.out.println();
        System.out.println("Verification trace:");
        System.out.println("  n            = " + n);
        System.out.println("  nn  = n × 11 = " + n + " × 11 = " + nn);
        System.out.println("  nnn = n × 111= " + n + " × 111 = " + nnn);
        System.out.println("  Sum          = " + sum);

        // ============================================================
        // ALTERNATIVE APPROACH 1 — String concatenation
        // ============================================================
        // Convert n to a String, duplicate it, and parse the result
        // back to an integer. This approach works for any digit value
        // (single or multi-digit), as long as "nn" is interpreted as
        // "the digits of n repeated twice".
        //
        // For n = 5:
        //   "" + 5 + 5       = "55"    → 55
        //   "" + 5 + 5 + 5   = "555"   → 555
        //
        // The leading "" forces String concatenation. Without it,
        // Java would treat "5 + 5" as arithmetic (10) instead of
        // string concatenation ("55").
        String s = String.valueOf(n);
        int nnStr = Integer.parseInt(s + s);
        int nnnStr = Integer.parseInt(s + s + s);
        int sumStr = n + nnStr + nnnStr;

        System.out.println();
        System.out.println("Via string concatenation: "
                + n + " + " + nnStr + " + " + nnnStr + " = " + sumStr);

        // ============================================================
        // ALTERNATIVE APPROACH 2 — Iterative construction
        // ============================================================
        // Build nn and nnn one digit at a time using the pattern:
        //     result = result * 10 + n
        //
        // For n = 5:
        //   nn:
        //     start: 0
        //     0 * 10 + 5 = 5    (after 1st digit)
        //     5 * 10 + 5 = 55   (after 2nd digit)
        //   nnn:
        //     55 * 10 + 5 = 555 (after 3rd digit)
        //
        // This is the most general approach: it extends to any number
        // of repetitions without needing to know the number of digits
        // or write arithmetic constants like 11, 111, 1111, etc.
        int iterativeNn = 0;
        for (int i = 0; i < 2; i++) {
            iterativeNn = iterativeNn * 10 + n;
        }

        int iterativeNnn = iterativeNn;
        for (int i = 0; i < 1; i++) {          // one more repetition
            iterativeNnn = iterativeNnn * 10 + n;
        }

        int sumIter = n + iterativeNn + iterativeNnn;
        System.out.println("Via iterative construction: "
                + n + " + " + iterativeNn + " + " + iterativeNnn
                + " = " + sumIter);

        // ============================================================
        // EXTENSION — Generalize to n + nn + nnn + ... (k terms)
        // ============================================================
        // The same iterative pattern can generate the sum of k terms
        // where each term repeats n one more time than the previous.
        //
        // For n = 5 and k = 3:  5 + 55 + 555 = 615
        // For n = 5 and k = 4:  5 + 55 + 555 + 5555 = 6170
        // For n = 5 and k = 5:  5 + 55 + 555 + 5555 + 55555 = 61725
        //
        // This generalization is shown below for reference.
        int k = 3;
        int currentTerm = 0;
        int runningSum = 0;
        System.out.println();
        System.out.println("Generalized sum with k = " + k + " terms:");
        for (int i = 1; i <= k; i++) {
            currentTerm = currentTerm * 10 + n;
            runningSum += currentTerm;
            System.out.println("  term " + i + ": " + currentTerm
                    + "  (running sum: " + runningSum + ")");
        }
        System.out.println("  Total = " + runningSum);

        // ------------------------------------------------------------
        // BONUS — Try more examples by uncommenting
        // ------------------------------------------------------------
        // System.out.println("\nMore examples:");
        // int[] samples = {1, 2, 3, 5, 7, 9};
        // for (int sample : samples) {
        //     int result = sample + sample * 11 + sample * 111;
        //     System.out.printf("  n=%d → %d + %d + %d = %d%n",
        //             sample, sample, sample * 11, sample * 111, result);
        // }
    }
}
