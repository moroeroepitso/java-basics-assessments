package javamarathon.part1.fundamentals;

import java.util.Scanner;

/**
 *
 * @author botho
 */
public class SameRightmostDigitCheck {

    public static void main(String[] args) {

        // ------------------------------------------------------------
        // STEP 1: Create a Scanner to read input from the keyboard
        // ------------------------------------------------------------
        Scanner scanner = new Scanner(System.in);

        // ------------------------------------------------------------
        // STEP 2: Prompt for and read each of the three numbers
        // ------------------------------------------------------------
        // The prompts match the expected output exactly (including
        // the same spacing inconsistencies as in previous exercises:
        // a space before the colon in prompts 1 and 3, but not 2).
        System.out.print("Input the first number : ");
        int first = scanner.nextInt();

        System.out.print("Input the second number: ");
        int second = scanner.nextInt();

        System.out.print("Input the third number : ");
        int third = scanner.nextInt();

        // ------------------------------------------------------------
        // STEP 3: Extract the rightmost digit of each number
        // ------------------------------------------------------------
        // The modulus operator '%' gives the remainder of division.
        // For non-negative numbers, n % 10 gives the last digit.
        //
        // For robustness against negative inputs, we apply Math.abs to
        // the result. This ensures that the "rightmost digit" is
        // interpreted the same way for both positive and negative
        // numbers:
        //     -23 → last digit is 3 (not -3)
        //     -13 → last digit is 3 (not -3)
        //
        // This way, -23 and 13 would be considered to share a rightmost
        // digit (both end in 3), which is the natural interpretation.
        int lastDigit1 = Math.abs(first % 10);
        int lastDigit2 = Math.abs(second % 10);
        int lastDigit3 = Math.abs(third % 10);

        // ------------------------------------------------------------
        // STEP 4: Check pairwise equality and combine with OR
        // ------------------------------------------------------------
        // "At least two share the same rightmost digit" is true if any
        // of the three pairwise comparisons is true:
        //
        //     (d1 == d2)  OR  (d2 == d3)  OR  (d1 == d3)
        //
        // For (23, 45, 13):
        //     d1 = 3, d2 = 5, d3 = 3
        //     (3 == 5) || (5 == 3) || (3 == 3)
        //     false    || false    || true
        //     → true  ✓
        boolean result = (lastDigit1 == lastDigit2)
                || (lastDigit2 == lastDigit3)
                || (lastDigit1 == lastDigit3);

        // ------------------------------------------------------------
        // STEP 5: Print the result
        // ------------------------------------------------------------
        // The required output format is:
        //   "The result is: true"
        System.out.println("The result is: " + result);

        // ------------------------------------------------------------
        // STEP 6: Close the Scanner
        // ------------------------------------------------------------
        scanner.close();

        // ------------------------------------------------------------
        // STEP 7: (Optional) Print verification details
        // ------------------------------------------------------------
        // A short trace shows each rightmost digit and each pairwise
        // comparison, making the logic transparent.
        System.out.println();
        System.out.println("Verification trace:");
        System.out.println("  first  = " + first + "  →  last digit: " + lastDigit1);
        System.out.println("  second = " + second + "  →  last digit: " + lastDigit2);
        System.out.println("  third  = " + third + "  →  last digit: " + lastDigit3);
        System.out.println();
        System.out.println("  Pairwise comparisons:");
        System.out.println("    lastDigit1 == lastDigit2  →  " + lastDigit1 + " == " + lastDigit2
                + "  →  " + (lastDigit1 == lastDigit2));
        System.out.println("    lastDigit2 == lastDigit3  →  " + lastDigit2 + " == " + lastDigit3
                + "  →  " + (lastDigit2 == lastDigit3));
        System.out.println("    lastDigit1 == lastDigit3  →  " + lastDigit1 + " == " + lastDigit3
                + "  →  " + (lastDigit1 == lastDigit3));
        System.out.println();
        System.out.println("  Combined (any pair matches): " + result);

        // ============================================================
        // ALTERNATIVE 1 — Static (non-interactive) version
        // ============================================================
        // For fixed inputs (23, 45, 13), no reading is needed.
        // ============================================================
        int f = 23, s = 45, t = 13;
        boolean staticResult = (f % 10 == s % 10)
                || (s % 10 == t % 10)
                || (f % 10 == t % 10);

        System.out.println();
        System.out.println("Static version:");
        System.out.println("  (23, 45, 13)  →  " + staticResult);

        // ============================================================
        // ALTERNATIVE 2 — Using a helper method
        // ============================================================
        // Encapsulating the logic in a method gives it a descriptive
        // name and makes it reusable.
        // ============================================================
        System.out.println();
        System.out.println("Via helper method:");
        System.out.println("  shareRightmost(23, 45, 13)  = " + shareRightmost(23, 45, 13));
        System.out.println("  shareRightmost(23, 45, 57)  = " + shareRightmost(23, 45, 57));
        System.out.println("  shareRightmost(10, 20, 30)  = " + shareRightmost(10, 20, 30));
        System.out.println("  shareRightmost(10, 20, 33)  = " + shareRightmost(10, 20, 33));
        System.out.println("  shareRightmost(-23, 45, 13) = " + shareRightmost(-23, 45, 13));
        System.out.println("  shareRightmost(0, 10, 20)   = " + shareRightmost(0, 10, 20));

        // ============================================================
        // ALTERNATIVE 3 — Counting distinct rightmost digits
        // ============================================================
        // Another way to think about the problem: if there are fewer
        // than 3 DISTINCT rightmost digits, then at least two must
        // share one. This is equivalent and sometimes cleaner with
        // data structures.
        // ============================================================
        java.util.Set<Integer> distinctLastDigits = new java.util.HashSet<>();
        distinctLastDigits.add(lastDigit1);
        distinctLastDigits.add(lastDigit2);
        distinctLastDigits.add(lastDigit3);

        // If the set has fewer than 3 elements, at least two inputs
        // shared the same rightmost digit.
        boolean viaSet = distinctLastDigits.size() < 3;

        System.out.println();
        System.out.println("Via set of distinct last digits:");
        System.out.println("  Distinct last digits = " + distinctLastDigits);
        System.out.println("  Count = " + distinctLastDigits.size());
        System.out.println("  Result (count < 3)   = " + viaSet);

        // ============================================================
        // ALTERNATIVE 4 — Using the "add returns false" trick
        // ============================================================
        // Set.add() returns false if the element was already present.
        // We can exploit this to detect duplicates directly:
        //
        //     Set<Integer> seen = new HashSet<>();
        //     boolean duplicate = !seen.add(lastDigit1)
        //                      || !seen.add(lastDigit2)
        //                      || !seen.add(lastDigit3);
        //
        // However, this evaluates all three adds due to short-circuit
        // semantics — fine here since we only care about the final
        // state. It's a neat trick but slightly less readable than
        // the direct pairwise approach.
        // ============================================================
        java.util.Set<Integer> seen = new java.util.HashSet<>();
        boolean duplicateFound = !seen.add(lastDigit1)
                || !seen.add(lastDigit2)
                || !seen.add(lastDigit3);

        System.out.println();
        System.out.println("Via Set.add() duplicate detection: " + duplicateFound);

        // ============================================================
        // ALTERNATIVE 5 — Testing many combinations to verify logic
        // ============================================================
        // A quick sweep through test cases confirms the logic works
        // for all combinations of matches/non-matches.
        // ============================================================
        System.out.println();
        System.out.println("Test sweep:");
        int[][] tests = {
            {23, 45, 13}, // true:  23 and 13 share '3'
            {23, 43, 13}, // true:  all share '3'
            {23, 45, 67}, // false: no matches
            {10, 20, 30}, // true:  all share '0'
            {10, 20, 33}, // true:  10 and 20 share '0'
            {10, 25, 37}, // false: 0, 5, 7 all different
            {0, 10, 20}, // true:  all share '0'
            {-23, 45, 13}, // true:  -23 and 13 share '3' (using abs)
            {-23, 45, -13}, // true:  all share '3' if abs is applied
        };

        for (int[] triple : tests) {
            boolean r = shareRightmost(triple[0], triple[1], triple[2]);
            System.out.printf("  (%4d, %4d, %4d)  →  %s%n",
                    triple[0], triple[1], triple[2], r);
        }
    }

    /**
     * Returns true if at least two of the three integers share the same
     * rightmost digit.
     *
     * The rightmost digit of n is Math.abs(n % 10), which gives a non-negative
     * digit in the range 0–9 even for negative inputs.
     *
     * @param a first integer
     * @param b second integer
     * @param c third integer
     * @return true if any two of a, b, c end in the same digit
     */
    private static boolean shareRightmost(int a, int b, int c) {
        int da = Math.abs(a % 10);
        int db = Math.abs(b % 10);
        int dc = Math.abs(c % 10);
        return (da == db) || (db == dc) || (da == dc);
    }
}
