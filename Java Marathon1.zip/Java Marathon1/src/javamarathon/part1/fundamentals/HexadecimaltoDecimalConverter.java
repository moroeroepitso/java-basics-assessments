package javamarathon.part1.fundamentals;

/**
 *
 * @author botho
 */
public class HexadecimaltoDecimalConverter {

    public static void main(String[] args) {

        // ------------------------------------------------------------
        // STEP 1: Declare the hexadecimal number as a String
        // ------------------------------------------------------------
        // Storing the hex value as a String preserves its hexadecimal
        // meaning and allows us to include letters (A–F) if needed.
        String hex = "25";

        // ------------------------------------------------------------
        // STEP 2: Convert to decimal using the built-in method
        // ------------------------------------------------------------
        // Integer.parseInt(String, radix) interprets the string as a
        // number in the given base. Passing radix = 16 tells Java to
        // treat the string as hexadecimal.
        //
        //   Integer.parseInt("25", 16)  =  37
        //
        // This is the recommended approach for real-world code: concise,
        // correct, and case-insensitive for letter digits.
        int decimalNumber = Integer.parseInt(hex, 16);

        // ------------------------------------------------------------
        // STEP 3: Print the result
        // ------------------------------------------------------------
        // The required output format is:
        //   "Equivalent decimal number is: 37"
        System.out.println("Equivalent decimal number is: " + decimalNumber);

        // ------------------------------------------------------------
        // STEP 4: (Optional) Print a verification trace
        // ------------------------------------------------------------
        // Showing the intermediate steps helps confirm the conversion
        // was done correctly and provides a useful learning reference.
        System.out.println();
        System.out.println("Verification trace:");
        System.out.println("  Hexadecimal string  = " + hex);
        System.out.println("  Decimal number      = " + decimalNumber);
        System.out.println("  Hex check (upper)   = " + Integer.toHexString(decimalNumber).toUpperCase());
        System.out.println("  Hex check (lower)   = " + Integer.toHexString(decimalNumber));

        // ============================================================
        // ALTERNATIVE APPROACH — Manual hex-to-decimal conversion
        // ============================================================
        // This method shows the underlying algorithm: walk through the
        // hex string from LEFT to RIGHT, multiplying the running total
        // by 16 at each step and adding the numeric value of the
        // current character. This is a form of Horner's method and
        // avoids computing powers of 16 separately.
        //
        // Each character is mapped to a numeric value:
        //   '0'..'9'  →  0..9
        //   'A'..'F'  →  10..15    (case-insensitive: also 'a'..'f')
        //
        // WORKING TRACE with hex = "25":
        //
        //   Start:  decimal = 0
        //   Char '2':  numeric value 2  →  decimal = 0 × 16 + 2  =  2
        //   Char '5':  numeric value 5  →  decimal = 2 × 16 + 5  =  37   ✓
        //
        // WORKING TRACE with hex = "FF" (255 in decimal):
        //
        //   Start:  decimal = 0
        //   Char 'F':  numeric value 15  →  decimal = 0  × 16 + 15  =  15
        //   Char 'F':  numeric value 15  →  decimal = 15 × 16 + 15  =  255  ✓
        //
        // WORKING TRACE with hex = "1A3" (419 in decimal):
        //
        //   Start:  decimal = 0
        //   Char '1':  numeric value 1   →  decimal = 0   × 16 + 1   =  1
        //   Char 'A':  numeric value 10  →  decimal = 1   × 16 + 10  =  26
        //   Char '3':  numeric value 3   →  decimal = 26  × 16 + 3   =  419  ✓
        // ============================================================
        int manualDecimal = hexToDecimalManual(hex);
        System.out.println();
        System.out.println("Manual conversion result: " + manualDecimal);

        // ------------------------------------------------------------
        // BONUS: Try more examples to confirm the logic
        // ------------------------------------------------------------
        // Uncomment the lines below to test other hex values.
        // ------------------------------------------------------------
        // System.out.println("\nMore examples:");
        // System.out.println("  0    → " + hexToDecimalManual("0"));       // 0
        // System.out.println("  9    → " + hexToDecimalManual("9"));       // 9
        // System.out.println("  A    → " + hexToDecimalManual("A"));       // 10
        // System.out.println("  F    → " + hexToDecimalManual("F"));       // 15
        // System.out.println("  10   → " + hexToDecimalManual("10"));      // 16
        // System.out.println("  25   → " + hexToDecimalManual("25"));      // 37
        // System.out.println("  FF   → " + hexToDecimalManual("FF"));      // 255
        // System.out.println("  1A3  → " + hexToDecimalManual("1A3"));     // 419
        // System.out.println("  fF   → " + hexToDecimalManual("fF"));      // 255 (case-insensitive)
    }

    /**
     * Converts a hexadecimal string to its decimal integer representation.
     *
     * Algorithm (Horner's method): Walk through the hex string from left to
     * right, maintaining a running decimal value. At each step: decimal =
     * decimal * 16 + numericValueOfCurrentChar This is equivalent to
     * multiplying the running total by 16 (to shift it one position left) and
     * adding the new digit's value.
     *
     * Character-to-value mapping (case-insensitive): '0'..'9' → 0..9 'A'..'F' →
     * 10..15 'a'..'f' → 10..15
     *
     * @param hex the hexadecimal string to convert (e.g., "25")
     * @return the equivalent decimal integer
     * @throws IllegalArgumentException if the input contains characters other
     * than 0–9 and A–F (either case), or if the string is null or empty
     */
    private static int hexToDecimalManual(String hex) {

        // Validate input: must be non-empty.
        if (hex == null || hex.isEmpty()) {
            throw new IllegalArgumentException(
                    "Hexadecimal string must not be null or empty.");
        }

        // 'decimal' holds the running total, starting at 0.
        int decimal = 0;

        // Walk through each character of the hex string from left
        // (most significant digit) to right (least significant digit).
        for (int i = 0; i < hex.length(); i++) {

            // Fetch the current character.
            char c = hex.charAt(i);

            // Convert the character to its numeric value (0–15).
            int digitValue;
            if (c >= '0' && c <= '9') {
                // Digit '0'..'9' → 0..9
                // '0' - '0' = 0, '9' - '0' = 9
                digitValue = c - '0';
            } else if (c >= 'A' && c <= 'F') {
                // Uppercase 'A'..'F' → 10..15
                // 'A' - 'A' + 10 = 10, 'F' - 'A' + 10 = 15
                digitValue = c - 'A' + 10;
            } else if (c >= 'a' && c <= 'f') {
                // Lowercase 'a'..'f' → 10..15
                // 'a' - 'a' + 10 = 10, 'f' - 'a' + 10 = 15
                digitValue = c - 'a' + 10;
            } else {
                // Any other character is not a valid hex digit.
                throw new IllegalArgumentException(
                        "Invalid hexadecimal character '" + c
                        + "' at index " + i
                        + ". Only 0-9, A-F, and a-f are allowed.");
            }

            // Multiply the running total by 16 (shift one position left),
            // then add the numeric value of the current character.
            decimal = decimal * 16 + digitValue;
        }

        // Return the computed decimal value.
        return decimal;
    }
}
