package javamarathon.part1.fundamentals;

/**
 *
 * @author botho
 */
public class CheckJavaInstallation {

    public static void main(String[] args) {

        // ------------------------------------------------------------
        // STEP 1: Read each System property into a local variable
        // ------------------------------------------------------------
        // System.getProperty(String key) returns the value of the
        // requested property, or null if the property does not exist.
        //
        // We store each value in a named variable so the print statements
        // below are clean and easy to read. If a property is missing,
        // we provide a fallback string like "Not available" to avoid
        // printing "null" awkwardly.
        // The Java version number, e.g., "1.8.0_71" or "17.0.1".
        String javaVersion = getPropertyOrDefault("java.version");

        // The Java runtime version, often more detailed than java.version.
        // Example: "1.8.0_71-b15" (the "-b15" indicates build 15).
        String javaRuntimeVersion = getPropertyOrDefault("java.runtime.version");

        // The installation directory of the Java Runtime Environment (JRE).
        // Example: "/opt/jdk/jdk1.8.0_71/jre" on Linux, or
        //          "C:\\Program Files\\Java\\jdk-17\\" on Windows.
        String javaHome = getPropertyOrDefault("java.home");

        // The company or organization that provides the Java implementation.
        // Examples: "Oracle Corporation", "Eclipse Adoptium", "Azul Systems".
        String javaVendor = getPropertyOrDefault("java.vendor");

        // The vendor's website URL.
        // Example: "http://java.oracle.com/"
        String javaVendorUrl = getPropertyOrDefault("java.vendor.url");

        // The class path used when this program was launched.
        // A single "." means the current directory.
        String javaClassPath = getPropertyOrDefault("java.class.path");

        // ------------------------------------------------------------
        // STEP 2: Print the required output lines
        // ------------------------------------------------------------
        // The format matches the problem statement exactly:
        //   "Java Version: ..."
        //   "Java Runtime Version: ..."
        //   etc.
        System.out.println("Java Version: " + javaVersion);
        System.out.println("Java Runtime Version: " + javaRuntimeVersion);
        System.out.println("Java Home: " + javaHome);
        System.out.println("Java Vendor: " + javaVendor);
        System.out.println("Java Vendor URL: " + javaVendorUrl);
        System.out.println("Java Class Path: " + javaClassPath);

        // ------------------------------------------------------------
        // STEP 3: (Optional) Print additional system information
        // ------------------------------------------------------------
        // The following block demonstrates that the same technique
        // can be used to inspect other aspects of the runtime
        // environment. These lines are useful for diagnostics but
        // are not part of the required output.
        System.out.println();
        System.out.println("--- Additional System Information ---");
        System.out.println("Java VM Name         : " + getPropertyOrDefault("java.vm.name"));
        System.out.println("Java VM Version      : " + getPropertyOrDefault("java.vm.version"));
        System.out.println("Java VM Vendor       : " + getPropertyOrDefault("java.vm.vendor"));
        System.out.println("Java Specification   : " + getPropertyOrDefault("java.specification.version"));
        System.out.println("Operating System     : " + getPropertyOrDefault("os.name"));
        System.out.println("OS Version           : " + getPropertyOrDefault("os.version"));
        System.out.println("OS Architecture      : " + getPropertyOrDefault("os.arch"));
        System.out.println("User Name            : " + getPropertyOrDefault("user.name"));
        System.out.println("User Working Dir     : " + getPropertyOrDefault("user.dir"));
        System.out.println("User Home Dir        : " + getPropertyOrDefault("user.home"));
        System.out.println("File Separator       : " + getPropertyOrDefault("file.separator"));
        System.out.println("Path Separator       : " + getPropertyOrDefault("path.separator"));
        System.out.println("Line Separator       : " + escapeLineSeparator(getPropertyOrDefault("line.separator")));

        // ------------------------------------------------------------
        // STEP 4: (Optional) Print ALL system properties
        // ------------------------------------------------------------
        // System.getProperties() returns a Properties object containing
        // every system property. Printing them all is useful when
        // diagnosing platform-specific problems. Uncomment the block
        // below to see the complete list.
        // ------------------------------------------------------------
        // System.out.println();
        // System.out.println("--- All System Properties ---");
        // System.getProperties().forEach((key, value) ->
        //     System.out.println(key + " = " + value));
        // ------------------------------------------------------------
        // STEP 5: (Optional) Print Java version in a user-friendly way
        // ------------------------------------------------------------
        // The runtime library reports a property called "java.version"
        // in a format that varies across JDK versions:
        //   JDK 8 and earlier:  "1.8.0_71"
        //   JDK 9 and later:    "17.0.1", "21", "23.0.2", etc.
        //
        // The block below identifies the major version and reports
        // whether it corresponds to a widely used LTS release.
        // ------------------------------------------------------------
        System.out.println();
        System.out.println("--- Java Version Analysis ---");

        // ------------------------------------------------------------
        // STEP 6: (Optional) Sanity check — is Java actually installed?
        // ------------------------------------------------------------
        // If we reached this point, then yes: the JVM is running this
        // class, so Java is definitely installed. This is a slightly
        // playful but valid observation.
        // ------------------------------------------------------------
        System.out.println();
        System.out.println("Java is installed and running: YES (this program is proof!)");
    }

    /**
     * Reads a system property and returns its value, or a fallback string ("Not
     * available") if the property is missing.
     *
     * This small helper keeps the main method clean by centralizing the "get or
     * default" pattern. It also guards against a null value being concatenated
     * awkwardly into output.
     *
     * @param key the name of the system property (e.g., "java.version")
     * @return the property value, or "Not available" if it is null
     */
    private static String getPropertyOrDefault(String key) {
        String value = System.getProperty(key);
        return (value != null) ? value : "Not available";
    }

    /**
     * Converts a line separator string into a human-readable escape sequence so
     * that it can be printed on a single line.
     *
     * On Unix-like systems, line.separator is "\n". On Windows, it is "\r\n".
     * Printing the raw value would produce an actual newline, breaking the
     * output format. This helper replaces it with the literal text "\n" or
     * "\r\n" so the value is visible.
     *
     * @param sep the raw line separator string
     * @return a printable representation with visible escape sequences
     */
    private static String escapeLineSeparator(String sep) {
        return sep.replace("\r", "\\r").replace("\n", "\\n");
    }

    private static Object rsion() {
        throw new UnsupportedOperationException("Not supported yet."); //To change body of generated methods, choose Tools | Templates.
    }

    public void version() {
    }
}
