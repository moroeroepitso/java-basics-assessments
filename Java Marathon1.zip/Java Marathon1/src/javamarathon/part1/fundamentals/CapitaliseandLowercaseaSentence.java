package javamarathon.part1.fundamentals;

import java.util.Scanner;

/**
 *
 * @author botho
 */
public class CapitaliseandLowercaseaSentence {

    public static void main(String[] args) {

        // ------------------------------------------------------------
        // STEP 1: Create a Scanner to read input from the keyboard
        // ------------------------------------------------------------
        Scanner scanner = new Scanner(System.in);

        // ------------------------------------------------------------
        // STEP 2: Prompt for and read the sentence
        // ------------------------------------------------------------
        // The prompt matches the expected output:
        //   "Input a Sentence: the quick brown fox jumps over the lazy dog."
        //
        // We use print() (not println()) so the user's typed sentence
        // appears on the same line as the prompt.
        //
        // nextLine() reads the ENTIRE line, including spaces. If we
        // used next(), only the first word ("the") would be read.
        System.out.print("Input a Sentence: ");
        String sentence = scanner.nextLine();

        // ------------------------------------------------------------
        // STEP 3: Produce the capitalized version (Title Case)
        // ------------------------------------------------------------
        // We call a helper method that splits the sentence into words,
        // uppercases the first letter of each, and rejoins them.
        String capitalized = capitalizeWords(sentence);

        // ------------------------------------------------------------
        // STEP 4: Produce the lowercase version
        // ------------------------------------------------------------
        // String.toLowerCase() converts every letter to lowercase.
        // Punctuation, spaces, and digits are unchanged.
        String lowercased = sentence.toLowerCase();

        // ------------------------------------------------------------
        // STEP 5: Print both transformed sentences
        // ------------------------------------------------------------
        // The expected output uses the labels:
        //   "Capitalized: ..."
        //   "Lowercase:   ..."      ← note the extra spaces for alignment
        System.out.println("Capitalized: " + capitalized);
        System.out.println("Lowercase:   " + lowercased);

        // ------------------------------------------------------------
        // STEP 6: Close the Scanner
        // ------------------------------------------------------------
        scanner.close();

        // ------------------------------------------------------------
        // STEP 7: (Optional) Verification details
        // ------------------------------------------------------------
        System.out.println();
        System.out.println("Verification trace:");
        System.out.println("  Original length    : " + sentence.length());
        System.out.println("  Capitalized length : " + capitalized.length());
        System.out.println("  Lowercase length   : " + lowercased.length());
        System.out.println("  All lowercase?     : "
                + lowercased.equals(lowercased.toLowerCase()));
        System.out.println("  Original equals lowercase? "
                + sentence.equals(lowercased));

        // ============================================================
        // ALTERNATIVE 1 — Static version (non-interactive)
        // ============================================================
        // For fixed input, no reading is needed.
        String staticSentence = "the quick brown fox jumps over the lazy dog.";
        System.out.println();
        System.out.println("Static version:");
        System.out.println("  Capitalized: " + capitalizeWords(staticSentence));
        System.out.println("  Lowercase:   " + staticSentence.toLowerCase());

        // ============================================================
        // ALTERNATIVE 2 — Step-by-step demonstration
        // ============================================================
        // Show the intermediate steps: split into words, uppercase
        // the first letter of each, and join back together.
        System.out.println();
        System.out.println("Step-by-step (capitalization):");
        String[] words = sentence.split("\\s+");
        System.out.println("  Split into " + words.length + " words:");
        for (int i = 0; i < words.length; i++) {
            System.out.println("    words[" + i + "] = \"" + words[i] + "\"");
        }

        System.out.println();
        System.out.println("  Capitalizing each word:");
        for (int i = 0; i < words.length; i++) {
            String original = words[i];
            String transformed = capitalizeWord(original);
            System.out.printf("    \"%s\" → \"%s\"%n", original, transformed);
        }

        // ============================================================
        // ALTERNATIVE 3 — Using StringBuilder manually
        // ============================================================
        // The capitalizeWords helper internally uses String.split +
        // String.join. An alternative is to walk the string character
        // by character, tracking whether we're at the start of a word.
        //
        // This version avoids split() and works in O(n) with no
        // intermediate array, at the cost of a longer implementation.
        System.out.println();
        System.out.println("Via character-by-character scanning:");
        System.out.println("  " + capitalizeByScanning(sentence));

        // ============================================================
        // ALTERNATIVE 4 — Testing with different inputs
        // ============================================================
        // Exercises the logic against edge cases: punctuation,
        // apostrophes, mixed case, empty input, etc.
        System.out.println();
        System.out.println("Test cases:");
        String[] tests = {
            "the quick brown fox jumps over the lazy dog.",
            "HELLO WORLD",
            "hello world",
            "don't stop believing",
            "well-known fact",
            "123abc 456def",
            "a",
            "",
            "   multiple    spaces   ",
            "MixedCASE sEnTeNcE"
        };
        for (String test : tests) {
            System.out.printf("  Input       : \"%s\"%n", test);
            System.out.printf("    Capitalized: \"%s\"%n", capitalizeWords(test));
            System.out.printf("    Lowercase  : \"%s\"%n", test.toLowerCase());
        }

        // ============================================================
        // ALTERNATIVE 5 — Using streams (Java 8+)
        // ============================================================
        // A functional one-liner for capitalization. Less readable
        // but shows how the same logic can be expressed with streams:
        //
        //     String capitalized = Arrays.stream(sentence.split("\\s+"))
        //             .map(w -> w.isEmpty() ? w
        //                 : Character.toUpperCase(w.charAt(0))
        //                   + w.substring(1).toLowerCase())
        //             .collect(Collectors.joining(" "));
        // ============================================================
    }

    /**
     * Capitalizes the first letter of each word in a sentence and lowercases
     * the rest of each word.
     *
     * Words are separated by any sequence of whitespace (spaces, tabs,
     * newlines). Punctuation attached to words is preserved — e.g., "dog."
     * becomes "Dog." and "don't" becomes "Don't".
     *
     * @param sentence the sentence to capitalize
     * @return the capitalized sentence, or the input unchanged if it is null or
     * empty
     */
    private static String capitalizeWords(String sentence) {
        if (sentence == null || sentence.isEmpty()) {
            return sentence;
        }

        // Split the sentence on one or more whitespace characters.
        // "\\s+" is a regular expression: \s matches any whitespace
        // (space, tab, newline), and + means "one or more".
        String[] words = sentence.split("\\s+");

        // Capitalize each word and join with a single space.
        StringBuilder result = new StringBuilder();
        for (int i = 0; i < words.length; i++) {
            if (i > 0) {
                result.append(' ');
            }
            result.append(capitalizeWord(words[i]));
        }
        return result.toString();
    }

    /**
     * Capitalizes a single word: uppercase the first character and lowercase
     * the rest.
     *
     * Non-letter first characters (digits, symbols) are left as-is, since
     * Character.toUpperCase has no effect on them.
     *
     * @param word the word to capitalize (must not be null)
     * @return the capitalized word, or the input if it is empty
     */
    private static String capitalizeWord(String word) {
        if (word.isEmpty()) {
            return word;
        }

        // Uppercase the first character.
        char firstUpper = Character.toUpperCase(word.charAt(0));

        // Lowercase the rest of the word.
        String restLower = word.substring(1).toLowerCase();

        return firstUpper + restLower;
    }

    /**
     * Capitalizes a sentence by scanning it character by character.
     *
     * This avoids String.split and works in a single pass, tracking whether the
     * current position is the start of a new word.
     *
     * A "start of word" is the first character of the string or any
     * non-whitespace character immediately preceded by whitespace.
     *
     * @param sentence the sentence to capitalize
     * @return the capitalized sentence
     */
    private static String capitalizeByScanning(String sentence) {
        if (sentence == null || sentence.isEmpty()) {
            return sentence;
        }

        StringBuilder result = new StringBuilder(sentence.length());
        boolean atWordStart = true;

        for (int i = 0; i < sentence.length(); i++) {
            char c = sentence.charAt(i);

            if (Character.isWhitespace(c)) {
                result.append(c);
                atWordStart = true;    // next non-space starts a new word
            } else if (atWordStart) {
                result.append(Character.toUpperCase(c));
                atWordStart = false;
            } else {
                result.append(Character.toLowerCase(c));
            }
        }
        return result.toString();
    }
}
