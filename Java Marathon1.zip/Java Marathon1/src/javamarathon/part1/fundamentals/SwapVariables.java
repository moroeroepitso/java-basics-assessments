/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package javamarathon.part1.fundamentals;

/**
 *
 * @author botho
 */
public class SwapVariables {
 

    public static void main(String[] args) {

        // ------------------------------------------------------------
        // SETUP: Initialize the variables with the given values
        // ------------------------------------------------------------
        // We use 'int' because both values (15 and 27) are whole numbers.
        int a = 15;
        int b = 27;

        // Print the values BEFORE swapping.
        // Format: "Before swapping : a, b = 15, 27"
        System.out.println("Before swapping : a, b = " + a + ", " + b);

        // ============================================================
        // METHOD 1: Swap using a temporary variable (RECOMMENDED)
        // ============================================================
        // The idea:
        //   1. Save 'a' into a temporary holder so it isn't lost.
        //   2. Copy 'b' into 'a' (overwriting 'a').
        //   3. Copy the saved value (old 'a') into 'b'.
        //
        // Visual trace with a = 15, b = 27:
        //
        //   Step 1:  temp = a   →  temp = 15, a = 15, b = 27
        //   Step 2:  a    = b   →  temp = 15, a = 27, b = 27
        //   Step 3:  b    = temp → temp = 15, a = 27, b = 15   ✓
        //
        // We store the result in new variables (a1, b1) so that we can
        // demonstrate the other methods without resetting.

        int a1 = a;       // start from the original values
        int b1 = b;

        int temp = a1;    // Step 1: save 'a' into temp
        a1 = b1;          // Step 2: overwrite 'a' with 'b'
        b1 = temp;        // Step 3: put the saved value into 'b'

        System.out.println("Method 1 (temp variable)   : a, b = " + a1 + ", " + b1);

        // ============================================================
        // METHOD 2: Swap using arithmetic (+ and -)
        // ============================================================
        // The idea:
        //   1. a = a + b   →  'a' now holds the SUM of both values.
        //   2. b = a - b   →  (original a + b) - b = original a.
        //   3. a = a - b   →  (original a + b) - original a = original b.
        //
        // Visual trace with a = 15, b = 27:
        //
        //   Step 1:  a = a + b = 15 + 27 = 42   →  a = 42, b = 27
        //   Step 2:  b = a - b = 42 - 27 = 15   →  a = 42, b = 15
        //   Step 3:  a = a - b = 42 - 15 = 27   →  a = 27, b = 15   ✓
        //
        // CAVEAT: This method can overflow if a + b exceeds the maximum
        //         value of int (2,147,483,647). For example, swapping
        //         a = 2,000,000,000 and b = 2,000,000,000 would produce
        //         a negative intermediate value.

        int a2 = a;       // start from the original values
        int b2 = b;

        a2 = a2 + b2;     // Step 1: a now holds the sum
        b2 = a2 - b2;     // Step 2: b becomes the original a
        a2 = a2 - b2;     // Step 3: a becomes the original b

        System.out.println("Method 2 (arithmetic)      : a, b = " + a2 + ", " + b2);

        // ============================================================
        // METHOD 3: Swap using XOR bitwise operator (^)
        // ============================================================
        // The XOR (exclusive OR) operator returns 1 only when the two
        // bits being compared are different. It has a useful property:
        //     x ^ x = 0   and   x ^ 0 = x
        // which allows us to swap without a third variable.
        //
        // Visual trace with a = 15 (binary 01111), b = 27 (binary 11011):
        //     //            10100   = 20   →  a = 20, b = 27
        //
        //   Step 2:  b = a ^ b
        //            10100
        //          ^ 11011
        //          -------
        //            01111   = 15   →  a = 20, b = 15
        //
        //   Step 3:  a = a ^ b
        //            10100
        //          ^ 01111
        //          -------
        //            11011   = 27   →  a = 27, b = 15   ✓
        //
        // CAVEAT: Only works for integer types, not for double or String.

        int a3 = a;       // start from the original values
        int b3 = b;

        a3 = a3 ^ b3;     // Step 1
        b3 = a3 ^ b3;     // Step 2
        a3 = a3 ^ b3;     // Step 3

        System.out.println("Method 3 (XOR bitwise)     : a, b = " + a3 + ", " + b3);

        // ------------------------------------------------------------
        // FINAL: Print the required output line
        // ------------------------------------------------------------
        // The problem expects the line:
        //     "After swapping : a, b = 27, 15"
        // Any of the three methods above produces the same result, so
        // we use Method 1's result (a1, b1) since it is the clearest.
        System.out.println("After swapping  : a, b = " + a1 + ", " + b1);

        // ------------------------------------------------------------
        // BONUS: Swapping strings (only Method 1 works cleanly)
        // ------------------------------------------------------------
        // The temporary-variable method works for any type, including
        // String, double, boolean, and custom objects. The other two
        // methods only work for numeric primitives.
        String s1 = "Hello";
        String s2 = "World";
        String tempStr = s1;
        s1 = s2;
        s2 = tempStr;
        System.out.println("String swap example         : s1 = " + s1 + ", s2 = " + s2);
    }
}
   