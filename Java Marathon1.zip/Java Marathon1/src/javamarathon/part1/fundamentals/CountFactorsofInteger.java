package javamarathon.part1.fundamentals;

import java.util.Scanner;

/**
 *
 * @author botho
 */
public class CountFactorsofInteger {

    public static void main(String[] args) {

        // ------------------------------------------------------------
        // STEP 1: Create a Scanner to read input from the keyboard
        // ------------------------------------------------------------
        Scanner scanner = new Scanner(System.in);

        // ------------------------------------------------------------
        // STEP 2: Prompt for and read the number
        // ------------------------------------------------------------
        // The expected output begins with:
        //   "Input an integer: 25"
        //
        // We use print() (not println()) so the user's typed input
        // appears on the same line as the prompt.
        System.out.print("Input an integer: ");
        int number = scanner.nextInt();

        // ------------------------------------------------------------
        // STEP 3: Compute the number of factors
        // ------------------------------------------------------------
        // We use the optimized O(√n) approach described above.
        //
        // Walk i from 1 up to √number (inclusive):
        //     - If number % i == 0, then i is a factor.
        //         * If i == number / i (perfect square), count once.
        //         * Otherwise, count twice (i and number/i).
        //
        // The condition for the loop can be written as:
        //     i * i <= number     (avoiding floating-point sqrt)
        //
        // Using i * i <= number is preferred over Math.sqrt(number)
        // because it avoids rounding errors with floating-point
        // arithmetic near perfect squares.
        int factorCount = 0;

        for (int i = 1; i * i <= number; i++) {
            if (number % i == 0) {
                // i is a factor.
                if (i == number / i) {
                    // Perfect square — i and number/i are the same.
                    // Count only once.
                    factorCount += 1;
                } else {
                    // Two distinct factors: i and number/i.
                    factorCount += 2;
                }
            }
        }

        // ------------------------------------------------------------
        // STEP 4: Print the result
        // ------------------------------------------------------------
        // The expected output is just the count:
        //   "3"
        System.out.println(factorCount);

        // ------------------------------------------------------------
        // STEP 5: Close the Scanner
        // ------------------------------------------------------------
        scanner.close();

        // ------------------------------------------------------------
        // STEP 6: (Optional) Show which factors were found
        // ------------------------------------------------------------
        // Listing the factors makes the count verifiable and helps
        // illustrate the pairing property.
        System.out.println();
        System.out.println("Factors of " + number + ":");

        StringBuilder factorsList = new StringBuilder();
        int listed = 0;
        for (int i = 1; i <= number; i++) {
            if (number % i == 0) {
                if (listed > 0) {
                    factorsList.append(", ");
                }
                factorsList.append(i);
                listed++;
            }
        }
        System.out.println("  " + factorsList);
        System.out.println("  Count = " + listed);
        System.out.println("  Matches optimized count? " + (listed == factorCount));

        // ------------------------------------------------------------
        // STEP 7: (Optional) Verification trace of the pairing logic
        // ------------------------------------------------------------
        System.out.println();
        System.out.println("Pairing trace (only i up to √" + number + " is checked):");
        for (int i = 1; i * i <= number; i++) {
            if (number % i == 0) {
                int paired = number / i;
                if (i == paired) {
                    System.out.println("  i = " + i + " →  perfect square ("
                            + i + " × " + i + "), count += 1");
                } else {
                    System.out.println("  i = " + i + " →  factors " + i
                            + " and " + paired + ", count += 2");
                }
            }
        }
        System.out.println("  Total factors = " + factorCount);

        // ============================================================
        // ALTERNATIVE 1 — Static version (non-interactive)
        // ============================================================
        int staticNumber = 25;
        int staticCount = 0;
        for (int i = 1; i * i <= staticNumber; i++) {
            if (staticNumber % i == 0) {
                staticCount += (i == staticNumber / i) ? 1 : 2;
            }
        }
        System.out.println();
        System.out.println("Static version:");
        System.out.println("  Factors of 25 = " + staticCount);

        // ============================================================
        // ALTERNATIVE 2 — Trivial O(n) loop
        // ============================================================
        // The simplest implementation: test every integer from 1 to n.
        // Correct but slow for large n. Shown for comparison.
        int trivialCount = 0;
        for (int i = 1; i <= staticNumber; i++) {
            if (staticNumber % i == 0) {
                trivialCount++;
            }
        }
        System.out.println();
        System.out.println("Trivial O(n) version:");
        System.out.println("  Factors of 25 = " + trivialCount);
        System.out.println("  Matches optimized? " + (trivialCount == staticCount));

        // ============================================================
        // ALTERNATIVE 3 — Using a helper method
        // ============================================================
        // Encapsulating the count in a method makes it reusable and
        // gives it a descriptive name.
        System.out.println();
        System.out.println("Via helper method:");
        int[] testNumbers = {1, 2, 6, 12, 25, 28, 36, 100, 97, 1};
        for (int n : testNumbers) {
            System.out.printf("  countFactors(%3d) = %d%n", n, countFactors(n));
        }

        // ============================================================
        // ALTERNATIVE 4 — Handle edge cases
        // ============================================================
        // - number = 1: has exactly 1 factor (itself)
        // - prime numbers: have exactly 2 factors (1 and itself)
        // - perfect squares: the pair (√n, √n) counts only once
        System.out.println();
        System.out.println("Edge cases:");
        System.out.println("  countFactors(1)   = " + countFactors(1) + "  (1 factor: 1)");
        System.out.println("  countFactors(2)   = " + countFactors(2) + "  (2 factors: 1, 2 — prime)");
        System.out.println("  countFactors(97)  = " + countFactors(97) + "  (2 factors: 1, 97 — prime)");
        System.out.println("  countFactors(36)  = " + countFactors(36) + "  (9 factors: 1,2,3,4,6,9,12,18,36)");
        System.out.println("  countFactors(100) = " + countFactors(100) + "  (9 factors: 1,2,4,5,10,20,25,50,100)");

        // ============================================================
        // ALTERNATIVE 5 — Prime factorization approach
        // ============================================================
        // For a number n = p₁^a₁ × p₂^a₂ × ... × pₖ^aₖ,
        // the number of factors is:
        //     (a₁ + 1) × (a₂ + 1) × ... × (aₖ + 1)
        //
        // For n = 25 = 5²:  (2 + 1) = 3 factors
        // For n = 36 = 2² × 3²:  (2+1) × (2+1) = 9 factors
        // For n = 12 = 2² × 3:  (2+1) × (1+1) = 6 factors
        //
        // This is another O(√n) approach, sometimes preferred when
        // the prime factorization is needed anyway.
        System.out.println();
        System.out.println("Via prime factorization:");
        for (int n : testNumbers) {
            System.out.printf("  countFactorsByPrimeFactorization(%3d) = %d%n",
                    n, countFactorsByPrimeFactorization(n));
        }
    }

    /**
     * Counts the positive factors of a non-negative integer using the O(√n)
     * pairing approach.
     *
     * Factors come in pairs (d, n/d). For each d ≤ √n that divides n, either: -
     * d == n/d (perfect square) → count 1 - d != n/d → count 2
     *
     * @param n the integer whose factors to count (must be > 0)
     * @return the number of positive factors of n
     * @throws IllegalArgumentException if n <= 0
     */
    private static int countFactors(int n) {
        if (n <= 0) {
            throw new IllegalArgumentException("n must be positive.");
        }

        int count = 0;
        for (int i = 1; (long) i * i <= n; i++) {
            if (n % i == 0) {
                count += (i == n / i) ? 1 : 2;
            }
        }
        return count;
    }

    /**
     * Counts factors using prime factorization: for n = p₁^a₁ × p₂^a₂ × ... ×
     * pₖ^aₖ, the number of factors is (a₁+1)(a₂+1)...(aₖ+1).
     *
     * This is a valid alternative to the pairing approach and is O(√n) as well.
     *
     * @param n the integer whose factors to count (must be > 0)
     * @return the number of positive factors of n
     */
    private static int countFactorsByPrimeFactorization(int n) {
        if (n <= 0) {
            throw new IllegalArgumentException("n must be positive.");
        }
        if (n == 1) {
            return 1;
        }

        int count = 1;   // product of (exponent + 1)
        int remaining = n;

        // Extract all factors of 2.
        int exp = 0;
        while (remaining % 2 == 0) {
            remaining /= 2;
            exp++;
        }
        if (exp > 0) {
            count *= (exp + 1);
        }

        // Extract odd prime factors.
        for (int p = 3; (long) p * p <= remaining; p += 2) {
            exp = 0;
            while (remaining % p == 0) {
                remaining /= p;
                exp++;
            }
            if (exp > 0) {
                count *= (exp + 1);
            }
        }

        // If a prime factor remains, its exponent is 1.
        if (remaining > 1) {
            count *= 2;
        }
        return count;
    }
}
