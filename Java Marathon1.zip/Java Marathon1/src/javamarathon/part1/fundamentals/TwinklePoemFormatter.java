package javamarathon.part1.fundamentals;

/**
 *
 * @author botho
 */
public class TwinklePoemFormatter {

    public static void main(String[] args) {

        // ------------------------------------------------------------
        // STEP 1: Print each line of the poem
        // ------------------------------------------------------------
        // We use one println() per line, embedding '\t' for the
        // indentation. This produces exactly the required format.
        //
        // Note that each \t represents one "level" of indentation.
        // The pattern below is:
        //   Level 0  →  Line 1
        //   Level 1  →  Line 2
        //   Level 2  →  Line 3
        //   Level 2  →  Line 4
        //   Level 0  →  Line 5
        //   Level 1  →  Line 6
        // ---- Line 1: no indentation ----
        System.out.println("Twinkle, twinkle, little star,");

        // ---- Line 2: 1 tab (level 1) ----
        // The '\t' at the beginning shifts the line one indent level
        // to the right.
        System.out.println("\tHow I wonder what you are!");

        // ---- Line 3: 2 tabs (level 2) ----
        // The '\t\t' shifts the line two indent levels right, creating
        // the "deepest" indented portion of the poem.
        System.out.println("\t\tUp above the world so high,");

        // ---- Line 4: 2 tabs (level 2) ----
        // Matches the indentation of line 3, keeping these two lines
        // visually paired.
        System.out.println("\t\tLike a diamond in the sky.");

        // ---- Line 5: no indentation ----
        // Returns to the baseline, marking the poem's repetition.
        System.out.println("Twinkle, twinkle, little star,");

        // ---- Line 6: 1 tab (level 1) ----
        // The poem's closing line, indented one level — same as
        // line 2. This gives the poem a sense of returning to the
        // "chorus" after the deeply-indented verse.
        System.out.println("\tHow I wonder what you are");

        // ------------------------------------------------------------
        // ALTERNATIVE — Using string concatenation with a tab constant
        // ------------------------------------------------------------
        // If you prefer to make the indentation more explicit, use a
        // named constant for the tab and concatenate it. This makes
        // the "level" concept clearer and easier to change later.
        // ------------------------------------------------------------
        // final String TAB = "\t";
        // System.out.println("Twinkle, twinkle, little star,");
        // System.out.println(TAB + "How I wonder what you are!");
        // System.out.println(TAB + TAB + "Up above the world so high,");
        // System.out.println(TAB + TAB + "Like a diamond in the sky.");
        // System.out.println("Twinkle, twinkle, little star,");
        // System.out.println(TAB + "How I wonder what you are");
        // ------------------------------------------------------------
        // ALTERNATIVE — Using a loop with an indentation array
        // ------------------------------------------------------------
        // For longer poems, storing each line along with its indent
        // level in arrays and looping avoids repeating the print
        // statement. This is more scalable and easier to modify.
        // ------------------------------------------------------------
        // String[] lines = {
        //     "Twinkle, twinkle, little star,",
        //     "How I wonder what you are!",
        //     "Up above the world so high,",
        //     "Like a diamond in the sky.",
        //     "Twinkle, twinkle, little star,",
        //     "How I wonder what you are"
        // };
        // int[] indentLevels = { 0, 1, 2, 2, 0, 1 };
        // for (int i = 0; i < lines.length; i++) {
        //     StringBuilder indent = new StringBuilder();
        //     for (int t = 0; t < indentLevels[i]; t++) {
        //         indent.append('\t');
        //     }
        //     System.out.println(indent + lines[i]);
        // }
        // ------------------------------------------------------------
        // ALTERNATIVE — Using String.repeat() (Java 11+)
        // ------------------------------------------------------------
        // For modern Java, String.repeat(int) creates a string by
        // repeating the same sequence N times. Combined with the
        // arrays above, this gives a clean, one-line indentation:
        // ------------------------------------------------------------
        // for (int i = 0; i < lines.length; i++) {
        //     System.out.println("\t".repeat(indentLevels[i]) + lines[i]);
        // }
        // ------------------------------------------------------------
        // ALTERNATIVE — Using text blocks (Java 15+)
        // ------------------------------------------------------------
        // A text block (three double-quotes) preserves newlines and
        // leading whitespace literally. This makes multi-line strings
        // extremely readable and is ideal for poems. However, text
        // blocks cannot produce a literal tab via \t; they use real
        // whitespace characters instead.
        // ------------------------------------------------------------
        // String poem = """
        //         Twinkle, twinkle, little star,
        //         \tHow I wonder what you are!
        //         \t\tUp above the world so high,
        //         \t\tLike a diamond in the sky.
        //         Twinkle, twinkle, little star,
        //         \tHow I wonder what you are""";
        // System.out.println(poem);
        // ------------------------------------------------------------
        // STEP 2: (Optional) Print the poem with visible tab markers
        // ------------------------------------------------------------
        // To show that the tabs ARE present (rather than just spaces),
        // we can display each line with '\t' written as visible text.
        // This helps when debugging tab-related issues.
        // ------------------------------------------------------------
        System.out.println();
        System.out.println("--- With visible tab markers (\\t) ---");
        System.out.println("Twinkle, twinkle, little star,");
        System.out.println("\\tHow I wonder what you are!");
        System.out.println("\\t\\tUp above the world so high,");
        System.out.println("\\t\\tLike a diamond in the sky.");
        System.out.println("Twinkle, twinkle, little star,");
        System.out.println("\\tHow I wonder what you are");
    }
}
