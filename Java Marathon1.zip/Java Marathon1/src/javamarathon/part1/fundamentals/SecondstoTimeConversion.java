package javamarathon.part1.fundamentals;

import java.util.Scanner;

/**
 * Converts a given number of seconds into HH:MM:SS format.
 */
public class SecondstoTimeConversion {

    public static void main(String[] args) {
        // Read input
        Scanner scanner = new Scanner(System.in);
        System.out.print("Input seconds: ");
        int totalSeconds = scanner.nextInt();
        scanner.close();

        // Convert to hours, minutes, seconds
        int hours = totalSeconds / 3600;
        int minutes = (totalSeconds % 3600) / 60;
        int seconds = totalSeconds % 60;

        // Format and display
        String formatted = String.format("%02d:%02d:%02d", hours, minutes, seconds);
        System.out.println(formatted);
    }
}
