package javamarathon.part1.fundamentals;

/**
 *
 * @author botho
 */
public class FormattedDateandTime {

    public static void main(String[] args) {

        // ============================================================
        // APPROACH 1 — SimpleDateFormat (legacy, java.text)
        // ============================================================
        // SimpleDateFormat is part of java.text and has been available
        // since Java 1.1. It works with java.util.Date.
        //
        // WARNING: SimpleDateFormat is NOT thread-safe. If you share one
        // instance between multiple threads, you must synchronize access
        // or create a new instance per thread. In Java 8+, prefer
        // DateTimeFormatter instead.
        // Create a Date object capturing the current moment.
        java.util.Date now = new java.util.Date();

        // Define the custom pattern.
        // The pattern string uses letters as placeholders (see the
        // pattern reference in the comments above).
        java.text.SimpleDateFormat sdf = new java.text.SimpleDateFormat(
                "yyyy/MM/dd HH:mm:ss.SSS");

        // Format the Date into a String and print it.
        String formattedLegacy = sdf.format(now);
        System.out.println("Now: " + formattedLegacy);

        // ============================================================
        // APPROACH 2 — DateTimeFormatter (modern, java.time)
        // ============================================================
        // DateTimeFormatter is part of java.time.format and was
        // introduced in Java 8. It works with the java.time types
        // (LocalDateTime, ZonedDateTime, etc.) instead of java.util.Date.
        //
        // It is IMMUTABLE and THREAD-SAFE — safe to share across
        // threads without synchronization. This is the recommended
        // approach for all new code.
        // Create a formatter with the same pattern.
        java.time.format.DateTimeFormatter dtf
                = java.time.format.DateTimeFormatter.ofPattern(
                        "yyyy/MM/dd HH:mm:ss.SSS");

        // Obtain the current date and time.
        // LocalDateTime.now() captures the current moment in the
        // system's default time zone. It has no time zone information
        // attached — for a time-zone-aware value, use ZonedDateTime.now().
        java.time.LocalDateTime dateTime = java.time.LocalDateTime.now();

        // Format the LocalDateTime into a String and print it.
        String formattedModern = dtf.format(dateTime);
        System.out.println("Now (via DateTimeFormatter): " + formattedModern);

        // ============================================================
        // STEP 3: (Optional) Show the two outputs side by side
        // ============================================================
        // Both approaches should produce identical output for the same
        // pattern and moment. Showing them side by side confirms this.
        System.out.println();
        System.out.println("Comparison:");
        System.out.println("  SimpleDateFormat output   : " + formattedLegacy);
        System.out.println("  DateTimeFormatter output  : " + formattedModern);
        System.out.println("  Match?                    : "
                + formattedLegacy.equals(formattedModern));

        // ============================================================
        // STEP 4: (Optional) Show different patterns for the same moment
        // ============================================================
        // The power of formatters is the ability to produce many
        // different formats from the same instant. Below are several
        // common formats, all showing the SAME moment.
        System.out.println();
        System.out.println("Same moment, different patterns:");
        String[] patterns = {
            "yyyy-MM-dd", // ISO date
            "dd/MM/yyyy", // European date
            "MM/dd/yyyy", // US date
            "HH:mm:ss", // Time only (24h)
            "hh:mm:ss a", // Time only (12h with AM/PM)
            "EEEE, MMMM d, yyyy", // Full date
            "EEE MMM dd HH:mm:ss zzz yyyy", // Legacy Date.toString style
            "yyyy-MM-dd'T'HH:mm:ss.SSSXXX", // ISO-8601 with offset
            "yyyyMMdd_HHmmss", // Filename-safe timestamp
            "D", // Day of year
            "w", // Week of year
            "G" // Era (AD)
        };

        java.time.ZonedDateTime zdt = java.time.ZonedDateTime.now();
        for (String pattern : patterns) {
            java.time.format.DateTimeFormatter fmt
                    = java.time.format.DateTimeFormatter.ofPattern(pattern);
            System.out.printf("  %-30s → %s%n", pattern, fmt.format(zdt));
        }

        // ============================================================
        // STEP 5: (Optional) Verbose explanation of each pattern letter
        // ============================================================
        // Walk through each component of the required pattern so it's
        // clear what each one produces.
        System.out.println();
        System.out.println("Pattern letter reference for 'yyyy/MM/dd HH:mm:ss.SSS':");
        System.out.println("  yyyy  → year                (4-digit)");
        System.out.println("  /     → literal slash");
        System.out.println("  MM    → month               (2-digit, 01–12)");
        System.out.println("  /     → literal slash");
        System.out.println("  dd    → day of month        (2-digit, 01–31)");
        System.out.println("  (space) → literal space");
        System.out.println("  HH    → hour                (2-digit, 00–23, 24-hour)");
        System.out.println("  :     → literal colon");
        System.out.println("  mm    → minute              (2-digit, 00–59)");
        System.out.println("  :     → literal colon");
        System.out.println("  ss    → second              (2-digit, 00–59)");
        System.out.println("  .     → literal dot");
        System.out.println("  SSS   → millisecond         (3-digit, 000–999)");

        // ============================================================
        // STEP 6: (Optional) A note on millisecond precision
        // ============================================================
        // The 'SSS' pattern prints 3 digits for milliseconds.
        // On most systems, the actual clock precision is:
        //   - 1 ms on Linux (via System.currentTimeMillis())
        //   - ~15 ms on Windows (the historical clock tick)
        //   - Nanosecond precision available via Instant.now()
        //     (Java 9+ on modern Linux)
        //
        // So the last digit(s) of 'SSS' may not change on every run
        // on Windows. This is a platform limitation, not a bug.
        // ============================================================
        // ============================================================
        // ALTERNATIVE — Using String.format() with a Calendar
        // ============================================================
        // Before java.time, the traditional way to format dates in
        // a thread-safe manner was to use Calendar + String.format.
        // Shown here for historical completeness.
        // ============================================================
        // java.util.Calendar cal = java.util.Calendar.getInstance();
        // String s = String.format("%04d/%02d/%02d %02d:%02d:%02d.%03d",
        //         cal.get(java.util.Calendar.YEAR),
        //         cal.get(java.util.Calendar.MONTH) + 1,   // months are 0-based!
        //         cal.get(java.util.Calendar.DAY_OF_MONTH),
        //         cal.get(java.util.Calendar.HOUR_OF_DAY),
        //         cal.get(java.util.Calendar.MINUTE),
        //         cal.get(java.util.Calendar.SECOND),
        //         cal.get(java.util.Calendar.MILLISECOND));
        // System.out.println("Now (via Calendar): " + s);
    }
}
