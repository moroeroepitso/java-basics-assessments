package javamarathon.part1.fundamentals;

/**
 *
 * @author botho
 */
public class DisplaySystemTime {

    public static void main(String[] args) {

        // ------------------------------------------------------------
        // STEP 1: Create a Date object representing the current instant
        // ------------------------------------------------------------
        // The no-argument constructor of java.util.Date captures the
        // current moment from the system clock, stored internally as
        // milliseconds since the epoch (1970-01-01 00:00:00 UTC).
        //
        // Note: 'new Date()' does NOT read the time zone or calendar —
        // it just records the current millisecond count. The time zone
        // only comes into play when the Date is FORMATTED for display
        // (via toString() or SimpleDateFormat).
        java.util.Date currentDate = new java.util.Date();

        // ------------------------------------------------------------
        // STEP 2: Print the Date's default string representation
        // ------------------------------------------------------------
        // The expected output format is:
        //   "Current Date time: Fri Jun 16 14:17:40 IST 2017"
        //
        // Date.toString() automatically produces the format:
        //   dow mon dd hh:mm:ss zzz yyyy
        //
        // Concatenating a Date with a String implicitly calls its
        // toString() method, so no explicit call is needed.
        System.out.println("Current Date time: " + currentDate);

        // ------------------------------------------------------------
        // STEP 3: (Optional) Print the underlying epoch milliseconds
        // ------------------------------------------------------------
        // getTime() returns the number of milliseconds since the epoch.
        // This is the ACTUAL data stored inside a Date — no time zone
        // involved. It's the same value regardless of where the JVM
        // is running (as long as the system clocks agree).
        System.out.println();
        System.out.println("Additional information:");
        System.out.println("  Epoch milliseconds : " + currentDate.getTime());
        System.out.println("  Epoch seconds      : " + (currentDate.getTime() / 1000));

        // ------------------------------------------------------------
        // STEP 4: (Optional) Show which time zone was used for display
        // ------------------------------------------------------------
        // The time zone abbreviation in the toString() output comes
        // from the JVM's default time zone, which is inherited from
        // the operating system at startup.
        //
        // java.util.TimeZone.getDefault() returns the default time
        // zone as a TimeZone object.
        java.util.TimeZone tz = java.util.TimeZone.getDefault();
        System.out.println("  Default time zone  : " + tz.getDisplayName());
        System.out.println("  Time zone ID       : " + tz.getID());
        System.out.println("  Raw UTC offset (ms): " + tz.getRawOffset());
        System.out.println("  Total UTC offset(ms): " + tz.getOffset(currentDate.getTime()));

        // ------------------------------------------------------------
        // STEP 5: (Optional) Compare with modern java.time API
        // ------------------------------------------------------------
        // The java.time package (Java 8+) provides more explicit and
        // immutable types for dates and times:
        //   Instant        →  a moment on the timeline (UTC)
        //   LocalDateTime  →  a date + time WITHOUT a time zone
        //   ZonedDateTime  →  a date + time WITH a time zone
        //   OffsetDateTime →  a date + time with a fixed offset
        //
        // The block below shows the equivalent modern representation
        // for comparison.
        System.out.println();
        System.out.println("Modern java.time equivalents:");
        System.out.println("  Instant         : " + java.time.Instant.now());
        System.out.println("  ZonedDateTime   : " + java.time.ZonedDateTime.now());
        System.out.println("  OffsetDateTime  : " + java.time.OffsetDateTime.now());

        // ============================================================
        // NOTE — About the "IST" time zone abbreviation in the example
        // ============================================================
        // The abbreviation "IST" is ambiguous — it can mean:
        //   - Indian Standard Time     (UTC+05:30)
        //   - Irish Standard Time      (UTC+01:00)
        //   - Israel Standard Time     (UTC+02:00)
        //
        // The 2017 date and the +05:30 offset in the example suggest
        // Indian Standard Time was intended. In your own run, you will
        // likely see a different abbreviation depending on your
        // machine's time zone — for example, "PST" (Pacific), "EST"
        // (Eastern), "GMT" (Greenwich), or "UTC".
        //
        // To force a specific time zone for the display, you would use
        // SimpleDateFormat with setTimeZone(...) — but that would no
        // longer be the "default" representation, so it's out of scope
        // for this exercise.
        // ============================================================
        // ============================================================
        // ALTERNATIVE — Using java.time.Instant for the current moment
        // ============================================================
        // If you need a "date" without any formatting at all, use:
        //     java.time.Instant now = java.time.Instant.now();
        //
        // Its toString() returns an ISO-8601 UTC timestamp, e.g.:
        //     2024-01-15T10:30:45.123456789Z
        //
        // This format is unambiguous (always UTC, always ISO) and is
        // preferred for logging, serialization, and persistence.
        // ============================================================
        // ============================================================
        // ALTERNATIVE — Using SimpleDateFormat (custom formatting)
        // ============================================================
        // If you wanted to control the format, SimpleDateFormat (from
        // java.text) is the legacy way:
        //
        //     SimpleDateFormat sdf = new SimpleDateFormat(
        //             "EEE MMM dd HH:mm:ss zzz yyyy", Locale.ENGLISH);
        //     System.out.println(sdf.format(new Date()));
        //
        // Modern equivalent (java.time.format.DateTimeFormatter):
        //
        //     DateTimeFormatter dtf = DateTimeFormatter.ofPattern(
        //             "EEE MMM dd HH:mm:ss zzz yyyy", Locale.ENGLISH);
        //     System.out.println(dtf.format(ZonedDateTime.now()));
        //
        // Both produce output very similar to Date.toString(). But
        // since this exercise asks for the DEFAULT representation, we
        // simply use Date.toString() — no formatter needed.
        // ============================================================
    }
}
