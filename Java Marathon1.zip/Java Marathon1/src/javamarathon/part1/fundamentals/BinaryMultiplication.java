package javamarathon.part1.fundamentals;

/**
 *
 * @author botho
 */
public class BinaryMultiplication {
  
    public static void main(String[] args) {

        // ------------------------------------------------------------
        // STEP 1: Declare the two binary numbers as Strings
        // ------------------------------------------------------------
        // Storing binary values as String preserves their binary meaning
        // and allows leading zeros (e.g., "0011") if needed.
        String binary1 = "10";   // 2 in decimal
        String binary2 = "11";   // 3 in decimal

        // ------------------------------------------------------------
        // STEP 2: Convert each binary string to a decimal integer
        // ------------------------------------------------------------
        // Integer.parseInt(String, radix) interprets the string as a
        // number in the given base. Passing radix = 2 tells Java to
        // treat the string as binary.
        //
        //   Integer.parseInt("10", 2)  =  2
        //   Integer.parseInt("11", 2)  =  3
        int decimal1 = Integer.parseInt(binary1, 2);
        int decimal2 = Integer.parseInt(binary2, 2);

        // ------------------------------------------------------------
        // STEP 3: Multiply the two decimal integers
        // ------------------------------------------------------------
        // Standard integer multiplication. The result is 2 × 3 = 6.
        int decimalProduct = decimal1 * decimal2;

        // ------------------------------------------------------------
        // STEP 4: Convert the decimal product back to a binary string
        // ------------------------------------------------------------
        // Integer.toBinaryString(int) returns the binary representation
        // of the given integer as a String, without leading zeros.
        //
        //   Integer.toBinaryString(6)  =  "110"
        String binaryProduct = Integer.toBinaryString(decimalProduct);

        // ------------------------------------------------------------
        // STEP 5: Print the result
        // ------------------------------------------------------------
        // The required output format is:
        //   "Product of two binary numbers: 110"
        System.out.println("Product of two binary numbers: " + binaryProduct);

        // ------------------------------------------------------------
        // STEP 6: (Optional) Print a verification trace
        // ------------------------------------------------------------
        // Showing the intermediate decimal values helps confirm that
        // the conversion was done correctly.
        System.out.println();
        System.out.println("Verification trace:");
        System.out.println("  binary1 = " + binary1 + "  →  decimal " + decimal1);
        System.out.println("  binary2 = " + binary2 + "  →  decimal " + decimal2);
        System.out.println("  decimal product = " + decimal1 + " × " + decimal2
                         + " = " + decimalProduct);
        System.out.println("  binary  product = " + binaryProduct);

        // ============================================================
        // ALTERNATIVE APPROACH — Manual binary multiplication
        // ============================================================
        // This method simulates the "shift and add" algorithm taught
        // in textbooks. Binary multiplication is conceptually identical
        // to decimal multiplication: each digit of the multiplier is
        // multiplied against the multiplicand, and the partial results
        // are shifted left and added together.
        //
        // BINARY MULTIPLICATION RULES (single-bit):
        //   0 × 0 = 0
        //   0 × 1 = 0
        //   1 × 0 = 0
        //   1 × 1 = 1
        //
        // WORKING TRACE with binary1 = "10", binary2 = "11":
        //
        //           1 0          ← multiplicand (2)
        //         × 1 1          ← multiplier   (3)
        //         -------
        //           1 0          ← partial product 1 (10 × rightmost 1)
        //         1 0            ← partial product 2 (10 × next 1, shifted left)
        //         -------
        //         1 1 0          ← final sum (6 in decimal)
        //
        // Each partial product is either the multiplicand itself (when
        // the multiplier bit is 1) or zero (when the multiplier bit is 0),
        // then shifted left by the bit's position.
        // ============================================================
        String manualBinaryProduct = multiplyBinaryStrings(binary1, binary2);
        System.out.println();
        System.out.println("Manual binary multiplication result: " + manualBinaryProduct);

        // ------------------------------------------------------------
        // BONUS: Try more examples to confirm the logic
        // ------------------------------------------------------------
        // Uncomment the lines below to test other binary multiplications.
        // ------------------------------------------------------------
        // System.out.println("\nMore examples:");
        // System.out.println("  1 × 1     = " + multiplyBinaryStrings("1", "1"));         // 1
        // System.out.println("  101 × 10  = " + multiplyBinaryStrings("101", "10"));     // 1010
        // System.out.println("  111 × 11  = " + multiplyBinaryStrings("111", "11"));     // 10101
        // System.out.println("  1001 × 11 = " + multiplyBinaryStrings("1001", "11"));   // 11011
    }

    /**
     * Multiplies two binary strings and returns their product as a
     * binary string.
     * 
     * This method performs manual binary multiplication without relying
     * on Integer.parseInt or Integer.toBinaryString. It uses the
     * classic "shift and add" algorithm:
     * 
     *   1. For each bit of the multiplier (from right to left):
     *        - If the bit is '1', add the multiplicand, shifted left
     *          by the bit's position, to a running total.
     *        - If the bit is '0', add nothing.
     *   2. Return the accumulated total as a binary string.
     * 
     * @param b1 the multiplicand as a binary string (e.g., "10")
     * @param b2 the multiplier   as a binary string (e.g., "11")
     * @return   the binary product as a String (e.g., "110")
     */
    private static String multiplyBinaryStrings(String b1, String b2) {

        // Handle the special case of multiplying by zero.
        // "0" × anything = "0".
        if (b1.equals("0") || b2.equals("0")) {
            return "0";
        }

        // 'accumulator' holds the running sum of partial products,
        // always stored as a binary string.
        String accumulator = "0";

        // Loop through each bit of the multiplier (b2), from the
        // rightmost (least significant) bit to the leftmost.
        for (int i = b2.length() - 1; i >= 0; i--) {

            // Fetch the current multiplier bit.
            char multiplierBit = b2.charAt(i);

            // Compute the position of this bit from the right edge.
            // The rightmost bit is at position 0, the next at 1, etc.
            int shift = b2.length() - 1 - i;

            // If the multiplier bit is '1', we add the multiplicand
            // shifted left by 'shift' positions to the accumulator.
            // If the bit is '0', the partial product is zero, and we
            // skip the addition.
            if (multiplierBit == '1') {

                // Shift the multiplicand left by appending zeros.
                // Left-shifting a binary number by n positions is
                // equivalent to multiplying it by 2^n.
                StringBuilder shifted = new StringBuilder(b1);
                for (int s = 0; s < shift; s++) {
                    shifted.append('0');
                }

                // Add the shifted multiplicand to the accumulator
                // using the binary addition routine below.
                accumulator = addBinaryStrings(accumulator, shifted.toString());
            }
            // If the bit is '0', nothing needs to be added.
        }

        // Strip any leading zeros that might have accumulated.
        // For example, "00110" should become "110".
        int firstOne = 0;
        while (firstOne < accumulator.length() - 1
                && accumulator.charAt(firstOne) == '0') {
            firstOne++;
        }
        return accumulator.substring(firstOne);
    }

    /**
     * Adds two binary strings and returns their sum as a binary string.
     * 
     * This is a reusable helper method that performs binary addition
     * using simple carry logic. It is used by multiplyBinaryStrings()
     * to add each partial product to the accumulator.
     * 
     * @param b1 the first binary string
     * @param b2 the second binary string
     * @return   the binary sum as a String
     */
    private static String addBinaryStrings(String b1, String b2) {

        // StringBuilder builds the result efficiently in reverse order.
        StringBuilder result = new StringBuilder();

        // Two pointers, starting at the rightmost character of each string.
        int i = b1.length() - 1;
        int j = b2.length() - 1;

        // 'carry' holds any overflow (0 or 1) from the previous column.
        int carry = 0;

        // Loop while there are bits left in either string, OR a carry
        // remains to be written.
        while (i >= 0 || j >= 0 || carry > 0) {

            // Fetch the current bit from each string, or 0 if we have
            // already consumed that string. Character '1' - '0' = 1,
            // and '0' - '0' = 0, so subtracting '0' converts the char
            // digit into an integer value.
            int bit1 = (i >= 0) ? b1.charAt(i) - '0' : 0;
            int bit2 = (j >= 0) ? b2.charAt(j) - '0' : 0;

            // Sum the two bits plus the carry.
            int bitSum = bit1 + bit2 + carry;

            // Result bit is the sum modulo 2; new carry is the sum / 2.
            result.append(bitSum % 2);
            carry = bitSum / 2;

            // Move both pointers one step to the left.
            i--;
            j--;
        }

        // Bits were appended right-to-left; reverse for normal order.
        return result.reverse().toString();
    }
}

