package javamarathon.part1.fundamentals;

import java.util.Arrays;

/**
 *
 * @author botho
 */
public class PartitionEvenandOdd {

    public static void main(String[] args) {

        // ------------------------------------------------------------
        // STEP 1: Declare the original array
        // ------------------------------------------------------------
        int[] array = {7, 2, 4, 1, 3, 5, 6, 8, 2, 10};

        // ------------------------------------------------------------
        // STEP 2: Print the original array
        // ------------------------------------------------------------
        // The expected output format is:
        //   "Original array: [7, 2, 4, 1, 3, 5, 6, 8, 2, 10]"
        System.out.println("Original array: " + Arrays.toString(array));

        // ------------------------------------------------------------
        // STEP 3: Partition the array in place (evens first, then odds)
        // ------------------------------------------------------------
        // We call a helper that performs the two-pointer partition.
        // The array is modified in place.
        //
        // IMPORTANT: because Java arrays are reference types, the
        // helper method receives a REFERENCE to the same array, so
        // changes made inside the method are visible to the caller.
        partitionEvenOdd(array);

        // ------------------------------------------------------------
        // STEP 4: Print the partitioned array
        // ------------------------------------------------------------
        // The expected output format is:
        //   "After partition the said array becomes: [10, 2, 4, 2, 8, 6, 5, 3, 1, 7]"
        System.out.println("After partition the said array becomes: "
                + Arrays.toString(array));

        // ============================================================
        // STEP 5: (Optional) Verification
        // ============================================================
        // Confirm the partition property: no even number appears after
        // any odd number. This is the defining characteristic of a
        // valid partition.
        System.out.println();
        System.out.println("Verification:");
        System.out.println("  First even appears at index 0? "
                + (array[0] % 2 == 0));

        // Find the boundary where odds begin.
        int firstOddIndex = -1;
        for (int i = 0; i < array.length; i++) {
            if (array[i] % 2 != 0) {
                firstOddIndex = i;
                break;
            }
        }

        boolean noEvenAfterOdd = true;
        if (firstOddIndex >= 0) {
            for (int i = firstOddIndex; i < array.length; i++) {
                if (array[i] % 2 == 0) {
                    noEvenAfterOdd = false;
                    break;
                }
            }
        }

        System.out.println("  First odd index       : " + firstOddIndex);
        System.out.println("  All evens before odds?: " + noEvenAfterOdd);

        // Count evens and odds to confirm none were lost.
        int evens = 0, odds = 0;
        for (int value : array) {
            if (value % 2 == 0) {
                evens++;
            } else {
                odds++;
            }
        }
        System.out.println("  Even count            : " + evens);
        System.out.println("  Odd count             : " + odds);
        System.out.println("  Total count           : " + array.length);

        // ============================================================
        // ALTERNATIVE 1 — Static version demonstrating the algorithm
        // ============================================================
        // The same algorithm, shown inline for clarity.
        // ============================================================
        int[] demo = {7, 2, 4, 1, 3, 5, 6, 8, 2, 10};
        int left = 0;
        int right = demo.length - 1;

        while (left < right) {
            // Move 'left' forward while it points to an even number.
            while (left < right && demo[left] % 2 == 0) {
                left++;
            }
            // Move 'right' backward while it points to an odd number.
            while (left < right && demo[right] % 2 != 0) {
                right--;
            }
            // If pointers haven't crossed, swap the out-of-place
            // elements: an odd on the left and an even on the right.
            if (left < right) {
                int temp = demo[left];
                demo[left] = demo[right];
                demo[right] = temp;
                left++;
                right--;
            }
        }

        System.out.println();
        System.out.println("Via inline two-pointer partition:");
        System.out.println("  " + Arrays.toString(demo));

        // ============================================================
        // ALTERNATIVE 2 — Stable partition (preserves original order)
        // ============================================================
        // This approach preserves the relative order of elements within
        // each group. The result differs from the expected output but
        // is still a valid "evens first, then odds" partition.
        //
        // For the given input:
        //     Even order preserved: [2, 4, 6, 8, 2, 10]
        //     Odd  order preserved: [7, 1, 3, 5]
        //     Combined: [2, 4, 6, 8, 2, 10, 7, 1, 3, 5]
        // ============================================================
        int[] stable = stablePartitionEvenOdd(new int[]{7, 2, 4, 1, 3, 5, 6, 8, 2, 10});
        System.out.println();
        System.out.println("Stable partition (order preserved):");
        System.out.println("  " + Arrays.toString(stable));

        // ============================================================
        // ALTERNATIVE 3 — Using lists for clarity
        // ============================================================
        // The most readable stable version: collect evens and odds
        // into separate lists, then concatenate.
        // ============================================================
        java.util.List<Integer> evenList = new java.util.ArrayList<>();
        java.util.List<Integer> oddList = new java.util.ArrayList<>();

        for (int value : new int[]{7, 2, 4, 1, 3, 5, 6, 8, 2, 10}) {
            if (value % 2 == 0) {
                evenList.add(value);
            } else {
                oddList.add(value);
            }
        }
        evenList.addAll(oddList);

        System.out.println();
        System.out.println("Via lists (stable):");
        System.out.println("  Evens: " + evenList.subList(0, evenList.size() - oddList.size()));
        System.out.println("  Odds : " + oddList);
        System.out.println("  Combined: " + evenList);

        // ============================================================
        // ALTERNATIVE 4 — Using streams (Java 8+)
        // ============================================================
        // A concise functional alternative for stable partitioning.
        //
        //     int[] partitioned = IntStream.concat(
        //             IntStream.of(original).filter(n -> n % 2 == 0),
        //             IntStream.of(original).filter(n -> n % 2 != 0)
        //     ).toArray();
        // ============================================================
        int[] original = {7, 2, 4, 1, 3, 5, 6, 8, 2, 10};
        int[] streamPartitioned = java.util.stream.IntStream.concat(
                java.util.stream.IntStream.of(original).filter(n -> n % 2 == 0),
                java.util.stream.IntStream.of(original).filter(n -> n % 2 != 0)
        ).toArray();

        System.out.println();
        System.out.println("Via streams (stable):");
        System.out.println("  " + Arrays.toString(streamPartitioned));

        // ============================================================
        // ALTERNATIVE 5 — Testing multiple arrays
        // ============================================================
        System.out.println();
        System.out.println("Test sweep (two-pointer in-place):");
        int[][] tests = {
            {7, 2, 4, 1, 3, 5, 6, 8, 2, 10}, // given
            {1, 3, 5, 7}, // all odd
            {2, 4, 6, 8}, // all even
            {1, 2}, // one of each
            {1}, // single odd
            {2}, // single even
            {}, // empty
            {5, 3, 1, 2, 4, 6}, // odds then evens
            {2, 4, 6, 1, 3, 5} // evens then odds (already partitioned)
        };

        for (int[] test : tests) {
            int[] copy = Arrays.copyOf(test, test.length);
            partitionEvenOdd(copy);
            System.out.printf("  %-35s → %s%n",
                    Arrays.toString(test), Arrays.toString(copy));
        }
    }

    /**
     * Partitions an array IN PLACE so that all even numbers appear before all
     * odd numbers.
     *
     * Uses the two-pointer (Hoare-style) partition: - 'left' starts at 0 and
     * moves right, looking for an odd number. - 'right' starts at length − 1
     * and moves left, looking for an even number. - When both find out-of-place
     * elements, swap them. - Repeat until the pointers cross.
     *
     * Time complexity: O(n) — each element is examined at most once. Space
     * complexity: O(1) — no extra storage beyond a temp variable.
     *
     * Note: this partition is NOT stable. The relative order of the even
     * numbers (and of the odd numbers) is not preserved. If stability is
     * required, use a stable partition approach instead.
     *
     * @param arr the array to partition in place (may be null or empty)
     */
    private static void partitionEvenOdd(int[] arr) {
        if (arr == null || arr.length <= 1) {
            return;   // nothing to do
        }

        int left = 0;
        int right = arr.length - 1;

        while (left < right) {
            // Advance 'left' while it points to an even number.
            // Condition 'left < right' guards against running past
            // the 'right' pointer if all elements are even.
            while (left < right && arr[left] % 2 == 0) {
                left++;
            }

            // Retreat 'right' while it points to an odd number.
            while (left < right && arr[right] % 2 != 0) {
                right--;
            }

            // If pointers haven't crossed, arr[left] is odd and
            // arr[right] is even. Swap them to put the even one
            // earlier and the odd one later.
            if (left < right) {
                int temp = arr[left];
                arr[left] = arr[right];
                arr[right] = temp;
                left++;
                right--;
            }
        }
    }

    /**
     * Partitions an array into evens followed by odds, PRESERVING the original
     * relative order of elements within each group.
     *
     * Returns a NEW array; the input is not modified.
     *
     * Time complexity: O(n). Space complexity: O(n) — allocates a new array.
     *
     * @param arr the input array
     * @return a new array with evens first (in original order), then odds (in
     * original order)
     */
    private static int[] stablePartitionEvenOdd(int[] arr) {
        if (arr == null || arr.length == 0) {
            return new int[0];
        }

        // First pass: count evens and odds.
        int evenCount = 0;
        for (int value : arr) {
            if (value % 2 == 0) {
                evenCount++;
            }
        }

        // Allocate the result array.
        int[] result = new int[arr.length];

        // Second pass: fill evens from the start, odds from evenCount.
        int evenIndex = 0;
        int oddIndex = evenCount;
        for (int value : arr) {
            if (value % 2 == 0) {
                result[evenIndex++] = value;
            } else {
                result[oddIndex++] = value;
            }
        }

        return result;
    }
}
