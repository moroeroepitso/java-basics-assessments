package javamarathon.part1.fundamentals;

/**
 *
 * @author botho
 */
public class BinaryAddition {

    public static void main(String[] args) {

        // ------------------------------------------------------------
        // STEP 1: Declare the two binary numbers as Strings
        // ------------------------------------------------------------
        // Storing binary values as String preserves their binary meaning
        // and allows leading zeros (e.g., "0011") if needed.
        String binary1 = "10";   // 2 in decimal
        String binary2 = "11";   // 3 in decimal

        // ------------------------------------------------------------
        // STEP 2: Convert each binary string to a decimal integer
        // ------------------------------------------------------------
        // Integer.parseInt(String, radix) interprets the string as a
        // number in the given base. Passing radix = 2 tells Java to
        // treat the string as binary.
        //
        //   Integer.parseInt("10", 2)  =  2
        //   Integer.parseInt("11", 2)  =  3
        int decimal1 = Integer.parseInt(binary1, 2);
        int decimal2 = Integer.parseInt(binary2, 2);

        // ------------------------------------------------------------
        // STEP 3: Add the two decimal integers
        // ------------------------------------------------------------
        // Standard integer addition. The result is 2 + 3 = 5 in decimal.
        int decimalSum = decimal1 + decimal2;

        // ------------------------------------------------------------
        // STEP 4: Convert the decimal sum back to a binary string
        // ------------------------------------------------------------
        // Integer.toBinaryString(int) returns the binary representation
        // of the given integer as a String, without leading zeros.
        //
        //   Integer.toBinaryString(5)  =  "101"
        String binarySum = Integer.toBinaryString(decimalSum);

        // ------------------------------------------------------------
        // STEP 5: Print the result
        // ------------------------------------------------------------
        // The required output format is:
        //   "Sum of two binary numbers: 101"
        System.out.println("Sum of two binary numbers: " + binarySum);

        // ------------------------------------------------------------
        // STEP 6: (Optional) Print a verification trace
        // ------------------------------------------------------------
        // Showing the intermediate decimal values helps confirm that
        // the conversion was done correctly.
        System.out.println();
        System.out.println("Verification trace:");
        System.out.println("  binary1 = " + binary1 + "  →  decimal " + decimal1);
        System.out.println("  binary2 = " + binary2 + "  →  decimal " + decimal2);
        System.out.println("  decimal sum    = " + decimal1 + " + " + decimal2
                + " = " + decimalSum);
        System.out.println("  binary  sum    = " + binarySum);

        // ============================================================
        // ALTERNATIVE APPROACH — Manual binary addition (no built-ins)
        // ============================================================
        // This method simulates what a computer does at the hardware
        // level: it walks through both binary strings from right to
        // left, adds corresponding bits along with any carry, and
        // writes down each result bit.
        //
        // Binary addition rules:
        //   0 + 0 + 0  =  0, carry 0
        //   0 + 1 + 0  =  1, carry 0
        //   1 + 0 + 0  =  1, carry 0
        //   1 + 1 + 0  =  0, carry 1
        //   0 + 0 + 1  =  1, carry 0
        //   0 + 1 + 1  =  0, carry 1
        //   1 + 0 + 1  =  0, carry 1
        //   1 + 1 + 1  =  1, carry 1
        //
        // Working trace with binary1 = "10", binary2 = "11":
        //
        //   Rightmost bit:  0 + 1 + 0 carry = 1  →  result "1", carry 0
        //   Next bit:       1 + 1 + 0 carry = 2  →  result "0", carry 1
        //   No more bits:   carry = 1            →  prepend "1"
        //
        //   Final: reverse "101" → "101"
        // ============================================================
        String manualBinarySum = addBinaryStrings(binary1, binary2);
        System.out.println();
        System.out.println("Manual binary addition result: " + manualBinarySum);

        // ------------------------------------------------------------
        // BONUS: Try more examples to confirm the logic
        // ------------------------------------------------------------
        // Uncomment the lines below to test other binary additions.
        // ------------------------------------------------------------
        // System.out.println("\nMore examples:");
        // System.out.println("  1 + 1     = " + addBinaryStrings("1", "1"));         // 10
        // System.out.println("  101 + 1   = " + addBinaryStrings("101", "1"));     // 110
        // System.out.println("  111 + 1   = " + addBinaryStrings("111", "1"));     // 1000
        // System.out.println("  1001 + 11 = " + addBinaryStrings("1001", "11"));   // 1100
    }

    /**
     * Adds two binary strings and returns their sum as a binary string.
     *
     * This method performs manual binary addition without relying on
     * Integer.parseInt or Integer.toBinaryString. It walks both strings from
     * right to left, computes the bit sum at each position, tracks the carry,
     * and assembles the result.
     *
     * @param b1 the first binary string (e.g., "10")
     * @param b2 the second binary string (e.g., "11")
     * @return the binary sum as a String (e.g., "101")
     */
    private static String addBinaryStrings(String b1, String b2) {

        // StringBuilder builds the result efficiently in reverse order.
        // We append bits from right to left, then reverse at the end.
        StringBuilder result = new StringBuilder();

        // Two pointers, starting at the rightmost character of each string.
        int i = b1.length() - 1;
        int j = b2.length() - 1;

        // 'carry' holds any overflow (0 or 1) from the previous column.
        int carry = 0;

        // Loop while there are still bits to process in either string,
        // OR while there is a carry left over.
        while (i >= 0 || j >= 0 || carry > 0) {

            // Fetch the current bit from each string, or 0 if we have
            // already consumed that string. Character '1' - '0' = 1,
            // and '0' - '0' = 0, so subtracting '0' converts the char
            // digit into an integer value.
            int bit1 = (i >= 0) ? b1.charAt(i) - '0' : 0;
            int bit2 = (j >= 0) ? b2.charAt(j) - '0' : 0;

            // Sum the two bits plus the carry from the previous column.
            // The total is always between 0 and 3.
            int bitSum = bit1 + bit2 + carry;

            // The result bit is the sum modulo 2 (0 or 1).
            // The new carry is the sum divided by 2 (0 or 1).
            result.append(bitSum % 2);
            carry = bitSum / 2;

            // Move both pointers one step to the left.
            i--;
            j--;
        }

        // The bits were appended from right to left, so reverse to
        // get the final binary string in the normal left-to-right order.
        return result.reverse().toString();
    }
}
