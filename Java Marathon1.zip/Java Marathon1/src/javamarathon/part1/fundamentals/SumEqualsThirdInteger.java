package javamarathon.part1.fundamentals;

import java.util.Scanner;

/**
 *
 * @author botho
 */
public class SumEqualsThirdInteger {

    public static void main(String[] args) {

        // ------------------------------------------------------------
        // STEP 1: Create a Scanner to read input from the keyboard
        // ------------------------------------------------------------
        Scanner scanner = new Scanner(System.in);

        // ------------------------------------------------------------
        // STEP 2: Prompt for and read each of the three numbers
        // ------------------------------------------------------------
        // The prompts match the expected output exactly, including
        // the specific spacing before each colon:
        //   "Input the first number : 5"   ← space before colon
        //   "Input the second number: 10"  ← no space before colon
        //   "Input the third number : 15"  ← space before colon
        //
        // These inconsistencies are in the problem statement's
        // expected output, so we reproduce them exactly.
        //
        // We use print() (not println()) so the user's typed input
        // appears on the same line as the prompt.
        System.out.print("Input the first number : ");
        int first = scanner.nextInt();

        System.out.print("Input the second number: ");
        int second = scanner.nextInt();

        System.out.print("Input the third number : ");
        int third = scanner.nextInt();

        // ------------------------------------------------------------
        // STEP 3: Compute the sum of the first two numbers
        // ------------------------------------------------------------
        // The addition is straightforward integer arithmetic.
        int sum = first + second;

        // ------------------------------------------------------------
        // STEP 4: Compare the sum with the third number
        // ------------------------------------------------------------
        // The '==' operator returns a boolean:
        //     true   if sum equals third
        //     false  otherwise
        //
        // For (5, 10, 15):
        //     sum  = 5 + 10 = 15
        //     15 == 15  →  true
        boolean result = (sum == third);

        // ------------------------------------------------------------
        // STEP 5: Print the result
        // ------------------------------------------------------------
        // The required output format is:
        //   "The result is: true"
        //
        // Java's boolean printing produces lowercase "true" or "false",
        // matching the expected output exactly.
        System.out.println("The result is: " + result);

        // ------------------------------------------------------------
        // STEP 6: Close the Scanner
        // ------------------------------------------------------------
        scanner.close();

        // ------------------------------------------------------------
        // STEP 7: (Optional) Print verification details
        // ------------------------------------------------------------
        // A short trace helps confirm the computation.
        System.out.println();
        System.out.println("Verification trace:");
        System.out.println("  first  = " + first);
        System.out.println("  second = " + second);
        System.out.println("  sum    = " + first + " + " + second + " = " + sum);
        System.out.println("  third  = " + third);
        System.out.println("  sum == third?  " + sum + " == " + third
                + "  →  " + result);

        // ============================================================
        // ALTERNATIVE — Static (non-interactive) version
        // ============================================================
        // If the three numbers are fixed, no input is needed. The
        // entire computation reduces to a single boolean expression.
        // ============================================================
        int f = 5, s = 10, t = 15;
        boolean staticResult = (f + s) == t;

        System.out.println();
        System.out.println("Static version:");
        System.out.println("  (5 + 10) == 15  →  " + staticResult);

        // ============================================================
        // ALTERNATIVE — Using a helper method
        // ============================================================
        // Wrapping the test in a method makes it reusable and gives
        // the logic a name: "does the sum of a and b equal c?"
        // ============================================================
        System.out.println();
        System.out.println("Via helper method:");
        System.out.println("  sumEqualsThird(5, 10, 15)   = " + sumEqualsThird(5, 10, 15));
        System.out.println("  sumEqualsThird(5, 10, 20)   = " + sumEqualsThird(5, 10, 20));
        System.out.println("  sumEqualsThird(0, 0, 0)     = " + sumEqualsThird(0, 0, 0));
        System.out.println("  sumEqualsThird(-5, 10, 5)   = " + sumEqualsThird(-5, 10, 5));

        // ============================================================
        // ALTERNATIVE — Reading from command-line arguments
        // ============================================================
        // When run as `java SumEqualsThird 5 10 15`, the args array
        // contains ["5", "10", "15"]. This is useful for testing
        // and scripting. Uncomment the block below to try it.
        // ============================================================
        // if (args.length == 3) {
        //     int a1 = Integer.parseInt(args[0]);
        //     int a2 = Integer.parseInt(args[1]);
        //     int a3 = Integer.parseInt(args[2]);
        //     System.out.println("From args: " + ((a1 + a2) == a3));
        // }
        // ============================================================
        // ALTERNATIVE — Using a more general version
        // ============================================================
        // What if instead of "sum", we wanted to test any of the
        // four basic operations? The helper below takes the operation
        // as a parameter. Useful for exercises that ask for the same
        // pattern with different operators.
        // ============================================================
        System.out.println();
        System.out.println("Generalized version (any operation):");
        System.out.println("  5 + 10 == 15  → " + testOperation(5, 10, 15, "+"));
        System.out.println("  5 - 10 == -5  → " + testOperation(5, 10, -5, "-"));
        System.out.println("  5 * 10 == 50  → " + testOperation(5, 10, 50, "*"));
        System.out.println("  5 / 10 == 0   → " + testOperation(5, 10, 0, "/"));
    }

    /**
     * Returns true if a + b equals c, false otherwise.
     *
     * Encapsulating the test in a method gives it a clear name and makes the
     * program easier to read. The method is small enough that the JIT compiler
     * will inline it, so there is no performance penalty.
     *
     * @param a first addend
     * @param b second addend
     * @param c target value for the sum
     * @return true if a + b == c, false otherwise
     */
    private static boolean sumEqualsThird(int a, int b, int c) {
        return (a + b) == c;
    }

    /**
     * Generalized operation tester: returns true if (a OP b) == c, where OP is
     * one of "+", "-", "*", "/".
     *
     * This helper demonstrates how a single test can be adapted to multiple
     * arithmetic operators. In real code, an enum would be preferable; the
     * String form is used here for brevity.
     *
     * @param a first operand
     * @param b second operand
     * @param c target result
     * @param op one of "+", "-", "*", "/"
     * @return true if (a OP b) equals c
     */
    private static boolean testOperation(int a, int b, int c, String op) {
        int computed;
        switch (op) {
            case "+":
                computed = a + b;
                break;
            case "-":
                computed = a - b;
                break;
            case "*":
                computed = a * b;
                break;
            case "/":
                computed = a / b;
                break;
            default:
                throw new IllegalArgumentException(
                        "Unknown operation: " + op);
        }
        return computed == c;
    }
}
