package javamarathon.part1.fundamentals;

/**
 *
 * @author botho
 */
public class StringtoIntegerConversion {

    public static void main(String[] args) {

        // ------------------------------------------------------------
        // STEP 1: Declare the string to convert
        // ------------------------------------------------------------
        // For this exercise, the input is fixed to "25". In an
        // interactive program, we would read this from the user with
        // Scanner.nextLine().
        String stringNumber = "25";

        // ------------------------------------------------------------
        // STEP 2: Print the prompt line
        // ------------------------------------------------------------
        // The expected output begins with:
        //   "Input a number(string): 25"
        //
        // Since this exercise provides the input directly (rather
        // than reading it live), we print the prompt and the value
        // on the same line.
        System.out.println("Input a number(string): " + stringNumber);

        // ------------------------------------------------------------
        // STEP 3: Convert the string to an integer
        // ------------------------------------------------------------
        // Integer.parseInt(String) parses the string argument as a
        // signed decimal integer and returns an int.
        //
        // For "25":
        //   Integer.parseInt("25")  =  25  (an int)
        //
        // The result is a PRIMITIVE int, not an Integer object, which
        // is convenient for arithmetic and comparisons.
        int intValue = Integer.parseInt(stringNumber);

        // ------------------------------------------------------------
        // STEP 4: Print the converted integer
        // ------------------------------------------------------------
        // The required output is:
        //   "The integer value is: 25"
        //
        // Note that we now print the int, not the original string.
        // Even though they look identical in the output, they are
        // different types internally — the int can be used in
        // arithmetic, while the string cannot.
        System.out.println("The integer value is: " + intValue);

        // ------------------------------------------------------------
        // STEP 5: (Optional) Verify the conversion
        // ------------------------------------------------------------
        // Show that the int behaves like a number, not a string.
        // If we tried these operations with the original string,
        // we would get String concatenation instead of arithmetic.
        System.out.println();
        System.out.println("Proof that it's a real integer:");
        System.out.println("  " + intValue + " + 10   = " + (intValue + 10));
        System.out.println("  " + intValue + " × 2    = " + (intValue * 2));
        System.out.println("  " + intValue + " ÷ 5    = " + (intValue / 5));
        System.out.println("  " + intValue + " % 4    = " + (intValue % 4));
        System.out.println("  sqrt(" + intValue + ")  = " + Math.sqrt(intValue));

        // ------------------------------------------------------------
        // STEP 6: (Optional) Show the difference between string and int
        // ------------------------------------------------------------
        // This demonstrates WHY conversion matters: the '+' operator
        // behaves very differently for Strings and ints.
        System.out.println();
        System.out.println("String vs. int behavior with '+':");
        System.out.println("  String: \"25\" + 10  = \"" + (stringNumber + 10) + "\"");
        System.out.println("  int   :  25  + 10  =  " + (intValue + 10));

        // ============================================================
        // ALTERNATIVE — Using Integer.valueOf(String)
        // ============================================================
        // valueOf returns an Integer object (a wrapper around an int).
        // When assigned to an int variable, Java automatically
        // "unboxes" it — an operation called autoboxing.
        //
        // For most purposes, parseInt and valueOf are interchangeable.
        // The choice depends on whether you need a primitive int or
        // an Integer object:
        //     parseInt  →  int      (no object creation)
        //     valueOf   →  Integer  (may use cached objects)
        // ============================================================
        Integer integerObject = Integer.valueOf(stringNumber);
        int intFromObject = integerObject;   // auto-unboxing

        System.out.println();
        System.out.println("Via Integer.valueOf():");
        System.out.println("  Integer object  = " + integerObject);
        System.out.println("  Unboxed to int  = " + intFromObject);

        // ============================================================
        // ALTERNATIVE — Using Scanner
        // ============================================================
        // Wrapping a string in a Scanner and calling nextInt() parses
        // the first integer token from it. Useful when the string
        // contains multiple values separated by whitespace.
        // ============================================================
        java.util.Scanner stringScanner = new java.util.Scanner(stringNumber);
        int intFromScanner = stringScanner.nextInt();
        stringScanner.close();

        System.out.println();
        System.out.println("Via Scanner:");
        System.out.println("  Parsed value    = " + intFromScanner);

        // ============================================================
        // ALTERNATIVE — Robust conversion with exception handling
        // ============================================================
        // Real-world code should validate input and catch errors.
        // The try/catch block below shows how to handle invalid input
        // gracefully instead of crashing.
        // ============================================================
        System.out.println();
        System.out.println("Robust parsing demonstration:");

        String[] testInputs = {
            "25", // valid
            "-42", // valid (negative)
            "+100", // valid (explicit positive)
            "  7  ", // invalid (whitespace)
            "3.14", // invalid (decimal)
            "abc", // invalid (letters)
            "12x", // invalid (mixed)
            "", // invalid (empty)
            "999999999999" // invalid (out of int range)
        };

        for (String input : testInputs) {
            try {
                int parsed = Integer.parseInt(input);
                System.out.printf("  \"%s\"  →  %d%n", input, parsed);
            } catch (NumberFormatException e) {
                System.out.printf("  \"%s\"  →  ERROR: %s%n",
                        input, e.getMessage());
            }
        }

        // ============================================================
        // ALTERNATIVE — For larger values, use Long or BigInteger
        // ============================================================
        // If the string might exceed the range of int
        // (−2,147,483,648 to 2,147,483,647), use:
        //     Long.parseLong(String)         →  long
        //     new BigInteger(String)         →  arbitrary precision
        // ============================================================
        System.out.println();
        System.out.println("Parsing larger values:");
        try {
            long longValue = Long.parseLong("999999999999");
            System.out.println("  Long parseLong(\"999999999999\")  = " + longValue);

            java.math.BigInteger bigValue = new java.math.BigInteger(
                    "999999999999999999999999999999");
            System.out.println("  BigInteger value                = " + bigValue);
        } catch (NumberFormatException e) {
            System.out.println("  Parse error: " + e.getMessage());
        }

        // ============================================================
        // ALTERNATIVE — Parsing in a different radix
        // ============================================================
        // parseInt has an overload that accepts a radix:
        //     Integer.parseInt(String s, int radix)
        //
        // Useful for parsing binary, octal, or hexadecimal strings.
        // ============================================================
        System.out.println();
        System.out.println("Parsing in different radixes:");
        System.out.println("  parseInt(\"101\", 2)   = "
                + Integer.parseInt("101", 2));        // binary → 5
        System.out.println("  parseInt(\"17\", 8)    = "
                + Integer.parseInt("17", 8));         // octal  → 15
        System.out.println("  parseInt(\"FF\", 16)   = "
                + Integer.parseInt("FF", 16));        // hex    → 255
        System.out.println("  parseInt(\"25\", 10)   = "
                + Integer.parseInt("25", 10));        // decimal → 25
    }
}
