package javamarathon.part1.fundamentals;

/**
 *
 * @author botho
 */
public class DivisiblebyBoth {

    public static void main(String[] args) {

        // ============================================================
        // PART 1: Numbers between 1 and 100 divisible by 3
        // ============================================================
        // The range is 1 to 100 inclusive. We start at the first
        // multiple of 3 (which is 3) and step by 3 each iteration.
        // This directly generates: 3, 6, 9, 12, ..., 99.
        //
        // Stepping by 3 is more efficient than iterating 1–100 and
        // checking divisibility, but both approaches give the same
        // result. Using the check (i % 3 == 0) is more explicit and
        // easier to generalize, so we use it here for clarity.
        System.out.println("Divided by 3:");
        for (int i = 1; i <= 100; i++) {
            if (i % 3 == 0) {
                // Print the number followed by ", "
                System.out.print(i + ", ");
            }
        }
        // After the loop, print a newline to end the line.
        System.out.println();

        // ------------------------------------------------------------
        // Blank line for readability between sections.
        // ------------------------------------------------------------
        System.out.println();

        // ============================================================
        // PART 2: Numbers between 1 and 100 divisible by 5
        // ============================================================
        // Same pattern as Part 1, but with a different divisor.
        // The expected output for this section does NOT have a
        // trailing comma after 95 (unlike Part 1, which has one after
        // 99). We handle that by printing ", " before each number
        // except the first.
        System.out.println("Divided by 5:");

        // We track whether we've printed the first number yet,
        // so we know when to skip the leading separator.
        boolean first = true;
        for (int i = 1; i <= 100; i++) {
            if (i % 5 == 0) {
                if (!first) {
                    System.out.print(", ");
                }
                System.out.print(i);
                first = false;
            }
        }
        System.out.println();

        // ------------------------------------------------------------
        // Blank line for readability between sections.
        // ------------------------------------------------------------
        System.out.println();

        // ============================================================
        // PART 3: Numbers between 1 and 100 divisible by BOTH 3 and 5
        // ============================================================
        // A number is divisible by both 3 and 5 if and only if it is
        // divisible by 15 (since gcd(3, 5) = 1 and 3 × 5 = 15).
        //
        // We could check this in two equivalent ways:
        //     (a) i % 3 == 0 && i % 5 == 0
        //     (b) i % 15 == 0
        //
        // Option (b) is simpler and slightly more efficient. Both
        // give the same result. We use option (b) with a comment.
        //
        // The expected output again has a trailing comma:
        //     15, 30, 45, 60, 75, 90,
        System.out.println("Divided by 3 & 5:");
        for (int i = 1; i <= 100; i++) {
            if (i % 15 == 0) {
                // Print the number followed by ", " (matches the
                // expected trailing-comma style for this section).
                System.out.print(i + ", ");
            }
        }
        System.out.println();

        // ============================================================
        // STEP 4: (Optional) Summary with counts
        // ============================================================
        // A useful addition: count how many numbers fall into each
        // category. This confirms the arithmetic.
        int count3 = 0, count5 = 0, count15 = 0;
        for (int i = 1; i <= 100; i++) {
            if (i % 3 == 0) {
                count3++;
            }
            if (i % 5 == 0) {
                count5++;
            }
            if (i % 15 == 0) {
                count15++;
            }
        }

        System.out.println();
        System.out.println("Summary:");
        System.out.println("  Numbers divisible by 3    : " + count3);
        System.out.println("  Numbers divisible by 5    : " + count5);
        System.out.println("  Numbers divisible by 3 & 5: " + count15);

        // ------------------------------------------------------------
        // STEP 5: (Optional) Alternative output — one per line
        // ------------------------------------------------------------
        // Some exercises prefer one number per line. The same logic
        // applies, but with println() instead of print(", ").
        // ------------------------------------------------------------
        System.out.println();
        System.out.println("--- Alternative: one per line ---");
        System.out.println();
        System.out.println("Divided by 3:");
        for (int i = 3; i <= 100; i += 3) {
            System.out.println(i);
        }
        System.out.println();
        System.out.println("Divided by 5:");
        for (int i = 5; i <= 100; i += 5) {
            System.out.println(i);
        }
        System.out.println();
        System.out.println("Divided by 3 & 5:");
        for (int i = 15; i <= 100; i += 15) {
            System.out.println(i);
        }

        // ============================================================
        // ALTERNATIVE — Using the "step by divisor" approach
        // ============================================================
        // Instead of checking every number, start at the divisor and
        // step by it. This visits only the numbers we want, skipping
        // the check entirely.
        //
        // For 3:   start at 3,  step 3   → 3, 6, 9, ...
        // For 5:   start at 5,  step 5   → 5, 10, 15, ...
        // For 15:  start at 15, step 15  → 15, 30, 45, ...
        //
        // This is twice as fast as the check-each-number approach for
        // finding multiples in a range. The downside is that it
        // doesn't generalize as easily to more complex conditions
        // (e.g., "divisible by 3 OR 5").
        // ============================================================
        // ============================================================
        // ALTERNATIVE — Using Java streams (Java 8+)
        // ============================================================
        // A functional-style approach using IntStream:
        //
        //   IntStream.rangeClosed(1, 100)
        //            .filter(n -> n % 3 == 0)
        //            .forEach(n -> System.out.print(n + ", "));
        //
        // Concise, but the imperative loop above is clearer for
        // beginners and easier to debug.
        // ============================================================
        // ============================================================
        // ALTERNATIVE — Divisible by 3 OR 5
        // ============================================================
        // A closely related exercise asks for numbers divisible by
        // 3 OR 5 (i.e., divisible by at least one). The condition
        // uses || instead of &&:
        //
        //     if (i % 3 == 0 || i % 5 == 0) { ... }
        //
        // For 1–100, this would print 3, 5, 6, 9, 10, 12, 15, ...
        // — a total of 33 + 20 − 6 = 47 numbers (using inclusion–
        // exclusion: |A ∪ B| = |A| + |B| − |A ∩ B|).
        // ============================================================
        System.out.println();
        System.out.println("--- Bonus: divisible by 3 OR 5 ---");
        System.out.print("Divided by 3 or 5: ");
        for (int i = 1; i <= 100; i++) {
            if (i % 3 == 0 || i % 5 == 0) {
                System.out.print(i + ", ");
            }
        }
        System.out.println();
    }
}
