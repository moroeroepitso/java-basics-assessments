package javamarathon.part1.fundamentals;

/**
 *
 * @author botho
 */
public class ListAvailableCharserts {

    public static void main(String[] args) {

        // ------------------------------------------------------------
        // STEP 1: Print a header line
        // ------------------------------------------------------------
        // The expected output begins with:
        //   "List of available character sets:"
        System.out.println("List of available character sets:");

        // ------------------------------------------------------------
        // STEP 2: Fetch all available charsets
        // ------------------------------------------------------------
        // Charset.availableCharsets() returns a SortedMap where:
        //   - The key is the canonical charset name (e.g., "UTF-8").
        //   - The value is the Charset object itself.
        //
        // The map is already sorted alphabetically by the JDK, so we
        // don't need to sort it ourselves.
        java.util.SortedMap<String, java.nio.charset.Charset> charsets
                = java.nio.charset.Charset.availableCharsets();

        // ------------------------------------------------------------
        // STEP 3: Iterate over the charset names and print each one
        // ------------------------------------------------------------
        // We iterate over the KEYS of the map (the canonical names) and
        // print each one on its own line.
        //
        // The iteration is guaranteed to be in ascending alphabetical
        // order because availableCharsets() returns a SortedMap with
        // natural string ordering (case-insensitive in practice, since
        // the JDK uses a case-insensitive comparator for charset names).
        for (String charsetName : charsets.keySet()) {
            System.out.println(charsetName);
        }

        // ------------------------------------------------------------
        // STEP 4: (Optional) Print a summary line with the total count
        // ------------------------------------------------------------
        // This is not part of the required output, but it's helpful to
        // know how many charsets are available. The count varies by
        // JDK version — typically 170–180.
        System.out.println();
        System.out.println("Total available charsets: " + charsets.size());

        // ------------------------------------------------------------
        // STEP 5: (Optional) Show the JVM's default charset
        // ------------------------------------------------------------
        // Charset.defaultCharset() returns the platform's default
        // charset, which is used when you call new String(bytes) or
        // getBytes() without specifying a charset. On modern JVMs
        // (JDK 18+), this is UTF-8 by default; on older JVMs, it
        // depends on the operating system locale.
        System.out.println();
        System.out.println("Default charset: " + java.nio.charset.Charset.defaultCharset());

        // ------------------------------------------------------------
        // STEP 6: (Optional) Show common charsets with their aliases
        // ------------------------------------------------------------
        // Charset objects expose their canonical name and the list of
        // aliases (alternate names recognized by forName).
        //
        // For example, "UTF-8" has aliases including "UTF8" and
        // "unicode-1-1-utf-8". The alias list is empty for many
        // charsets but populated for the widely used ones.
        System.out.println();
        System.out.println("--- Aliases of common charsets ---");
        String[] common = {"UTF-8", "UTF-16", "US-ASCII", "ISO-8859-1"};
        for (String name : common) {
            try {
                java.nio.charset.Charset cs = java.nio.charset.Charset.forName(name);
                System.out.println(cs.name() + "  aliases: " + cs.aliases());
            } catch (java.nio.charset.UnsupportedCharsetException e) {
                System.out.println(name + "  (not available on this JVM)");
            }
        }

        // ------------------------------------------------------------
        // STEP 7: (Optional) Group charsets by family
        // ------------------------------------------------------------
        // Charsets often come in families (UTF-*, ISO-8859-*, windows-*).
        // Grouping by prefix makes the list easier to navigate.
        System.out.println();
        System.out.println("--- Charsets grouped by family ---");
        java.util.Map<String, Integer> familyCounts = new java.util.TreeMap<>();
        for (String name : charsets.keySet()) {
            // Extract the family prefix: everything before the first
            // digit, dash, or dot. E.g., "UTF-8" → "UTF", "windows-1252"
            // → "windows", "ISO-8859-1" → "ISO".
            String family = name.split("[-\\d.]")[0];
            familyCounts.merge(family, 1, Integer::sum);
        }
        for (java.util.Map.Entry<String, Integer> entry : familyCounts.entrySet()) {
            System.out.printf("  %-15s : %d charsets%n",
                    entry.getKey(), entry.getValue());
        }
    }
}
