package javamarathon.part1.fundamentals;

/**
 *
 * @author botho
 */
public class CountDivisiblesinRange {

    public static void main(String[] args) {

        // ------------------------------------------------------------
        // STEP 1: Declare the range and the divisor
        // ------------------------------------------------------------
        // 'low' and 'high' define the inclusive range to search.
        // 'divisor' is the number we test divisibility against.
        int low = 1;
        int high = 20;
        int divisor = 4;

        // ============================================================
        // METHOD 1 — Iterate and test each number (RECOMMENDED)
        // ============================================================
        // This approach walks through every integer from 'low' to
        // 'high' and checks if it's divisible by 'divisor'.
        //
        // Divisibility test:  n % divisor == 0
        //
        // For range 1–20 and divisor 4:
        //     1 % 4 = 1  → no
        //     2 % 4 = 2  → no
        //     3 % 4 = 3  → no
        //     4 % 4 = 0  → YES (count 1)
        //     5 % 4 = 1  → no
        //     ...
        //     8 % 4 = 0  → YES (count 2)
        //     ...
        //     20 % 4 = 0 → YES (count 5)
        //
        // This is the clearest approach: it directly mirrors the
        // problem statement "count values in a range divisible by d".
        int count = 0;
        for (int i = low; i <= high; i++) {
            if (i % divisor == 0) {
                count++;
            }
        }

        // ------------------------------------------------------------
        // STEP 2: Print the result
        // ------------------------------------------------------------
        // The expected output is just the number:
        //   "5"
        System.out.println(count);

        // ------------------------------------------------------------
        // STEP 3: (Optional) Show which numbers were counted
        // ------------------------------------------------------------
        // Listing the actual multiples makes the count verifiable.
        System.out.println();
        System.out.println("Multiples of " + divisor + " in range [" + low + ", " + high + "]:");
        StringBuilder multiplesList = new StringBuilder();
        int listCount = 0;
        for (int i = low; i <= high; i++) {
            if (i % divisor == 0) {
                if (listCount > 0) {
                    multiplesList.append(", ");
                }
                multiplesList.append(i);
                listCount++;
            }
        }
        System.out.println("  " + multiplesList);
        System.out.println("  Count = " + listCount);

        // ============================================================
        // METHOD 2 — Direct formula (mathematical shortcut)
        // ============================================================
        // For a range [low, high] and divisor d, the number of
        // multiples of d in the range is:
        //
        //     count = floor(high / d) − floor((low − 1) / d)
        //
        // For [1, 20] with d = 4:
        //     floor(20 / 4)     = 5
        //     floor(0 / 4)      = 0
        //     count = 5 − 0 = 5
        //
        // This is O(1) — no loop needed. For very large ranges (e.g.,
        // up to a billion), this approach is dramatically faster.
        //
        // Note: In Java, integer division '/' already performs floor
        // division for positive numbers, so no Math.floor is needed.
        int formulaCount = (high / divisor) - ((low - 1) / divisor);

        System.out.println();
        System.out.println("Via formula:");
        System.out.println("  floor(" + high + " / " + divisor + ") - floor(("
                + low + " - 1) / " + divisor + ")");
        System.out.println("  = " + (high / divisor) + " - " + ((low - 1) / divisor));
        System.out.println("  = " + formulaCount);
        System.out.println("  Matches loop count? " + (formulaCount == count));

        // ============================================================
        // METHOD 3 — Step by the divisor
        // ============================================================
        // Instead of testing every number, we jump directly to each
        // multiple. The first multiple at or above 'low' is:
        //
        //     first = ceil(low / d) * d
        //
        // We can compute it as:
        //     first = ((low + d − 1) / d) * d
        //
        // Then we step by 'd' until we exceed 'high'.
        //
        // For [1, 20] with d = 4:
        //     first = ((1 + 3) / 4) * 4 = (4 / 4) * 4 = 1 * 4 = 4
        //     steps: 4, 8, 12, 16, 20 → 5 iterations
        int firstMultiple = ((low + divisor - 1) / divisor) * divisor;
        int stepCount = 0;
        for (int i = firstMultiple; i <= high; i += divisor) {
            stepCount++;
        }

        System.out.println();
        System.out.println("Via stepping by divisor:");
        System.out.println("  First multiple = " + firstMultiple);
        System.out.println("  Steps taken    = " + stepCount);
        System.out.println("  Matches loop count? " + (stepCount == count));

        // ============================================================
        // STEP 4: (Optional) Print a summary table
        // ============================================================
        System.out.println();
        System.out.println("Summary:");
        System.out.println("  Range         : [" + low + ", " + high + "]");
        System.out.println("  Divisor       : " + divisor);
        System.out.println("  Count (loop)  : " + count);
        System.out.println("  Count (formula): " + formulaCount);
        System.out.println("  Count (step)  : " + stepCount);
        System.out.println("  All agree?    : "
                + (count == formulaCount && formulaCount == stepCount));

        // ============================================================
        // ALTERNATIVE — Using a helper method
        // ============================================================
        // Encapsulating the counting in a method makes it reusable
        // and gives the logic a descriptive name.
        // ============================================================
        System.out.println();
        System.out.println("Via helper method:");
        System.out.println("  countDivisibles(1, 20, 4)     = " + countDivisibles(1, 20, 4));
        System.out.println("  countDivisibles(1, 100, 3)    = " + countDivisibles(1, 100, 3));
        System.out.println("  countDivisibles(1, 100, 5)    = " + countDivisibles(1, 100, 5));
        System.out.println("  countDivisibles(1, 100, 15)   = " + countDivisibles(1, 100, 15));
        System.out.println("  countDivisibles(10, 30, 7)    = " + countDivisibles(10, 30, 7));
        System.out.println("  countDivisibles(0, 100, 10)   = " + countDivisibles(0, 100, 10));

        // ============================================================
        // ALTERNATIVE — Using Java streams (Java 8+)
        // ============================================================
        // A functional one-liner alternative:
        //
        //     long count = IntStream.rangeClosed(low, high)
        //                           .filter(i -> i % divisor == 0)
        //                           .count();
        //
        // Concise, but performs the same O(n) work as Method 1.
        // ============================================================
        // ============================================================
        // ALTERNATIVE — Edge cases to consider
        // ============================================================
        // A few boundary conditions to think about:
        //   - divisor == 0: illegal (division by zero)
        //   - low > high: empty range, count is 0
        //   - low or high negative: formula still works if we
        //     replace '/ d' with floor division
        //   - divisor == 1: every number matches
        //   - divisor > (high − low + 1): only matches if range
        //     includes a multiple of divisor
        System.out.println();
        System.out.println("Edge cases:");
        System.out.println("  countDivisibles(1, 20, 1)     = " + countDivisibles(1, 20, 1)
                + "  (all 20 match)");
        System.out.println("  countDivisibles(5, 5, 5)      = " + countDivisibles(5, 5, 5)
                + "  (single number)");
        System.out.println("  countDivisibles(6, 7, 4)      = " + countDivisibles(6, 7, 4)
                + "  (no multiples)");
        System.out.println("  countDivisibles(20, 1, 4)     = " + countDivisibles(20, 1, 4)
                + "  (empty range)");
        System.out.println("  countDivisibles(1, 20, 25)    = " + countDivisibles(1, 20, 25)
                + "  (divisor > range)");
    }

    /**
     * Counts how many integers in the inclusive range [low, high] are divisible
     * by 'divisor'.
     *
     * Uses the loop-based counting method — easy to understand and works for
     * any range.
     *
     * Edge cases handled: - low > high → returns 0 (empty range) - divisor == 0
     * → throws IllegalArgumentException
     *
     * @param low the low end of the range (inclusive)
     * @param high the high end of the range (inclusive)
     * @param divisor the number to test divisibility against
     * @return the count of multiples of divisor in [low, high]
     * @throws IllegalArgumentException if divisor is 0
     */
    private static int countDivisibles(int low, int high, int divisor) {
        if (divisor == 0) {
            throw new IllegalArgumentException("Divisor cannot be zero.");
        }
        if (low > high) {
            return 0;
        }

        int count = 0;
        for (int i = low; i <= high; i++) {
            if (i % divisor == 0) {
                count++;
            }
        }
        return count;
    }
}
