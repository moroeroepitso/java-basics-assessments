package javamarathon.part1.fundamentals;


 //2128087 PITSO MOROEROE
public class JavaPattern {

    public static void main(String[] args) {

        // ------------------------------------------------------------
        // STEP 1: Define the row slices for each letter
        // ------------------------------------------------------------
        // Each string below represents ONE ROW of ONE LETTER.
        // All slices are padded to 5 characters wide so columns align.
        //
        // We use an array for each letter so we can loop through the
        // 4 rows uniformly instead of writing 16 separate print calls.

        // ---- Letter 'J' : 4 rows, 5 columns each ----
        // Row 0: "    J"  -> J appears on the right
        // Row 1: "    J"  -> J stays on the right
        // Row 2: "J   J"  -> J appears on the left AND right (the hook)
        // Row 3: " J J "  -> the bottom curve of the J
        String[] letterJ = {
            "    J",
            "    J",
            "J   J",
            " J J "
        };

        // ---- Letter 'a' : 4 rows, 5 columns each ----
        // Row 0: "  a  "  -> the top of the 'a' (single peak)
        // Row 1: " a a "  -> the sides spreading out
        // Row 2: "aaaaa"  -> the middle crossbar
        // Row 3: "a   a"  -> the two legs at the bottom
        String[] letterA1 = {
            "  a  ",
            " a a ",
            "aaaaa",
            "a   a"
        };

        // ---- Letter 'v' : 4 rows, 5 columns each ----
        // Row 0: "v   v"  -> two arms far apart (top of the V)
        // Row 1: " v v "  -> arms moving closer
        // Row 2: "  V  "  -> the point of the V (using capital V for weight)
        // Row 3: "  V  "  -> a short stem so the V is 4 rows tall
        String[] letterV = {
            "v   v",
            " v v ",
            "  V  ",
            "  V  "
        };

        // ---- Letter 'a' (second one) : reuse the same pattern ----
        // Since "JAVA" ends with 'a', we can simply reuse letterA1.
        String[] letterA2 = letterA1;

        // ------------------------------------------------------------
        // STEP 2: Print the four rows of the combined word
        // ------------------------------------------------------------
        // We loop once per row (0 to 3) and, inside each iteration,
        // concatenate the row-slice from each letter and print it.
        //
        // A space is inserted between letters for visual separation.
        for (int row = 0; row < 4; row++) {

            // Build the current line by joining the row-slice of each letter
            String line = letterJ[row] + "  "
                        + letterA1[row] + "  "
                        + letterV[row] + "  "
                        + letterA2[row];

            // Print the fully assembled line for this row
            System.out.println(line);
        }

        // ------------------------------------------------------------
        // ALTERNATIVE (hard-coded) version — uncomment to use:
        // This produces the exact same output without arrays or loops.
        // Helpful for understanding what each row looks like.
        // ------------------------------------------------------------
        // System.out.println("    J     a    v     v     a");
        // System.out.println("    J    a a    v   v     a a");
        // System.out.println("J   J   aaaaa    V V     aaaaa");
        // System.out.println(" J J   a     a    V     a     a");
    }
}
