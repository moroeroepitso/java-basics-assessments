package javamarathon.part1.fundamentals;

/**
 *
 * @author botho
 */
public class FileSizeFinder {

    public static void main(String[] args) {

        // ------------------------------------------------------------
        // STEP 1: Declare the list of file paths to inspect
        // ------------------------------------------------------------
        // These are the paths from the problem statement. In a real
        // application, this list would typically come from command-line
        // arguments or a directory scan.
        String[] filePaths = {
            "/home/students/abc.txt",
            "/home/students/test.txt"
        };

        // ------------------------------------------------------------
        // STEP 2: Loop through each path and print its size
        // ------------------------------------------------------------
        // We create a File object for each path and call length() to
        // obtain the size in bytes.
        //
        // The output format matches the expected output exactly:
        //   <path>  : <size> bytes
        //
        // Alignment note: the expected output uses different spacing
        // before the ':' for each line, so that the colons align. This
        // is achieved by padding the path to a fixed width. The width
        // chosen here matches the first (longer) path, so the second
        // (shorter) path gets extra spaces.
        //
        // In the expected output:
        //   "/home/students/abc.txt  : 0 bytes"   ← 2 spaces before ":"
        //   "/home/students/test.txt : 0 bytes"   ← 1 space before  ":"
        //
        // To reproduce this exactly, we pad each path to the maximum
        // path length in the array (24 characters) and add one more
        // space before the colon.
        int maxPathLength = 0;
        for (String path : filePaths) {
            if (path.length() > maxPathLength) {
                maxPathLength = path.length();
            }
        }

        for (String path : filePaths) {

            // Create a File object wrapping the given path.
            java.io.File file = new java.io.File(path);

            // Obtain the file size in bytes.
            // length() returns 0L for missing files, empty files, and
            // directories — see the class-level comment for details.
            long sizeInBytes = file.length();

            // Pad the path to the max width, then add one space and the
            // colon, so all colons line up vertically.
            String paddedPath = padRight(path, maxPathLength);

            // Print in the required format.
            System.out.println(paddedPath + " : " + sizeInBytes + " bytes");
        }

        // ------------------------------------------------------------
        // STEP 3: (Optional) More detailed diagnostics
        // ------------------------------------------------------------
        // For real-world use, it's helpful to distinguish between
        // "file exists and is empty" and "file does not exist". The
        // block below shows this in a second pass.
        System.out.println();
        System.out.println("Detailed diagnostics:");
        for (String path : filePaths) {
            java.io.File file = new java.io.File(path);

            String status;
            long size;

            if (file.exists() && file.isFile()) {
                size = file.length();
                status = size + " bytes";
            } else if (file.exists() && file.isDirectory()) {
                size = file.length();
                status = "directory (size varies by OS)";
            } else {
                size = 0;
                status = "FILE NOT FOUND";
            }

            System.out.printf("  %-30s → %s%n", path, status);
        }

        // ------------------------------------------------------------
        // STEP 4: (Optional) Show additional file attributes
        // ------------------------------------------------------------
        // The File class exposes many useful metadata fields beyond
        // size: readability, writability, last-modified time, etc.
        // These are often useful when inspecting files programmatically.
        System.out.println();
        System.out.println("File attributes:");
        for (String path : filePaths) {
            java.io.File file = new java.io.File(path);

            System.out.println("  Path        : " + path);
            System.out.println("    exists    : " + file.exists());
            System.out.println("    isFile    : " + file.isFile());
            System.out.println("    isDir     : " + file.isDirectory());
            System.out.println("    readable  : " + file.canRead());
            System.out.println("    writable  : " + file.canWrite());
            System.out.println("    executable: " + file.canExecute());
            System.out.println("    size      : " + file.length() + " bytes");

            // Last modified time, if the file exists.
            if (file.exists()) {
                long lastModified = file.lastModified();
                java.time.LocalDateTime ldt = java.time.LocalDateTime.ofInstant(
                        java.time.Instant.ofEpochMilli(lastModified),
                        java.time.ZoneId.systemDefault());
                System.out.println("    modified  : " + ldt);
            }
            System.out.println();
        }

        // ============================================================
        // ALTERNATIVE APPROACH 1 — Using java.nio.file.Files
        // ============================================================
        // The modern NIO.2 API provides Files.size(Path) which THROWS
        // an IOException if the file does not exist — this is safer
        // because it prevents silently treating "missing" as "empty".
        //
        // Use this in modern code; the older File.length() is still
        // fine but has the ambiguity described above.
        // ============================================================
        // java.nio.file.Path nioPath = java.nio.file.Paths.get(path);
        // try {
        //     long size = java.nio.file.Files.size(nioPath);
        //     System.out.println(path + " : " + size + " bytes");
        // } catch (java.io.IOException e) {
        //     System.out.println(path + " : ERROR — " + e.getMessage());
        // }
        // ============================================================
        // ALTERNATIVE APPROACH 2 — Human-readable size formatting
        // ============================================================
        // For large files, showing raw byte counts is unhelpful. The
        // helper method below converts a byte count into a friendly
        // string like "1.5 MB" or "342 KB".
        // ============================================================
        System.out.println("Human-readable sizes (for reference):");
        for (String path : filePaths) {
            java.io.File file = new java.io.File(path);
            System.out.printf("  %-30s → %s%n",
                    path, humanReadableSize(file.length()));
        }
    }

    /**
     * Pads a string on the right with spaces until it reaches the specified
     * total width. If the string is already at least that wide, it is returned
     * unchanged.
     *
     * This is a small helper so we can align the ':' characters in the output —
     * Java's standard String class does not include a built-in padRight method
     * (though String.format and printf do offer '%-Ns' formatting, which we
     * could also use).
     *
     * @param s the string to pad
     * @param width the minimum total width
     * @return the padded string
     */
    private static String padRight(String s, int width) {
        if (s.length() >= width) {
            return s;
        }
        StringBuilder sb = new StringBuilder(s);
        while (sb.length() < width) {
            sb.append(' ');
        }
        return sb.toString();
    }

    /**
     * Converts a byte count into a human-readable string using the appropriate
     * unit (B, KB, MB, GB, TB).
     *
     * Uses 1024 as the divisor (binary units, i.e., KiB/MiB/GiB in strict
     * terminology, but commonly labeled KB/MB/GB in casual usage). To use
     * decimal SI units (1000-based), change the divisor below to 1000.0.
     *
     * @param bytes the size in bytes
     * @return a formatted string such as "1.5 MB"
     */
    private static String humanReadableSize(long bytes) {
        if (bytes < 1024) {
            return bytes + " B";
        }
        double kb = bytes / 1024.0;
        if (kb < 1024) {
            return String.format("%.2f KB", kb);
        }
        double mb = kb / 1024.0;
        if (mb < 1024) {
            return String.format("%.2f MB", mb);
        }
        double gb = mb / 1024.0;
        if (gb < 1024) {
            return String.format("%.2f GB", gb);
        }
        double tb = gb / 1024.0;
        return String.format("%.2f TB", tb);
    }
}
