package javamarathon.part1.fundamentals;

/**
 *
 * 2128087 pitso moroeroe
 */
public class FormulaComputation {
 

    public static void main(String[] args) {

        // ------------------------------------------------------------
        // STEP 1: Declare and initialize the three input variables
        // ------------------------------------------------------------
        // All three are stored as 'double' so that decimal values
        // (like the rate 7.5) and fractional results are handled
        // correctly throughout the calculation.

        // P = Principal: the initial amount of money invested or borrowed.
        double principal = 5000;

        // R = Rate: the annual interest rate expressed as a percentage.
        //      7.5 means 7.5% per year. Stored as double because of the ".5".
        double rate = 7.5;

        // T = Time: the duration in years for which the money is invested.
        double time = 3;

        // ------------------------------------------------------------
        // STEP 2: Apply the Simple Interest formula
        // ------------------------------------------------------------
        // Formula:  SI = (P * R * T) / 100
        //
        // The division by 100 converts the percentage rate into a
        // decimal fraction. For example, 7.5% becomes 0.075.
        //
        // Step-by-step trace with the given values:
        //   P * R      = 5000 * 7.5      = 37500.0
        //   * T        = 37500.0 * 3     = 112500.0
        //   / 100      = 112500.0 / 100  = 1125.0
        //
        // The parentheses around (P * R * T) make the order of
        // operations explicit: multiply first, then divide.
        double simpleInterest = (principal * rate * time) / 100;

        // ------------------------------------------------------------
        // STEP 3: Print the result
        // ------------------------------------------------------------
        System.out.println("Simple Interest Calculation");
        System.out.println("---------------------------");
        System.out.println("Principal (P) = " + principal);
        System.out.println("Rate      (R) = " + rate + "%");
        System.out.println("Time      (T) = " + time + " years");
        System.out.println("---------------------------");
        System.out.println("Simple Interest = " + simpleInterest);

        // ------------------------------------------------------------
        // STEP 4: (Optional) Compute and display the total amount
        // ------------------------------------------------------------
        // Total Amount = Principal + Simple Interest
        // This is often useful in real-world finance contexts and
        // shows a natural extension of the same computation.
        double totalAmount = principal + simpleInterest;
        System.out.println("Total Amount (P + SI) = " + totalAmount);

        // ------------------------------------------------------------
        // Alternative output using printf() for cleaner formatting
        // (uncomment to use) — %.2f prints two decimal places, which
        // is the conventional format for currency values.
        // ------------------------------------------------------------
        // System.out.printf("Simple Interest = %.2f%n", simpleInterest);
        // System.out.printf("Total Amount   = %.2f%n", totalAmount);
    }
}

