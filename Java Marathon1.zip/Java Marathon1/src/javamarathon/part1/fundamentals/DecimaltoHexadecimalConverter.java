package javamarathon.part1.fundamentals;

/**
 *
 * @author botho
 */
public class DecimaltoHexadecimalConverter {

   
        public static void main(String[] args) {

            // ------------------------------------------------------------
            // STEP 1: Declare the decimal number
            // ------------------------------------------------------------
            // The number is stored as an 'int' since the input is a whole
            // decimal number with no fractional part.
            int number = 15;

            // ------------------------------------------------------------
            // STEP 2: Convert to hexadecimal using the built-in method
            // ------------------------------------------------------------
            // Integer.toHexString(int) returns the hexadecimal representation
            // of the given integer as a String, without leading zeros and
            // using LOWERCASE letters for A–F.
            //
            //   Integer.toHexString(15)  =  "f"
            //
            // We then call .toUpperCase() to get "F", matching the expected
            // output. If we wanted lowercase, we would simply omit this call.
            String hexString = Integer.toHexString(number).toUpperCase();

            // ------------------------------------------------------------
            // STEP 3: Print the result
            // ------------------------------------------------------------
            // The required output format is:
            //   "Hexadecimal number is : F"
            // Note the space before the colon, matching the expected output.
            System.out.println("Hexadecimal number is : " + hexString);

            // ------------------------------------------------------------
            // STEP 4: (Optional) Print a verification trace
            // ------------------------------------------------------------
            // Showing the intermediate steps helps confirm the conversion
            // was done correctly and provides a useful learning reference.
            System.out.println();
            System.out.println("Verification trace:");
            System.out.println("  Decimal number     = " + number);
            System.out.println("  Hexadecimal string = " + hexString);
            System.out.println("  Decimal check      = " + Integer.parseInt(hexString, 16));

            // ============================================================
            // ALTERNATIVE APPROACH — Manual decimal-to-hexadecimal conversion
            // ============================================================
            // This method shows the underlying algorithm: repeatedly divide
            // the decimal number by 16, and record each remainder. Each
            // remainder (0–15) is mapped to its hex symbol. The symbols,
            // read from bottom to top, form the hexadecimal digits.
            //
            // WORKING TRACE with number = 15:
            //
            //   Step 1:  15 ÷ 16 = 0 remainder 15  →  symbol 'F'
            //   Stop when the quotient reaches 0.
            //
            //   Symbols in order recorded:  F
            //   Reversed (read bottom-to-top): F  →  "F"
            //
            // WORKING TRACE with a bigger example, number = 255:
            //
            //   Step 1:  255 ÷ 16 = 15 remainder 15  →  symbol 'F'  (LSB)
            //   Step 2:   15 ÷ 16 =  0 remainder 15  →  symbol 'F'  (MSB)
            //   Stop.
            //
            //   Reversed: "F" + "F"  →  "FF"   ✓  (255 = 0xFF)
            // ============================================================
            String manualHex = decimalToHexManual(number);
            System.out.println();
            System.out.println("Manual conversion result: " + manualHex);

            // ------------------------------------------------------------
            // BONUS: Try more examples to confirm the logic
            // ------------------------------------------------------------
            // Uncomment the lines below to test other decimal values.
            // ------------------------------------------------------------
            // System.out.println("\nMore examples:");
            // System.out.println("  0   → " + decimalToHexManual(0));        // 0
            // System.out.println("  10  → " + decimalToHexManual(10));       // A
            // System.out.println("  15  → " + decimalToHexManual(15));       // F
            // System.out.println("  16  → " + decimalToHexManual(16));       // 10
            // System.out.println("  255 → " + decimalToHexManual(255));      // FF
            // System.out.println("  4096→ " + decimalToHexManual(4096));     // 1000
        }

        /**
         * Converts a non-negative decimal integer to its hexadecimal string
         * representation using repeated division by 16.
         *
         * Algorithm: 1. If the number is 0, return "0" immediately. 2. While
         * the number is greater than 0: - Compute the remainder of number / 16.
         * - Map the remainder (0–15) to a hex symbol (0–9, A–F). - Divide the
         * number by 16 (integer division). 3. The symbols are collected from
         * least significant digit to most significant digit, so reverse them at
         * the end.
         *
         * @param n the decimal number to convert (must be >= 0)
         * @return the uppercase hexadecimal representation of n
         */
        private static String decimalToHexManual(int n) {

            // Special case: 0 in decimal is "0" in hexadecimal.
            // Without this check, the loop below would not execute at all
            // (since n is not > 0), and we would return an empty string.
            if (n == 0) {
                return "0";
            }

            // The 16 symbols used in hexadecimal, indexed 0..15.
            // Index 10 = 'A', 11 = 'B', ..., 15 = 'F'.
            // Keeping this array separate makes the mapping explicit and
            // easy to read or modify.
            char[] hexSymbols = {
                '0', '1', '2', '3', '4', '5', '6', '7',
                '8', '9', 'A', 'B', 'C', 'D', 'E', 'F'
            };

            // StringBuilder accumulates the hex symbols in the order they
            // are produced — from least significant to most significant.
            // We will reverse this at the end.
            StringBuilder hex = new StringBuilder();

            // Work on a copy of the input so the original is not modified.
            int quotient = n;

            // Repeatedly divide by 16, recording each remainder's symbol.
            while (quotient > 0) {
                // '%' returns the remainder of division by 16, in the
                // range 0..15.
                int remainder = quotient % 16;

                // Map the remainder to its hex symbol and append it.
                hex.append(hexSymbols[remainder]);

                // Integer division by 16 moves us to the next hex digit.
                // E.g., 255 / 16 = 15, then 15 / 16 = 0.
                quotient = quotient / 16;
            }

            // The symbols were collected LSB-first, so reverse them to get
            // the standard MSB-first hexadecimal representation.
            return hex.reverse().toString();
        }
    }

