package javamarathon.part1.fundamentals;

/**
 *
 * @author botho
 */
public class BinarytoDecimalConverter {

    public static void main(String[] args) {

        // ------------------------------------------------------------
        // STEP 1: Declare the binary number as a String
        // ------------------------------------------------------------
        // Storing the binary value as a String preserves its binary
        // meaning and allows leading zeros (e.g., "00100") if needed.
        //
        // IMPORTANT: If we wrote 'int binary = 100;', Java would store
        // the DECIMAL number one hundred (100₁₀), not binary "100"
        // (which is 4₁₀). The String representation avoids this
        // ambiguity entirely.
        String binary = "100";

        // ------------------------------------------------------------
        // STEP 2: Convert to decimal using the built-in method
        // ------------------------------------------------------------
        // Integer.parseInt(String, radix) interprets the string as a
        // number in the given base. Passing radix = 2 tells Java to
        // treat the string as binary.
        //
        //   Integer.parseInt("100", 2)  =  4
        //
        // This is the recommended approach for real-world code: concise,
        // correct, and handles all edge cases (including long binary
        // strings that exceed int range — though such inputs would throw
        // a NumberFormatException).
        int decimalNumber = Integer.parseInt(binary, 2);

        // ------------------------------------------------------------
        // STEP 3: Print the result
        // ------------------------------------------------------------
        // The required output format is:
        //   "Decimal Number: 4"
        System.out.println("Decimal Number: " + decimalNumber);

        // ------------------------------------------------------------
        // STEP 4: (Optional) Print a verification trace
        // ------------------------------------------------------------
        // Showing the intermediate steps helps confirm the conversion
        // was done correctly and provides a useful learning reference.
        System.out.println();
        System.out.println("Verification trace:");
        System.out.println("  Binary string   = " + binary);
        System.out.println("  Decimal number  = " + decimalNumber);
        System.out.println("  Binary check    = " + Integer.toBinaryString(decimalNumber));

        // ============================================================
        // ALTERNATIVE APPROACH — Manual binary-to-decimal conversion
        // ============================================================
        // This method shows the underlying algorithm: walk through the
        // binary string from LEFT to RIGHT, doubling the running total
        // at each step and adding the current bit. This is a form of
        // Horner's method and avoids computing powers of 2 separately.
        //
        // WORKING TRACE with binary = "100":
        //
        //   Start:  decimal = 0
        //   Bit '1':  decimal = 0 × 2 + 1  =  1
        //   Bit '0':  decimal = 1 × 2 + 0  =  2
        //   Bit '0':  decimal = 2 × 2 + 0  =  4   ✓
        //
        // WORKING TRACE with binary = "1011" (11 in decimal):
        //
        //   Start:  decimal = 0
        //   Bit '1':  decimal = 0  × 2 + 1  =  1
        //   Bit '0':  decimal = 1  × 2 + 0  =  2
        //   Bit '1':  decimal = 2  × 2 + 1  =  5
        //   Bit '1':  decimal = 5  × 2 + 1  =  11  ✓
        // ============================================================
        int manualDecimal = binaryToDecimalManual(binary);
        System.out.println();
        System.out.println("Manual conversion result: " + manualDecimal);

        // ------------------------------------------------------------
        // BONUS: Try more examples to confirm the logic
        // ------------------------------------------------------------
        // Uncomment the lines below to test other binary values.
        // ------------------------------------------------------------
        // System.out.println("\nMore examples:");
        // System.out.println("  0      → " + binaryToDecimalManual("0"));       // 0
        // System.out.println("  1      → " + binaryToDecimalManual("1"));       // 1
        // System.out.println("  10     → " + binaryToDecimalManual("10"));      // 2
        // System.out.println("  100    → " + binaryToDecimalManual("100"));     // 4
        // System.out.println("  1011   → " + binaryToDecimalManual("1011"));    // 11
        // System.out.println("  11111  → " + binaryToDecimalManual("11111"));   // 31
        // System.out.println("  10000000 → " + binaryToDecimalManual("10000000")); // 128
    }

    /**
     * Converts a binary string to its decimal integer representation.
     *
     * Algorithm (Horner's method): Walk through the binary string from left to
     * right, maintaining a running decimal value. At each step: decimal =
     * decimal * 2 + currentBit This is equivalent to multiplying the running
     * total by 2 (to shift it one position left) and adding the new bit.
     *
     * This approach avoids computing powers of 2 explicitly, which makes it
     * both faster and easier to read.
     *
     * @param binary the binary string to convert (e.g., "100")
     * @return the equivalent decimal integer
     * @throws IllegalArgumentException if the input contains characters other
     * than '0' or '1', or if the string is empty
     */
    private static int binaryToDecimalManual(String binary) {

        // Validate input: must be non-empty.
        if (binary == null || binary.isEmpty()) {
            throw new IllegalArgumentException(
                    "Binary string must not be null or empty.");
        }

        // 'decimal' holds the running total, starting at 0.
        int decimal = 0;

        // Walk through each character of the binary string from left
        // (most significant bit) to right (least significant bit).
        for (int i = 0; i < binary.length(); i++) {

            // Fetch the current character and validate it.
            char bit = binary.charAt(i);
            if (bit != '0' && bit != '1') {
                throw new IllegalArgumentException(
                        "Invalid binary character '" + bit
                        + "' at index " + i + ". Only '0' and '1' are allowed.");
            }

            // Multiply the running total by 2 (shift one position left),
            // then add the numeric value of the current bit.
            //   '1' - '0' = 1
            //   '0' - '0' = 0
            decimal = decimal * 2 + (bit - '0');
        }

        // Return the computed decimal value.
        return decimal;
    }
}
